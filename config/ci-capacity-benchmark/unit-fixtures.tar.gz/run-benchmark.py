from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
parser=argparse.ArgumentParser()
parser.add_argument('--scenario',choices=['storm','antigravity'],required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
bundle=Path(__file__).resolve().parent
root=Path.cwd()
relative=Path('src/main/git/command-runner/git-admission-storm-measurement.test.ts') if args.scenario=='storm' else Path('src/main/runtime/antigravity-screen-readiness-transcripts.test.ts')
test=root/relative
original=(bundle/f'{args.scenario}-original.source').read_text()
candidate=(bundle/f'{args.scenario}-candidate.source').read_text()
restore=test.read_text()
if restore!=candidate:
 raise RuntimeError('Current candidate differs from frozen bundled source')
if args.scenario=='storm':
 fixture=root/'src/main/git/command-runner/git-admission-storm-test-fixture.ts'
 if fixture.read_text()!=(bundle/'git-admission-storm-test-fixture.source').read_text():
  raise RuntimeError('Current storm fixture differs from frozen bundled source')
expected_passes=1 if args.scenario=='storm' else 60
args.out.mkdir(parents=True,exist_ok=True)
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_GIT_ADMISSION_STORM_MEASUREMENT':'0'}
rows=[]
try:
 for index,label in enumerate(['baseline','candidate','candidate','baseline','baseline','candidate']):
  source=original if label=='baseline' else candidate
  test.write_text(source)
  target=(args.out/f'{index}-{label}.json').resolve()
  started=time.perf_counter()
  with (args.out/f'{index}-{label}.log').open('w') as out:
   proc=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.config.ts',str(relative),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json',f'--outputFile={target}'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
  wall=time.perf_counter()-started
  report=json.loads(target.read_text())
  expected_skips=1 if args.scenario=='storm' and label=='candidate' else 0
  if proc.returncode!=0 or report['numPassedTests']!=expected_passes or report['numFailedTests']!=0 or report['numPendingTests']!=expected_skips:
   raise RuntimeError(f'{label} failed qualification; inspect {target}')
  cases=[case for file in report['testResults'] for case in file['assertionResults']]
  row={'mode':label,'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'processWallSeconds':wall,'bodyMs':sum(case.get('duration',0) for case in cases),'passed':report['numPassedTests'],'skipped':report['numPendingTests']}
  rows.append(row)
  print(json.dumps(row),flush=True)
finally:
 test.write_text(restore)
 if test.read_text()!=restore:
  raise RuntimeError('Failed to restore frozen candidate')
(args.out/'summary.json').write_text(json.dumps(rows,indent=2))
