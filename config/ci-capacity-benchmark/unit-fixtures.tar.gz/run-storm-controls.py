from pathlib import Path
import argparse,hashlib,json,os,subprocess
parser=argparse.ArgumentParser()
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
bundle=Path(__file__).resolve().parent
root=Path.cwd()
relative=Path('src/main/git/command-runner/git-admission-storm-measurement.test.ts')
test=root/relative
candidate=(bundle/'storm-candidate.source').read_text()
restore=test.read_text()
if restore!=candidate:
 raise RuntimeError('Current candidate differs from frozen bundled source')
reset=candidate[candidate.index('  _resetGitAdmissionForTests('):candidate.index("  const root = await createStormRoot('contention')")].rstrip()
constructor='  const mutationScheduler = new GitAdmissionScheduler({ now: () => 0, onAdmissionEvent: (event) => admissionEvents.push(event) })'
mutants={
 'bypassed-admission':(candidate.replace('      admissionTier: tier,','      admissionTier: tier,\n      admissionExempt: true,'),'expected +0 to be 4'),
 'withheld-release':(candidate.replace(reset,constructor+'''
  const acquire = mutationScheduler.acquire.bind(mutationScheduler)
  mutationScheduler.acquire = async (request) => {
    const grant = await acquire(request)
    return { ...grant, release: () => {} }
  }
  _resetGitAdmissionForTests(mutationScheduler)'''),'Child interactive-queued-0 did not start'),
 'fifo-priority':(candidate.replace(reset,constructor+'''
  Object.defineProperty(mutationScheduler, 'effectiveTier', { value: () => 0 })
  _resetGitAdmissionForTests(mutationScheduler)'''),'Child interactive-queued-0 did not start')
}
args.out.mkdir(parents=True,exist_ok=True)
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_GIT_ADMISSION_STORM_MEASUREMENT':'0'}
rows=[]
try:
 for label,(source,expected_message) in mutants.items():
  if source==candidate:
   raise RuntimeError(f'{label} mutation was not applied')
  test.write_text(source)
  target=(args.out/f'{label}.json').resolve()
  with (args.out/f'{label}.log').open('w') as out:
   proc=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.config.ts',str(relative),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json',f'--outputFile={target}'],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=60)
  report=json.loads(target.read_text())
  cases=[case for file in report['testResults'] for case in file['assertionResults']]
  failed=[case for case in cases if case['status']=='failed']
  if proc.returncode==0 or len(failed)!=1 or report['numFailedTests']!=1 or report['numPendingTests']!=1 or expected_message not in failed[0]['failureMessages'][0]:
   raise RuntimeError(f'{label} did not fail at its expected oracle; inspect {target}')
  row={'mutation':label,'bodyMs':failed[0]['duration'],'failure':failed[0]['failureMessages'][0].split('\n')[0]}
  rows.append(row)
  print(json.dumps(row),flush=True)
finally:
 test.write_text(restore)
 if test.read_text()!=restore:
  raise RuntimeError('Failed to restore frozen candidate')
(args.out/'summary.json').write_text(json.dumps(rows,indent=2))
