from pathlib import Path
import argparse, hashlib, json, os, re, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
root = Path.cwd()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
sim_relative = Path('src/main/runtime/orca-runtime-tail-wait-memo.test.ts')
runtime_relative = Path('src/main/runtime/pty-transcript-prune-wait-cache.test.ts')
restore = {relative: (root / relative).read_text() for relative in [sim_relative, runtime_relative]}
old_sim = (bundle / 'tail-memo-import-original.source').read_text()
new_runtime = (bundle / 'tail-final-runtime-cache.source').read_text()
production_inputs = {
    'orca-runtime-on-pty-data': (
        Path('src/main/runtime/orca-runtime-on-pty-data.ts'),
        (bundle / 'runtime-on-pty-data-original.source').read_text()
    ),
    'orca-runtime-refresh-floating-workspace-pty-liveness': (
        Path('src/main/runtime/orca-runtime-refresh-floating-workspace-pty-liveness.ts'),
        (bundle / 'runtime-prune-original.source').read_text()
    )
}
for relative, source in production_inputs.values():
    if (root / relative).read_text() != source:
        raise RuntimeError(f'Production source changed since snapshot: {relative}')
cache_selection = '''        const previousWaitState =
          leaf.tailWaitState?.fromTail === true
            ? leaf.tailWaitState
            : computeTerminalTailWaitState(leaf.tailBuffer, leaf.tailPartialLine, leaf.preview)'''
uncached = '''        const previousWaitState = computeTerminalTailWaitState(
          leaf.tailBuffer, leaf.tailPartialLine, leaf.preview
        )'''
mutants = [
    ('disabled-runtime-cache', 'orca-runtime-on-pty-data', cache_selection, uncached,
     'expected 4 to be 3'),
    ('disabled-runtime-stamping', 'orca-runtime-on-pty-data', '          leaf.waitBlockedAt = at\n', '',
     'expected null to be 4000'),
    ('disabled-runtime-prune-invalidation', 'orca-runtime-refresh-floating-workspace-pty-liveness',
     '    pty.tailWaitState = undefined\n', '', 'to be undefined')
]

def with_import_check(source):
    vitest_import = "import { describe, expect, it, vi } from 'vitest'"
    if source.count(vitest_import) != 1:
        raise RuntimeError('Expected a single test import')
    return source.replace(vitest_import, "import { afterAll, describe, expect, it, vi } from 'vitest'") + "\nafterAll(() => expect(process.env.ORCA_RUNTIME_MUTANT_IMPORTED).toBe('1'))\n"

env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_RUNTIME_MUTANT_IMPORTED': '0'}
rows = []
try:
    (root / sim_relative).write_text(with_import_check(old_sim))
    (root / runtime_relative).write_text(with_import_check(new_runtime))
    for label, module, pattern, replacement, failure_message in mutants:
        relative, original = production_inputs[module]
        if original.count(pattern) != 1:
            raise RuntimeError(f'Expected one mutation site for {label}')
        source = original.replace(pattern, replacement)
        source = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                        lambda match: 'from ' + json.dumps((root / relative.parent / match.group(2)).resolve().as_posix()), source)
        source += "\nprocess.env.ORCA_RUNTIME_MUTANT_IMPORTED = '1'\n"
        mutant = out / f'{label}.ts'
        mutant.write_text(source)
        config = out / f'{label}.config.ts'
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*' + module +
                          '$/, replacement: ' + json.dumps(mutant.as_posix()) +
                          ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        for oracle, test, expected_passed, expected_failed in [
                ('old-copied-loops', sim_relative, 12, 0),
                ('real-runtime', runtime_relative, 1, 1)]:
            target = out / f'{label}-{oracle}.json'
            with (out / f'{label}-{oracle}.log').open('w') as log:
                proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(test),
                                       '--maxWorkers=1', '--experimental.fsModuleCache=false', '--reporter=json',
                                       f'--outputFile={target}'], cwd=root, env=env, stdout=log,
                                      stderr=subprocess.STDOUT, timeout=90)
            report = json.loads(target.read_text())
            failed = [case for file in report['testResults'] for case in file['assertionResults']
                      if case['status'] == 'failed']
            if report['numPassedTests'] != expected_passed or report['numFailedTests'] != expected_failed or \
                    report['numPendingTests'] != 0 or (proc.returncode == 0) != (expected_failed == 0) or \
                    (expected_failed and (len(failed) != 1 or failure_message not in failed[0]['failureMessages'][0])):
                raise RuntimeError(f'{label}/{oracle} failed at an unexpected oracle; inspect {target}')
            row = {'mutation': label, 'oracle': oracle,
                   'mutantSha256': hashlib.sha256(source.encode()).hexdigest(),
                   'passed': report['numPassedTests'], 'failed': report['numFailedTests'],
                   'failure': failed[0]['failureMessages'][0].split('\n')[0] if failed else None}
            rows.append(row)
            print(json.dumps(row), flush=True)
finally:
    for relative, source in restore.items():
        (root / relative).write_text(source)
        if (root / relative).read_text() != source:
            raise RuntimeError(f'Failed to restore {relative}')
    for relative, source in production_inputs.values():
        if (root / relative).read_text() != source:
            raise RuntimeError(f'Production source changed during controls: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
