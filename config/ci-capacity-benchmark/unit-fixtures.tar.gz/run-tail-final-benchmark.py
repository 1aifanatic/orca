from pathlib import Path
import argparse, hashlib, json, os, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
root = Path.cwd()
inputs = [
    ('memo', Path('src/main/runtime/orca-runtime-tail-wait-memo.test.ts')),
    ('equivalence', Path('src/main/runtime/retained-tail-redraw-window.equivalence.test.ts')),
    ('projection', Path('src/main/runtime/terminal-projection.test.ts')),
    ('runtime-cache', Path('src/main/runtime/pty-transcript-prune-wait-cache.test.ts'))
]
baseline = {label: (bundle / (f'tail-{label}-import-original.source' if label != 'runtime-cache'
                            else 'runtime-cache-original.source')).read_text() for label, _ in inputs}
candidate = {label: (bundle / f'tail-final-{label}.source').read_text() for label, _ in inputs}
restore = {label: (root / relative).read_text() for label, relative in inputs}
args.out.mkdir(parents=True, exist_ok=True)
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1'}
rows = []
try:
    for index, mode in enumerate(['baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate']):
        sources = baseline if mode == 'baseline' else candidate
        for label, relative in inputs:
            (root / relative).write_text(sources[label])
        target = (args.out / f'{index}-{mode}.json').resolve()
        started = time.perf_counter()
        with (args.out / f'{index}-{mode}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                   *[str(relative) for _, relative in inputs], '--maxWorkers=1',
                                   '--experimental.fsModuleCache=false', '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        wall = time.perf_counter() - started
        report = json.loads(target.read_text())
        expected_passed = 16 if mode == 'baseline' else 7
        if proc.returncode != 0 or report['numPassedTests'] != expected_passed or \
                report['numFailedTests'] != 0 or report['numPendingTests'] != 0:
            raise RuntimeError(f'{mode} did not pass all {expected_passed} cases; inspect {target}')
        cases = [case for file in report['testResults'] for case in file['assertionResults']]
        row = {'mode': mode, 'sourceSha256': {label: hashlib.sha256(source.encode()).hexdigest()
                                            for label, source in sources.items()},
               'processWallSeconds': wall, 'bodyMs': sum(case.get('duration', 0) for case in cases),
               'passed': report['numPassedTests'],
               'caseNames': [case['fullName'] for case in cases]}
        rows.append(row)
        print(json.dumps(row), flush=True)
finally:
    for label, relative in inputs:
        (root / relative).write_text(restore[label])
        if (root / relative).read_text() != restore[label]:
            raise RuntimeError(f'Failed to restore {relative}')
(args.out / 'summary.json').write_text(json.dumps(rows, indent=2))
