# Range-selection import benchmark

Run from the primary checkout with frozen candidate installed:

```
python3 <bundle>/run-controls.py --out <out>/controls
python3 <bundle>/run-benchmark.py --out <out>/pairs
```

The benchmark runs three counterbalanced fresh-process pairs at maxWorkers=1 with filesystem and Node compile caches disabled. Both modes must have exactly the original15 names,15 passes and zero skips. Scripts guard frozen test and actual production inputs, set ORCA_BACKGROUND_LAUNCH=1 and restore incoming owned test bytes in finally. The manifest is the explicit list of source/census inputs. The flat hosted archive is rooted at driver scripts.

The previous partial diff-comment-zone-card mock intentionally retains actual draft rendering, but importOriginal also loads the saved-note NotesSendMenu and its agent detection, launch, delivery and sidebar graphs. Every original case supplies comments:[] and already stubs renderDiffCommentZoneCard. The candidate replaces only that unrelated NotesSendMenu component with vi.fn<typeof NotesSendMenu>. The facade throws if invoked and afterEach checks no calls; finally clears mock history even when the sentinel fails. Actual React hooks, Monaco imports/constants, editor fixture/model/selection, range drag, overlay, keyboard bindings, draft-zone lifecycle, TooltipProvider and DiffCommentDraftCard remain. All15 original case bodies/names are unchanged. Real NotesSendMenu.test.tsx and ReviewNotesSendMenuContent.test.tsx independently cover delivery-menu implementation behavior.

Final local original walls4.789/4.631/4.955s versus candidate3.505/3.448/3.679s; medians4.789→3.505s (26.8% lower). All15 pass with zero skips in all six runs. Refreshed CI11.551s non-body is not solely removable import cost: real Monaco still loads; only these direct paired numbers establish the local gain.

Three disposable actual production mutations independently disable pending-range painting, ignore hunk clamping, and hide an open inline draft. Each must fail its selected original assertion with14 other cases skipped and an imported-module marker. A fourth actual draft-render mutation invokes the unrelated menu and must fail both the throwing facade and no-call sentinel. Independent afterAll assertions verify its call history was cleared after those intentional failures. Controls use the primary checkout's exact React/Monaco package entrypoints because renderer Vite cannot resolve bare packages beside disposable /tmp modules; these are real dependencies, with no package mocks. Actual production files remain unchanged and hash guarded.

Final candidate SHA54f7eebf962565d0d0e000800a8dcd77f0d8b42b014e01a9eca6ec0c477a6b77; original145ffe941eddd3f84235b479603db30004aebd627af8f50277100205acef02ba. Focused oxlint, oxfmt --check and git diff --check pass. Independent final source review is clean at the final SHA; full pnpm tc:web passed. Live candidate was restored byte-for-byte, and all production hashes remain unchanged. CPU and source mutation windows are released.
