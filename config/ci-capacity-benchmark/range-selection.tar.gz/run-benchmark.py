from pathlib import Path
import argparse, hashlib, json, os, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle, root, out = Path(__file__).resolve().parent, Path.cwd(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/renderer/src/components/diff-comments/useDiffCommentDecorator.range-selection.test.tsx')
production = {'src/renderer/src/components/diff-comments/useDiffCommentDecorator.tsx': 'hook-original.source', 'src/renderer/src/components/diff-comments/diff-comment-line-range.ts': 'range-original.source', 'src/renderer/src/components/diff-comments/diff-comment-range-drag.ts': 'drag-original.source', 'src/renderer/src/components/diff-comments/diff-comment-add-note-shortcut.ts': 'shortcut-original.source', 'src/renderer/src/components/diff-comments/diff-comment-draft-zone.ts': 'draft-original.source', 'src/renderer/src/components/diff-comments/diff-comment-zone-card.tsx': 'zone-original.source', 'src/renderer/src/components/editor/NotesSendMenu.tsx': 'menu-original.source'}
production = {Path(path): frozen for path, frozen in production.items()}
manifest = json.loads((bundle / 'manifest.json').read_text())
for filename, expected in manifest.items():
    if hashlib.sha256((bundle / filename).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Frozen input changed: {filename}')
sources = {mode: (bundle / f'{mode}.source').read_text() for mode in ['original', 'candidate']}
if (root / test).read_text() != sources['candidate']:
    raise RuntimeError('Candidate test differs from frozen source')
for relative, frozen in production.items():
    if (root / relative).read_bytes() != (bundle / frozen).read_bytes():
        raise RuntimeError(f'Production differs from frozen source: {relative}')
restore = (root / test).read_bytes()
names = json.loads((bundle / 'case-names.json').read_text())
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1'}
rows, expected_statuses = [], None
try:
    for index, mode in enumerate(['original', 'candidate', 'candidate', 'original', 'original', 'candidate']):
        (root / test).write_text(sources[mode])
        target = out / f'{index}-{mode}.json'
        started = time.perf_counter()
        with (out / f'{index}-{mode}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                   str(test), '--maxWorkers=1', '--experimental.fsModuleCache=false',
                                   '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        wall = time.perf_counter() - started
        report = json.loads(target.read_text())
        cases = [case for suite in report['testResults'] for case in suite['assertionResults']]
        statuses = {case['fullName']: case['status'] for case in cases}
        if proc.returncode or not report['success'] or report['numTotalTests'] != 15 or \
                report['numFailedTests'] or report['numPassedTests'] != 15 or report['numPendingTests'] != 0 or sorted(statuses) != names or \
                set(statuses.values()) - {'passed', 'pending', 'skipped'}:
            raise RuntimeError(f'{mode} changed the original 15 cases; inspect {target}')
        if expected_statuses is None:
            expected_statuses = statuses
        if statuses != expected_statuses:
            raise RuntimeError(f'{mode} changed pass/skip outcomes')
        row = {'mode': mode, 'testSha256': manifest[f'{mode}.source'],
               'processWallSeconds': wall, 'bodyMs': sum(case.get('duration', 0) for case in cases),
               'passed': report['numPassedTests'], 'pending': report['numPendingTests'],
               'caseStatuses': statuses}
        rows.append(row)
        print(json.dumps(row), flush=True)
finally:
    (root / test).write_bytes(restore)
    if (root / test).read_bytes() != restore:
        raise RuntimeError('Test restoration failed')
    for relative, frozen in production.items():
        if (root / relative).read_bytes() != (bundle / frozen).read_bytes():
            raise RuntimeError(f'Production changed during benchmark: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
