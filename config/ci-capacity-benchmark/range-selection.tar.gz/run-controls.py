from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle, root, out = Path(__file__).resolve().parent, Path.cwd(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/renderer/src/components/diff-comments/useDiffCommentDecorator.range-selection.test.tsx')
base = Path('src/renderer/src/components/diff-comments')
production = {
    'hook': base / 'useDiffCommentDecorator.tsx',
    'range': base / 'diff-comment-line-range.ts',
    'drag': base / 'diff-comment-range-drag.ts',
    'shortcut': base / 'diff-comment-add-note-shortcut.ts',
    'draft': base / 'diff-comment-draft-zone.ts',
    'zone': base / 'diff-comment-zone-card.tsx',
    'menu': Path('src/renderer/src/components/editor/NotesSendMenu.tsx')
}
manifest = json.loads((bundle / 'manifest.json').read_text())
for name, expected in manifest.items():
    if hashlib.sha256((bundle / name).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Frozen input changed: {name}')
candidate = (bundle / 'candidate.source').read_text()
names = json.loads((bundle / 'case-names.json').read_text())
original = {family: (bundle / f'{family}-original.source').read_text() for family in production}
if (root / test).read_text() != candidate:
    raise RuntimeError('Candidate test differs from frozen source')
for family, relative in production.items():
    if (root / relative).read_text() != original[family]:
        raise RuntimeError(f'Production differs from frozen source: {relative}')
restore = (root / test).read_bytes()
mutants = [
    ('pending-range-ignored', 'drag', 'pendingRange = range', 'pendingRange = null',
     'keeps the open composer range lit and clears it when the composer closes',
     ['expected null to deeply equal'], 1),
    ('hunk-clamp-ignored', 'range', 'if (!commentableLines.has(line)) {\n      break\n    }',
     'if (!commentableLines.has(line)) {\n      return focusLine\n    }',
     'clamps a selection that runs past the end of the hunk', ['"lineNumber": 12', '"lineNumber": 30'], 1),
    ('open-draft-not-reported', 'draft',
     'const isDraftOpen = useCallback((): boolean => draftZoneRef.current !== null, [])',
     'const isDraftOpen = useCallback((): boolean => false, [])',
     'leaves the chord to an open inline draft card instead of re-anchoring it',
     ['to deeply equal', 'afterLineNumber'], 1),
    ('unrelated-menu-invoked', 'zone',
     '): void {\n  root.render(\n    <TooltipProvider delayDuration={400}>\n      <DiffCommentDraftCard',
     "): void {\n  NotesSendMenu({ worktreeId: 'worktree-1', groupId: 'worktree-1', modeIdParts: [], scopes: [], onDelivered: () => {} })\n  root.render(\n    <TooltipProvider delayDuration={400}>\n      <DiffCommentDraftCard",
     'leaves the chord to an open inline draft card instead of re-anchoring it',
     ['Range selection must not render the agent notes menu', 'to not be called'], 2)
]
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_RANGE_SELECTION_MUTANT_IMPORTED': '0'}
rows = []
try:
    for label, family, pattern, replacement, selected, expected, failure_count in mutants:
        relative = production[family]
        if original[family].count(pattern) != 1:
            raise RuntimeError(f'Changed mutation site: {pattern}')
        mutated = original[family].replace(pattern, replacement)
        mutated = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                         lambda match: 'from ' + json.dumps((root / relative.parent / match.group(2)).resolve().as_posix()), mutated)
        for dependency, entry in [
            ('monaco-editor', 'node_modules/monaco-editor/esm/vs/editor/editor.main.js'),
            ('react', 'node_modules/react/index.js'),
            ('react-dom/client', 'node_modules/react-dom/client.js')
        ]:
            mutated = mutated.replace("from '" + dependency + "'", 'from ' + json.dumps((root / entry).as_posix()))
        mutated += "\nprocess.env.ORCA_RANGE_SELECTION_MUTANT_IMPORTED = '1'\n"
        module_file = out / f'{label}{relative.suffix}'
        module_file.write_text(mutated)
        config = out / f'{label}.config.ts'
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*' + re.escape(relative.stem) +
                          '$/, replacement: ' + json.dumps(module_file.as_posix()) +
                          ' }, { find: /^react[/]jsx-runtime$/, replacement: ' + json.dumps((root / 'node_modules/react/jsx-runtime.js').as_posix()) + ' }, { find: /^react[/]jsx-dev-runtime$/, replacement: ' + json.dumps((root / 'node_modules/react/jsx-dev-runtime.js').as_posix()) + ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        source = candidate.replace('import { afterEach,', 'import { afterAll, afterEach,')
        source += "\nafterAll(() => { expect(process.env.ORCA_RANGE_SELECTION_MUTANT_IMPORTED).toBe('1'); expect(notesMenuFixture.NotesSendMenu, 'failure cleanup must clear unrelated menu call history').not.toHaveBeenCalled() })\n"
        (root / test).write_text(source)
        target = out / f'{label}.json'
        started = time.perf_counter()
        with (out / f'{label}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(test),
                                   '--maxWorkers=1', '--experimental.fsModuleCache=false',
                                   '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        report = json.loads(target.read_text())
        cases = [case for suite in report['testResults'] for case in suite['assertionResults']]
        failed = [case for case in cases if case['status'] == 'failed']
        failures = '\n'.join(failed[0]['failureMessages']) if len(failed) == 1 else ''
        if sorted(case['fullName'] for case in cases) != names or proc.returncode != 1 or \
                report['numPassedTests'] != 0 or report['numFailedTests'] != 1 or report['numPendingTests'] != 14 or \
                len(failed) != 1 or failed[0]['title'] != selected or \
                len(failed[0]['failureMessages']) != failure_count or not all(text in failures for text in expected):
            raise RuntimeError(f'{label} failed at an unexpected oracle; inspect {target}')
        row = {'mutation': label, 'productionSha256': hashlib.sha256(mutated.encode()).hexdigest(),
               'testSha256': hashlib.sha256(source.encode()).hexdigest(),
               'processWallSeconds': time.perf_counter() - started, 'bodyMs': failed[0].get('duration', 0),
               'failed': 1, 'pending': 14,
               'failures': [failure.split('\n')[0] for failure in failed[0]['failureMessages']]}
        rows.append(row)
        print(json.dumps(row), flush=True)
        (root / test).write_bytes(restore)
finally:
    (root / test).write_bytes(restore)
    if (root / test).read_bytes() != restore:
        raise RuntimeError('Test restoration failed')
    for family, relative in production.items():
        if (root / relative).read_text() != original[family]:
            raise RuntimeError(f'Production changed during controls: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
