import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { createRequire } from 'node:module'
import { join, resolve } from 'node:path'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
const root = resolve(process.cwd())
const { Terminal } = createRequire(join(root, 'package.json'))('@xterm/headless')
const mutantDirectory = mkdtempSync(join(tmpdir(), 'orca-serializer-negative-'))

const baseline = await import(pathToFileURL(join(import.meta.dirname, 'baseline-cell-descriptors.ts')).href)
const candidatePath = join(root, 'src/main/daemon/serialize-grid-cell-descriptors.ts')
const original = readFileSync(candidatePath, 'utf8')
const mutants = [
  ['missing-bold', '(expected.isBold() !== 0) === (actual.isBold() !== 0) &&', ''],
  ['blank-underline-loss', "expectedChars === ' ' && expected.isUnderline() !== 0", 'false'],
  ['clipped-policy-loss', "expected === actual || (expected === CLIPPED && actual.startsWith('▯'))", 'expected === actual'],
  ['trailing-blank-loss', 'while (end > start)', 'while (false)'],
  ['stale-text', 'expectedChars === actualChars &&', 'true &&']
]

function write(terminal, data) { terminal._core.writeSync(data) }
function reference(expected, actual, cols, starts = [-1, expected.length + 2, -1, actual.length + 1]) {
  const [es, ee, as, ae] = starts
  return baseline.compareRowSets('control', baseline.bufferRows(expected, es, ee, cols), baseline.bufferRows(actual, as, ae, cols))
}
function qualify(compare) {
  let comparisons = 0
  const expected = new Terminal({ cols: 8, rows: 4, scrollback: 10, allowProposedApi: true, logLevel: 'off' })
  const actual = new Terminal({ cols: 8, rows: 4, scrollback: 10, allowProposedApi: true, logLevel: 'off' })
  try {
    const check = (cols = 8) => {
      const e = expected.buffer.active, a = actual.buffer.active
      for (const [es, ee, as, ae] of [[0, e.length, 0, a.length], [-1, e.length + 2, -1, a.length + 1], [1, e.length + 1, 0, a.length]]) {
        assert.deepEqual(compare('control', e, es, ee, a, as, ae, cols), reference(e, a, cols, [es, ee, as, ae]))
        comparisons++
      }
    }
    const sgr = [1, 2, 3, 4, 7, 8, 9]
    const flags = (mask) => sgr.filter((_code, bit) => (mask & (1 << bit)) !== 0).join(';') || '0'
    for (let mask = 0; mask < 128; mask++) {
      write(expected, `\x1bc\x1b[${flags(mask)}mA\x1b[0mB`)
      write(actual, `\x1bc\x1b[${flags(mask)}mA\x1b[0mB`)
      check()
      for (let bit = 0; bit < sgr.length; bit++) {
        if (mask & (1 << bit)) {
          write(actual, `\x1bc\x1b[${flags(mask & ~(1 << bit))}mA\x1b[0mB`)
          check()
        }
      }
    }
    for (const [e, a, cols] of [
      ['abc界', 'abc ', 4], ['abc界', 'abc\x1b[48;2;1;2;3m ', 4], ['abc ', 'abc界', 4],
      ['é', 'è', 8], ['\x1b[32mA', '\x1b[38;5;2mA', 8],
      ['\x1b[42m ', '\x1b[48;5;2m ', 8], ['\x1b[7;31m ', '\x1b[7;32m ', 8],
      ['\x1b[4m\x1b[2J', '\x1b[2J', 8], ['\x1b[4m ', ' ', 8], ['\x1b[4m \x1b[0mB', ' B', 8],
      ['text\r\n', 'text', 8], ['text\r\n\x1b[48;2;1;2;3m\x1b[2K', 'text', 8],
      ['\x1b[?1049h\x1b[1;2;3;4;7;8;9mALT', '\x1b[?1049h\x1b[1;2;3;4;7;8mALT', 8]
    ]) {
      write(expected, '\x1bc' + e)
      write(actual, '\x1bc' + a)
      check(cols)
    }
  } finally { expected.dispose(); actual.dispose() }
  return comparisons
}

const candidate = await import(pathToFileURL(candidatePath).href)
console.log(JSON.stringify({ variant: 'candidate', parityComparisons: qualify(candidate.compareBufferRows) }))
for (const [name, before, after] of mutants) {
  assert.ok(original.includes(before), `missing mutation target ${name}`)
  const variantPath = join(mutantDirectory, `${name}.ts`)
  writeFileSync(variantPath, original.replace(before, after))
  const variant = await import(pathToFileURL(variantPath).href)
  let detected = false
  try { qualify(variant.compareBufferRows) } catch (error) { detected = error?.code === 'ERR_ASSERTION' }
  assert.ok(detected, `fault survived: ${name}`)
  console.log(JSON.stringify({ variant: name, detected }))
}

rmSync(mutantDirectory, { recursive: true, force: true })
