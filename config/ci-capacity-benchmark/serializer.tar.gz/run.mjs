import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createReadStream, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { createInterface } from 'node:readline'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const output = resolve(process.argv[2] || join(root, 'artifacts/serialize-grid-benchmark'))
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const paths = ['src/main/daemon/serialize-grid-cell-descriptors.ts', 'src/main/daemon/serialize-grid-roundtrip.ts']
const candidate = paths.map((file) => readFileSync(join(root, file), 'utf8'))
const baseline = ['baseline-cell-descriptors.ts', 'baseline-roundtrip.ts'].map((file) => readFileSync(join(import.meta.dirname, file), 'utf8'))
const heavyFiles = ['src/main/daemon/serialize-grid-transcript-replay.test.ts', 'src/main/daemon/serialize-grid.differential.fuzz.test.ts']
const files = [...heavyFiles, 'src/main/daemon/serialize-grid-cell-descriptors.test.ts']
const env = { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }
for (const key of Object.keys(env)) {
  if (key.startsWith('SERIALIZE_') || key === 'ORCA_OLD_SERIALIZE_ADDON' || key === 'ORCA_NEW_SERIALIZE_ADDON') delete env[key]
}
mkdirSync(output, { recursive: true })
const digest = (data) => createHash('sha256').update(data).digest('hex')
const initialHashes = Object.fromEntries(paths.map((file, index) => [file, digest(candidate[index])]))
const results = []

function install(arm) {
  const sources = arm === 'baseline' ? baseline : candidate
  for (let index = 0; index < paths.length; index++) writeFileSync(join(root, paths[index]), sources[index])
}
function execute(args, extraEnv = {}) {
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, ...args], cwd: root, env: { ...env, ...extraEnv }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  assert.equal(result.code, 0, describeProcessFailure(result))
  return { wallMs: performance.now() - started, stdout: result.stdout, stderr: result.stderr }
}
function testRun(label, selected, extraArgs = [], extraEnv = {}) {
  const reportPath = join(output, `${label}.json`)
  const result = execute(['exec', 'vitest', 'run', '--config', 'config/vitest.config.ts', ...selected, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], extraEnv)
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  assert.equal(report.numFailedTests, 0)
  return { label, wallMs: result.wallMs, bodyMs: report.testResults.flatMap((file) => file.assertionResults).reduce((total, test) => total + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, files: report.numTotalTestSuites }
}
function instrument(source) {
  const markers = ['return { checks: results, sourceCrash: String(error) }', 'return { checks: results, sourceCrash: null }']
  for (const marker of markers) assert.equal(source.split(marker).length, 2)
  source = `import { appendFileSync as appendSerializeCapture } from 'node:fs'\n${source}`
  source = source.replace('export async function runSerializeFuzzCase(', `function captureSerializeRun(testCase: SerializeFuzzCase, run: SerializeCaseRun): SerializeCaseRun {
  appendSerializeCapture(process.env.SERIALIZE_ORACLE_CAPTURE!, JSON.stringify({ testCase, run }) + String.fromCharCode(10))
  return run
}

export async function runSerializeFuzzCase(`)
  source = source.replace(markers[0], 'return captureSerializeRun(testCase, { checks: results, sourceCrash: String(error) })')
  return source.replace(markers[1], 'return captureSerializeRun(testCase, { checks: results, sourceCrash: null })')
}
async function captureSummary(capturePath) {
  const hash = createHash('sha256')
  let bytes = 0, scenarios = 0, checkpoints = 0, crashes = 0
  const stream = createReadStream(capturePath)
  stream.on('data', (chunk) => { hash.update(chunk); bytes += chunk.length })
  const lines = createInterface({ input: stream, crlfDelay: Infinity })
  for await (const line of lines) {
    const { run } = JSON.parse(line)
    scenarios++
    checkpoints += run.checks.length
    crashes += run.sourceCrash === null ? 0 : 1
  }
  return { sha256: hash.digest('hex'), bytes, scenarios, checkpoints, crashes }
}
try {
  // The new early-stop count control has no counterpart in the eager baseline.
  const namePattern = '^(?!.*reuses one cell per buffer).*$'
  for (let pair = 1; pair <= 3; pair++) {
    for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
      install(arm)
      const sample = testRun(`${arm}-${pair}`, files, ['--testNamePattern', namePattern])
      results.push({ pair, arm, ...sample })
      console.log(JSON.stringify(results.at(-1)))
    }
  }
  for (const sample of results) {
    assert.equal(sample.passes, 116)
    assert.equal(sample.skips, 3)
  }
  const captures = {}
  for (const arm of ['baseline', 'candidate']) {
    install(arm)
    writeFileSync(join(root, paths[1]), instrument(readFileSync(join(root, paths[1]), 'utf8')))
    const capturePath = join(output, `${arm}-capture.jsonl`)
    writeFileSync(capturePath, '')
    const run = testRun(`${arm}-capture`, heavyFiles, [], { SERIALIZE_ORACLE_CAPTURE: capturePath })
    assert.equal(run.passes, 97)
    assert.equal(run.skips, 2)
    captures[arm] = { ...run, ...await captureSummary(capturePath) }
    assert.equal(captures[arm].scenarios, 1611)
    assert.equal(captures[arm].crashes, 0)
  }
  assert.deepEqual(
    ['sha256', 'bytes', 'scenarios', 'checkpoints', 'crashes'].map((key) => captures.baseline[key]),
    ['sha256', 'bytes', 'scenarios', 'checkpoints', 'crashes'].map((key) => captures.candidate[key])
  )
  install('candidate')
  const controls = testRun('candidate-controls', [files[2]])
  const negative = execute(['exec', 'node', '--disable-warning=MODULE_TYPELESS_PACKAGE_JSON', join(import.meta.dirname, 'negative-controls.mjs')])
  writeFileSync(join(output, 'negative-controls.log'), negative.stdout + negative.stderr)
  const summary = {
    environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion },
    initialHashes,
    samples: results,
    baseline: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs)),
    candidate: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs)),
    captures,
    controls,
    negativeControls: negative.stdout.trim().split(String.fromCharCode(10)).map((line) => JSON.parse(line))
  }
  summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + String.fromCharCode(10))
  console.log(JSON.stringify(summary))
} finally {
  for (let index = 0; index < paths.length; index++) writeFileSync(join(root, paths[index]), candidate[index])
}
