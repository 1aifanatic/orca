import { resolve } from 'node:path'
import { defineConfig } from '__VITEST_CONFIG__'
import base from '__BASE_CONFIG__'
import FrozenAssignmentSequencer from './frozen-assignment-sequencer.mjs'

if (base.test?.experimental?.fsModuleCache) {
  throw new Error('This holdout keeps the existing disabled filesystem transform cache')
}
export default defineConfig({
  ...base,
  cacheDir: process.env.ORCA_REBALANCE_CACHE_DIR,
  test: {
    ...base.test,
    sequence: { ...base.test?.sequence, sequencer: FrozenAssignmentSequencer },
    reporters: ['default', resolve('config/scripts/ci-unit-timing-reporter.mjs'), 'json'],
    outputFile: { json: process.env.ORCA_REBALANCE_JSON_REPORT }
  }
})
