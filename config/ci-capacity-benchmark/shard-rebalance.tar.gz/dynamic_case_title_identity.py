import json
import re
from pathlib import Path


def read_rules(path):
    rules = json.loads(Path(path).read_text())
    assert rules['version'] == 1
    assert len(rules['files']) == 2
    for file, rule in rules['files'].items():
        assert file.startswith('src/') and '..' not in Path(file).parts
        assert len(rule['expectedCanonicalCases']) == rule['caseCount']
        assert len(rule['dynamicTitles']) == 1
        for title in rule['dynamicTitles']:
            assert title['pattern'].startswith('^') and title['pattern'].endswith('$')
            re.compile(title['pattern'])
            assert title['expectedMatches'] in [1, 2]
    return rules


def canonicalize_census(census, rules, source_hashes):
    result = {}
    for file, entries in census.items():
        assert all(len(entry) == 2 and all(isinstance(value, str) for value in entry) for entry in entries)
        if file not in rules['files']:
            result[file] = sorted([list(entry) for entry in entries])
            continue
        rule = rules['files'][file]
        assert source_hashes[file] == rule['sourceSha256'], 'Case-title rule source differs: ' + file
        assert len(entries) == rule['caseCount'], 'Case-title rule census differs: ' + file
        match_counts = [0] * len(rule['dynamicTitles'])
        canonical = []
        for name, status in entries:
            identities = []
            for index, title in enumerate(rule['dynamicTitles']):
                match = re.fullmatch(title['pattern'], name)
                if match:
                    match_counts[index] += 1
                    identities.append(match.expand(title['replacement']))
            assert len(identities) <= 1, 'Ambiguous case-title identity: ' + file
            canonical.append([identities[0] if identities else name, status])
        assert match_counts == [title['expectedMatches'] for title in rule['dynamicTitles']], 'Unexpected dynamic title form/count: ' + file
        canonical = sorted(canonical)
        assert canonical == rule['expectedCanonicalCases'], 'Case-title rule text/status differs: ' + file
        result[file] = canonical
    return result
