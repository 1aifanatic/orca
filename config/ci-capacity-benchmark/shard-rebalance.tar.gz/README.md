# One fresh post-registry shard-weight holdout screen

Prepared only. No tests, APIs, dispatch, source overlays or production weight writes. Do not publish or dispatch until the current PR merges and the dashboard branch is restored. Root retains that authority.

Fixed source: `9125022712afddc701282671aaabd94c7f1c0c67`; tree: `51d88559f2916bbbef71da2b71bdd33a167a24bf`. Training: successful normal run `37255291132`, attempt `1`, Node `24.21.0`, Ubuntu ARM, four workers, complete 10,916 ordinary unit files. The fresh source-specific weights/plans are copied under `plans/`; they are not the rejected October 4 weights. No retraining from trial results.

## Existing harness and packaging

All executable harness assets in this directory are byte-identical copies of `/tmp/orca-ci-shard-rebalance-repaired-design-20261004`. `validate-training.py` is deliberately not copied: that old one-off script hardcodes the former source/run and cannot qualify this new trial. `training-validation.json` instead preserves the new successful projection receipt and its source/artifact/job hashes. The existing preparation validates plans with the actual production discovery and LPT implementation.

Once root provides a brief clean primary checkout at the exact fixed source, run:

```sh
python3 /tmp/orca-ci-post-registry-shard-holdout-design-20261005/prepare-holdout.py \
  --source-sha 9125022712afddc701282671aaabd94c7f1c0c67 \
  --plans /tmp/orca-ci-post-registry-shard-holdout-design-20261005/plans \
  --out /tmp/orca-ci-post-registry-shard-holdout-ready-20261005 --rounds 1
```

Then copy `training-validation.json` and `title-readiness.json` into the new ready directory and hash-bind both as additional `inputHashes` entries in its newly generated `holdout-manifest.json`. This is supplemental evidence binding, not a policy/guard change. Re-run the existing `load_bundle` validation, retain a file-hash inventory, and create a flat archive rooted at that ready directory. Parent or an independent agent should review the new manifest/source/training/plan/title bindings before root publishes. Do not run the historical source-specific validation or alter its reports.

Root can later place the flat archive at `config/ci-capacity-benchmark/shard-rebalance.tar.gz` and the generated `paired-workflow.yml` on a temporary support branch. The workflow extracts assets outside the checkout before checking out the fixed source. It runs the normal dependency/native/Electron setup with exact trained Node version. No current-primary checkout change is authorized by this recipe.

## Scope, guards and ordering

One round only: five existing `ubuntu-24.04-arm` jobs, four workers, ten full shard processes covering both complete arms. Odd shards run existing then fresh; even shards reverse that order. No second round, third trial, cache enablement, thread change or isolation change is automatic.

Each arm keeps a distinct empty Vite/Vitest result cache. Filesystem transform cache and Node compile cache stay disabled. Existing BaseSequencer.sort remains active and its order is recorded, not forced equal. The frozen sequencer independently verifies the complete discovered census against the selected plan, including no duplicate, added or omitted file.

Keep the existing exact source/tree and tracked-cleanliness checks before and after each arm, exact toolchain/plan/manifest/training checks, actual assignment and timing reporters, raw JSON/case reports, hash guards and comparer. The driver does not rewrite production weights or source; templates/config/cache/results live outside the checkout. Its native 55-minute timeout sends TERM then unconditionally KILLs the original process group even if the leader exits. This preserves the qualified timeout cleanup; it does not claim arbitrary cancellation handling.

The two existing source-hash-bound title rules remain byte-identical and match unchanged source bytes: only two native-worker temporary-root titles and one profile-preflight UUID title get stable identities. Historical 32 negative controls remain bound to identical rule/module bytes. No new normalization is allowed from this screen. Runtime full-case comparison is mandatory and rejects any unexpected title drift, failures, missing or duplicate cases, status differences, incomplete reports or changed sources. Duplicate names and skipped/pending/todo statuses retain multiplicity. The new full case count is learned from successful raw reports; do not import the old 105,250 count or old canonical census SHA.

Retain prior negative-control evidence for wrong source/hash, case omission/duplication, changed nondynamic text/status and invalid random path/nonce forms. A narrow pure guard recheck of new plan/manifest provenance should precede dispatch; no Vitest run or extra planner is needed for it. If that or independent review exposes an unresolved narrow guard gap, defer the trial instead of relaxing validation.

## Cost and interpretation

Planning reference only: the normal run's five test steps took 594/564/542/523/538 seconds (sum 2,761). Executing both complete arms would occupy roughly 5,522 test-step runner-seconds (92.0 runner-minutes) at those rates, plus common dependency setup, checkout, upload and post-actions: roughly 95-100 runner-minutes as a coarse budget, with hosted runtime variation. Five paired jobs likely take about 19-21 minutes once running; queue time is unknown. These are job-count/budget estimates, not gains or a statistical forecast.

The 8.28% maximum summed-module-load projection merits this screen, but redistribution keeps the 8,915.751 module-second sum unchanged. Actual arm metrics are the sum of five monotonic process walls and the maximum shard process wall. Report shared setup and actual paired-job cost separately; do not call module phases CPU, maximum process duration workflow makespan, or observed job span an arm/queue gain. Complete success and exact case parity are prerequisites. A mixed/noisy result yields rejection or a root decision, never adoption from projection alone; no follow-up is automatic.
