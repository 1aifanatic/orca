# Full-census shard-rebalance holdout

This temporary harness compares existing versus refreshed shard assignments with identical final source. It has not run any tests or dispatched any jobs. It is independent of whether training comes from a final ready PR or a final-main integration run.

First obtain one complete successful final-source Node24/Linux ARM/four-worker unit run. Verify its five attempt-specific job conclusions and the truly final accepted source, including cursor changes. Use the actual checkout SHA reported by the module artifacts, which may be a PR merge SHA rather than its head. The training importer and preparation guards are described in design.md. The earlier run37181177025 projection remains historical and cannot train this final holdout.

## Freeze actual inputs

From the exact clean training-source checkout:

~~~sh
node /tmp/orca-ci-shard-rebalance-repaired-design-20261004/prepare.mjs \
  "$REBALANCE_ARTIFACT_DIRECTORY" config/scripts/ci-shard-timings.json \
  "$REBALANCE_FINAL_SOURCE_SHA" "$REBALANCE_TRAINING_RUN_ID" \
  "$REBALANCE_TRAINING_ATTEMPT" /tmp/orca-ci-shard-rebalance-plans-20261004
python3 /tmp/orca-ci-shard-rebalance-repaired-design-20261004/prepare-holdout.py \
  --source-sha "$REBALANCE_FINAL_SOURCE_SHA" \
  --plans /tmp/orca-ci-shard-rebalance-plans-20261004 \
  --out /tmp/orca-ci-shard-rebalance-repaired-ready-20261004 --rounds 1
tar -czf /tmp/orca-ci-shard-rebalance-repaired-ready-20261004.tar.gz \
  -C /tmp/orca-ci-shard-rebalance-repaired-ready-20261004 .
~~~

Preparation independently discovers the normal final-source census and recalculates both frozen plans using the existing production balanceFiles implementation. It verifies existing checked-in weight bytes, complete final-source fresh timings, common training provenance, and the unchanged whole E2E weight object. Both arms include every ordinary unit file, including terminal-restore-parity-writes.test.ts. There are no additional test exclusions, source overlays or case-ledger exceptions.

It freezes plan/weight/config/driver hashes, the exact source Git tree, training identity, Node version and package-manager version in holdout-manifest.json. A source or input mismatch refuses execution. Trial run ID must differ from training run ID. Nothing retrains or rebalances from holdout results.

## Future hosted execution

Root can place the prepared flat archive at config/ci-capacity-benchmark/shard-rebalance.tar.gz and the generated paired-workflow.yml on a dedicated temporary benchmark branch. This handoff does not publish those assets or dispatch the workflow.

The workflow extracts inputs outside the checkout before switching to the exact fixed source. Its dependency/Electron setup follows the normal unit action. It pins the exact trained Node24 version, uses five Linux ARM jobs and four Vitest workers per process. Odd shard indexes run existing then fresh; even indexes run fresh then existing. The default one-round trial therefore executes the entire unit census twice in five jobs. A deliberately prepared second round reverses every shard's order, executes two additional full arms, and raises the job deadline from 120 to 240 minutes; it is never automatic.

The driver is a dry run unless --execute is passed in a disposable Linux ARM Actions checkout. Each process has a real 55-minute deadline; timeout sends TERM then unconditionally KILLs the original process group, even if its leader exits first. Failed, timed-out or incomplete evidence cannot qualify a gain.

Every arm starts with a distinct empty Vite/Vitest result cache. The original BaseSequencer.sort runs unchanged and records its complete order. Filesystem transform caching remains disabled; Node compile caching is disabled in both arms. Source HEAD/tree and tracked cleanliness are checked before and after each process. Full independent Vitest discovery must match the complete plan census.

Default, existing module-timing and JSON case reporters are all retained. Each arm records exit status, unhandled errors, module states, exact assignment, module durations, raw case report, complete sorted case multiset, sort order, monotonic process wall time, source/tree identity and trial run/attempt. Mandatory artifact bytes are hashed. Module/case files must exactly match that arm's selected shard.

## Compare complete evidence

Download all five rebalance-unit-shard-I-attempt-A artifacts from one holdout attempt and retain the prepared bundle:

~~~sh
python3 /tmp/orca-ci-shard-rebalance-repaired-ready-20261004/compare-paired-shards.py \
  /tmp/rebalance-unit-artifacts \
  --bundle /tmp/orca-ci-shard-rebalance-repaired-ready-20261004 \
  --out /tmp/orca-ci-shard-rebalance-result-20261004.json
~~~

The comparer revalidates raw artifacts instead of trusting the driver's valid marker alone. It requires exactly every prepared round/shard/arm record, five matching input manifests and five setup records. It rejects mixed source/run/attempt/toolchain/platform, failed suites/cases/modules, unhandled errors, omitted/duplicate files, incorrect assignments, altered artifact bytes or sort-order coverage, and unexpected arm order. It compares the complete per-file multiset of full test names and statuses between assignments and rounds, preserving duplicate names and skips. No case count or status difference is approved. The exact reviewed dynamic_case_title_identity.py module and source-bound JSON rules are reused verbatim: only two native-worker temporary-root titles and one profile-preflight v4 UUID title receive stable identities. Every other title remains byte-exact. Raw reports and case-census.json remain intact; canonical-case-census.json has a separate mandatory artifact hash and is recomputed from raw names by the comparer. Both affected source hashes, rule/module hashes and the independent 32-control review receipt are frozen in the bundle.

Primary measurements per arm are maxShardProcessWallSeconds and totalActiveTestSeconds (maximum and sum of its five actual process durations). sumModulePhaseSeconds is a separate elapsed worker-phase diagnostic. Setup-plus-test values are estimates using the common setup cost, reported separately. The counterbalanced arms start at different times, so their maximum process duration is not observed workflow makespan. None of these values includes queueing or measures CPU time.

Optionally provide --jobs-json to report actual combined paired-job cost. Its file must contain runId, runAttempt and jobs from the attempt-specific Actions jobs endpoint. All five named jobs must have successful conclusions, matching run IDs and valid start/completion timestamps. The actual sum/max active-job time and observed job makespan include both treatments, shared setup, checkout, upload and post-actions; they cannot be assigned to either treatment. The observed span also includes staggered starts and does not establish a queue improvement. If these job records are absent, actualJobs is null and no actual whole-job cost is claimed.

One pair supplies directional evidence. A noisy result requires a deliberately counterbalanced follow-up, never a gain claim based on the training projection. Final evidence should state source/plan/training/holdout identities, full file and case census, all five wall times, both primary deltas and their limits.
