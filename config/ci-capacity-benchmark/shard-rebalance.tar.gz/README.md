# Standalone reversed-order shard-weight holdout

This is one additional full fixed-input pair in five jobs. It reverses each shard's order from run 37199891967 attempt 1: shards 1/3/5 run fresh then existing; shards 2/4 run existing then fresh. There is exactly one round. It does not repeat the original order inside these jobs.

The source remains `9574c8adb253c0e4084ad7697db16e7380f218d2`, tree `4d5487e8b827015ca53fad987a5d9e0606d124b5`. Existing/fresh weights, training provenance, five assignments, the entire normal 10,839-file census, Node 24.21.0, pnpm 12.8.1, four workers, original setup, source guards, cold-cache policy, raw reporters, case identity rules and hash checks are unchanged. Neither the first holdout nor this followup trains weights or changes assignments. All 291 E2E weights remain unchanged.

`armOrderByShard` freezes the explicit mapping. The shared validator rejects any mapping other than this exact reversal, any count other than one round, or a record whose position disagrees with its frozen shard order. Both the driver and comparer use that validator. `priorHoldout` binds the prior run, frozen manifest and sealed first-pair receipt; the new run must differ from both training and the first holdout. The original bundle and first-pair evidence remain untouched.

Runtime files are flat in this bundle. Root may publish the archive at `config/ci-capacity-benchmark/shard-rebalance.tar.gz` with `paired-workflow.yml` on a dedicated temporary branch. This preparation runs no tests, publishes nothing and dispatches nothing. Dry-run order previews use `python3 run-paired-shard.py --shard I --out /tmp/unused`; hosted execution additionally requires `--execute` and an exact clean Linux ARM Actions checkout.

Each arm starts with distinct empty Vite/Vitest result caches, filesystem transform caching disabled, and Node compile caching disabled. Every ordinary file, including the eight-case terminal batching qualification, runs in both assignments. The original BaseSequencer.sort stays unchanged. Real process deadlines and process-group cleanup stay unchanged. Default logs, module reports, raw JSON case reports, assignment and sort-order evidence, raw and canonical case ledgers, source/runtime/run identity, and per-arm exit/status/hash receipts remain mandatory.

After all five attempt-specific artifacts have been downloaded once, retained and digest-verified:

~~~sh
python3 /tmp/orca-ci-shard-rebalance-repaired-reversed-ready-20261004/compare-paired-shards.py \
  /tmp/reversed-rebalance-unit-artifacts \
  --bundle /tmp/orca-ci-shard-rebalance-repaired-reversed-ready-20261004 \
  --out /tmp/reversed-rebalance-result.json \
  --jobs-json /tmp/reversed-paired-job-metadata.json
~~~

The comparer directly revalidates every raw report and source/assignment/runtime/case/status/hash guard, requires all ten prepared shard/arm records and five setup records, verifies reversed positions, and compares complete canonical case multisets while preserving raw names. Only the three independently reviewed source-bound random title components use canonical identities; all other names/statuses remain exact.

Report total active test-process seconds, maximum shard process wall, module-phase elapsed diagnostics, shared setup estimates and actual combined paired-job cost separately. Actual jobs contain both arms and cannot be attributed to one assignment. Arms start at different times, so maximum shard process duration is not workflow makespan. Worker-phase elapsed sums are not CPU time. Queue/account-wide concurrency is unmeasured.

The first pair was valid but mixed: total active test time fell 1.321%, maximum shard wall rose 1.032%. It does not qualify a weight merge. The historical 3.0106% training projection is separate. Assess this deliberately reversed pair together with the preserved first pair; do not select a favorable arm or retrain from either holdout.
