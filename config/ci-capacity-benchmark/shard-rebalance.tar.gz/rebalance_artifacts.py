from collections import Counter
import hashlib
import json
import math
from pathlib import Path, PurePosixPath

from dynamic_case_title_identity import canonicalize_census, read_rules

ARMS = ('existing', 'fresh')


def arm_order(manifest, shard, round_index):
    assert manifest['rounds'] == 1 and round_index == 1, 'Standalone reversed pair has exactly one round'
    assert shard in range(1, 6)
    order = manifest['armOrderByShard'][str(shard)]
    assert isinstance(order, list) and len(order) == 2 and set(order) == set(ARMS)
    return list(order)


def validate_arm_position(record, manifest):
    assert record['treatment'] in ARMS
    expected = arm_order(manifest, record['shard'], record['round'])
    assert record['position'] == expected.index(record['treatment']) + 1, 'Wrong standalone reversed arm order'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def load_bundle(directory):
    directory = Path(directory)
    manifest_path = directory / 'holdout-manifest.json'
    manifest = read_json(manifest_path)
    assert manifest['version'] == 1 and manifest['workers'] == 4 and manifest['shards'] == 5
    assert manifest['rounds'] == 1, 'Standalone reversed pair has exactly one round'
    expected_orders = {str(shard): list(reversed(ARMS)) if shard % 2 else list(ARMS)
                       for shard in range(1, 6)}
    assert manifest['armOrderByShard'] == expected_orders, 'Require exact reversal of the first pair'
    assert manifest['priorHoldout']['runId'] == '37199891967' and manifest['priorHoldout']['runAttempt'] == '1'
    for name, expected in manifest['inputHashes'].items():
        assert sha((directory / name).read_bytes()) == expected, 'Frozen input differs: ' + name
    rules = read_rules(directory / 'dynamic-case-title-rules.json')
    expected_sources = {file: rule['sourceSha256'] for file, rule in rules['files'].items()}
    assert manifest['dynamicTitleSourceHashes'] == expected_sources
    assert set(expected_sources).issubset(manifest['files'])
    assert all(name in manifest['inputHashes'] for name in ['dynamic_case_title_identity.py', 'dynamic-case-title-rules.json', 'dynamic-title-identity-review.json'])
    plans = {arm: read_json(directory / (arm + '-assignment.json')) for arm in ARMS}
    files = manifest['files']
    assert files == sorted(set(files)) and files
    for arm, plan in plans.items():
        assert plan['sourceSha'] == manifest['sourceSha'] and plan['files'] == files
        assert plan['training'] == manifest['training']
        assert len(plan['shards']) == 5
        assigned = sorted(value for shard in plan['shards'] for value in shard['files'])
        assert assigned == files and len(set(assigned)) == len(assigned)
        assert sha((directory / (arm + '-weights.json')).read_bytes()) == plan['baselineSha256']
    return manifest, plans, sha(manifest_path.read_bytes())


def read_cases(report, checkout_root):
    assert report['success'] and report['numFailedTests'] == 0
    assert report['numFailedTestSuites'] == 0
    cases = {}
    checkout = PurePosixPath(checkout_root)
    for item in report['testResults']:
        value = PurePosixPath(item['name'].replace('\\', '/')).relative_to(checkout).as_posix()
        assert value not in cases, 'Duplicate JSON module: ' + value
        assert item['status'] == 'passed' and not item.get('message')
        entries = []
        for case in item['assertionResults']:
            assert case['status'] in ['passed', 'pending', 'skipped', 'todo']
            assert not case.get('failureMessages'), 'Case has failure messages: ' + case['fullName']
            entries.append([case['fullName'], case['status']])
        cases[value] = sorted(entries)
    assert sum(len(entries) for entries in cases.values()) == report['numTotalTests']
    assert sum(status == 'passed' for entries in cases.values() for _, status in entries) == report['numPassedTests']
    return cases


def validate_reports(directory, record, manifest, plan):
    directory = Path(directory)
    assert record['exitCode'] == 0 and not record['timedOut'] and record['sourceCleanAfter']
    assert record['sourceSha'] == manifest['sourceSha'] and record['sourceTreeGitOid'] == manifest['sourceTreeGitOid']
    assert record['workers'] == 4 and record['shard'] in range(1, 6)
    validate_arm_position(record, manifest)
    assert record['platformSystem'] == 'Linux' and record['platformMachine'].lower() in ['arm64', 'aarch64']
    assert record['node'].startswith('v24.') and record['runId'] and record['runAttempt']
    assert str(record['runId']) != str(manifest['training']['runId']), 'Holdout cannot be its training run'
    assert str(record['runId']) != str(manifest['priorHoldout']['runId']), 'Reversed pair must be a separate holdout run'
    assert isinstance(record['wallSeconds'], (float, int)) and math.isfinite(record['wallSeconds']) and record['wallSeconds'] > 0
    assert record['cacheStartedEmpty'] and record['filesystemTransformCache'] is False
    assert record['nodeCompileCache'] is False
    for name, expected in record['artifactHashes'].items():
        assert sha((directory / name).read_bytes()) == expected, 'Artifact bytes differ: ' + name
    required = {'vitest.json', 'unit-timings.json', 'unit-assignment.json', 'sort-order.json', 'case-census.json', 'canonical-case-census.json'}
    assert required.issubset(record['artifactHashes']), 'Missing mandatory artifact hash'
    selected = sorted(plan['shards'][record['shard'] - 1]['files'])
    assignment = read_json(directory / 'unit-assignment.json')
    assert assignment['selectedShard'] == record['shard'] and assignment['shards'] == plan['shards']
    assert assignment['baselineSha256'] == plan['baselineSha256'] and assignment['files'] == plan['files']
    assert assignment['training'] == plan['training']
    assert all(assignment.get(key) == value for key, value in plan.items())
    timings = read_json(directory / 'unit-timings.json')
    for witness in [assignment, timings]:
        assert witness['sourceSha'] == manifest['sourceSha']
        assert str(witness['runId']) == str(record['runId']) and str(witness['runAttempt']) == str(record['runAttempt'])
    assert timings['metric'] == 'module-duration-v1' and timings['nodeVersion'] == record['node'][1:]
    assert timings['shard'] == dict(index=record['shard'], count=5)
    assert timings['status'] == 'passed' and timings['unhandledErrors'] == 0
    assert sorted(timings['timings']) == selected and sorted(timings['results']) == selected
    assert all(value in ['passed', 'skipped'] for value in timings['results'].values())
    assert all(isinstance(value, (int, float)) and math.isfinite(value) and value > 0 for value in timings['timings'].values())
    order = read_json(directory / 'sort-order.json')
    assert sorted(order) == selected and len(set(order)) == len(order)
    cases = read_cases(read_json(directory / 'vitest.json'), record['checkoutRoot'])
    assert sorted(cases) == selected
    assert cases == read_json(directory / 'case-census.json')
    rules = read_rules(Path(__file__).resolve().parent / 'dynamic-case-title-rules.json')
    canonical_cases = canonicalize_census(cases, rules, manifest['dynamicTitleSourceHashes'])
    assert canonical_cases == read_json(directory / 'canonical-case-census.json')
    assert record['moduleCount'] == len(cases)
    assert record['caseCount'] == sum(len(entries) for entries in cases.values())
    assert record['moduleDurationSumMs'] == sum(timings['timings'].values())
    return canonical_cases, timings


def case_difference(before, after):
    left, right = Counter(tuple(value) for value in before), Counter(tuple(value) for value in after)
    return dict(removed=[list(value) for value in sorted((left - right).elements())],
                added=[list(value) for value in sorted((right - left).elements())])
