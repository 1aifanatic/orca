import argparse
from datetime import datetime
import json
import math
from pathlib import Path

from rebalance_artifacts import ARMS, case_difference, load_bundle, read_json, sha, validate_reports

parser = argparse.ArgumentParser()
parser.add_argument('artifacts')
parser.add_argument('--bundle', required=True)
parser.add_argument('--out', required=True)
parser.add_argument('--jobs-json')
args = parser.parse_args()
artifacts, bundle = Path(args.artifacts), Path(args.bundle)
manifest, plans, manifest_hash = load_bundle(bundle)
copies = list(artifacts.rglob('holdout-manifest.json'))
assert len(copies) == 5 and all(sha(path.read_bytes()) == manifest_hash for path in copies), 'Need five matching frozen bundle manifests'
records, cases, timings = {}, {}, {}
for path in artifacts.rglob('run-record.json'):
    record = read_json(path)
    assert record['valid'] and record['holdoutManifestSha256'] == manifest_hash, str(path)
    assert record['treatment'] in ARMS
    key = (record['round'], record['treatment'], record['shard'])
    assert key not in records, 'Duplicate treatment/shard/round record'
    assert record['planSha256'] == manifest['inputHashes'][record['treatment'] + '-assignment.json']
    census, modules = validate_reports(path.parent, record, manifest, plans[record['treatment']])
    records[key], cases[key], timings[key] = record, census, modules
expected_keys = {(round_index, arm, shard) for round_index in range(1, manifest['rounds'] + 1)
                 for arm in ARMS for shard in range(1, 6)}
assert set(records) == expected_keys, 'Require every prepared round and both complete five-shard arms'
assert len(set((record['runId'], record['runAttempt'], record['node'], record['pnpm'],
                record['platformSystem'], record['platformMachine']) for record in records.values())) == 1
provenance = next(iter(records.values()))
assert provenance['node'] == 'v' + manifest['nodeVersion'] and provenance['pnpm'] == manifest['pnpmVersion']
for record in records.values():
    existing_first = (record['shard'] + record['round'] - 1) % 2 == 1
    expected_position = 1 if (record['treatment'] == 'existing') == existing_first else 2
    assert record['position'] == expected_position, 'Wrong counterbalanced arm order'

setup_paths = list(artifacts.rglob('shared-setup.json'))
assert len(setup_paths) == 5, 'Require one setup record per paired shard job'
setup = {}
for path in setup_paths:
    record = read_json(path)
    assert record['shard'] in range(1, 6) and record['shard'] not in setup
    assert record['sourceSha'] == manifest['sourceSha']
    assert str(record['runId']) == str(provenance['runId']) and str(record['runAttempt']) == str(provenance['runAttempt'])
    assert isinstance(record['dependencySetupSeconds'], (float, int)) and math.isfinite(record['dependencySetupSeconds'])
    assert record['dependencySetupSeconds'] >= 0
    setup[record['shard']] = record['dependencySetupSeconds']

rows, deltas, common_cases = [], [], None
for round_index in range(1, manifest['rounds'] + 1):
    merged = {}
    round_rows = {}
    for arm in ARMS:
        census, walls, module_seconds = {}, [], 0
        for shard in range(1, 6):
            key = (round_index, arm, shard)
            walls.append(records[key]['wallSeconds'])
            module_seconds += sum(timings[key]['timings'].values()) / 1000
            for value, entries in cases[key].items():
                assert value not in census, 'File appeared in two shards: ' + value
                census[value] = entries
        assert sorted(census) == manifest['files'], 'Normal final-source files were omitted or added'
        merged[arm] = census
        row = dict(round=round_index, treatment=arm, shardTestProcessSeconds=walls,
                   totalActiveTestSeconds=sum(walls), maxShardProcessWallSeconds=max(walls),
                   sumModulePhaseSeconds=module_seconds, modules=len(census),
                   cases=sum(len(entries) for entries in census.values()),
                   commonDependencySetupSeconds=sum(setup.values()),
                   setupPlusTestEstimateSeconds=sum(setup.values()) + sum(walls),
                   maxSetupPlusTestEstimateSeconds=max(setup[index + 1] + walls[index] for index in range(5)))
        rows.append(row)
        round_rows[arm] = row
    for value in manifest['files']:
        difference = case_difference(merged['existing'][value], merged['fresh'][value])
        assert not difference['removed'] and not difference['added'], 'Case/status drift: ' + value + ': ' + json.dumps(difference)
    if common_cases is None:
        common_cases = merged['existing']
    else:
        assert common_cases == merged['existing'] == merged['fresh'], 'Case/status drift across rounds'
    existing, fresh = round_rows['existing'], round_rows['fresh']
    total_saved = existing['totalActiveTestSeconds'] - fresh['totalActiveTestSeconds']
    max_saved = existing['maxShardProcessWallSeconds'] - fresh['maxShardProcessWallSeconds']
    deltas.append(dict(round=round_index, totalActiveTestSecondsSaved=total_saved,
                       totalActiveTestSavingPercent=100 * total_saved / existing['totalActiveTestSeconds'],
                       maxShardProcessWallSecondsSaved=max_saved,
                       maxShardProcessSavingPercent=100 * max_saved / existing['maxShardProcessWallSeconds']))

actual_jobs = None
if args.jobs_json:
    payload = read_json(args.jobs_json)
    assert str(payload['runId']) == str(provenance['runId']) and str(payload['runAttempt']) == str(provenance['runAttempt'])
    jobs = [job for job in payload['jobs'] if job['name'].startswith('rebalance unit node 24 shard ')]
    assert len(jobs) == 5 and all(job['conclusion'] == 'success' for job in jobs)
    assert set(job['name'] for job in jobs) == {f'rebalance unit node 24 shard {index}/5' for index in range(1, 6)}
    assert all(str(job['run_id']) == str(provenance['runId']) for job in jobs)
    assert all(str(job.get('run_attempt', payload['runAttempt'])) == str(provenance['runAttempt']) for job in jobs)
    parse = lambda value: datetime.fromisoformat(value.replace('Z', '+00:00'))
    starts, ends = [parse(job['started_at']) for job in jobs], [parse(job['completed_at']) for job in jobs]
    active = [(end - start).total_seconds() for start, end in zip(starts, ends)]
    assert all(value > 0 for value in active)
    actual_jobs = dict(summedActualPairedJobActiveSeconds=sum(active),
                       maximumActualPairedJobActiveSeconds=max(active),
                       observedPairedJobMakespanSeconds=(max(ends) - min(starts)).total_seconds(),
                       scope='Both treatments, common setup, checkout, upload and post-actions; cannot be attributed to either assignment arm.')
result = dict(qualified=True, sourceSha=manifest['sourceSha'], sourceTreeGitOid=manifest['sourceTreeGitOid'],
              holdoutManifestSha256=manifest_hash, training=manifest['training'],
              holdoutRunId=provenance['runId'], holdoutRunAttempt=provenance['runAttempt'],
              normalFileCount=len(manifest['files']), fullCaseCount=sum(len(value) for value in common_cases.values()),
              canonicalCaseCensusSha256=sha(json.dumps(common_cases, sort_keys=True, separators=(',', ':')).encode()),
              rawCaseCensusSha256ByRecord={f'round-{round_index}/{arm}/shard-{shard}': record['artifactHashes']['case-census.json']
                                          for (round_index, arm, shard), record in sorted(records.items())},
              dynamicTitleIdentity=dict(moduleSha256=manifest['inputHashes']['dynamic_case_title_identity.py'],
                                        rulesSha256=manifest['inputHashes']['dynamic-case-title-rules.json'],
                                        sourceHashes=manifest['dynamicTitleSourceHashes']),
              planSha256={arm: manifest['inputHashes'][arm + '-assignment.json'] for arm in ARMS},
              e2eWeightsSha256=manifest['e2eSha256'], rounds=rows, pairedDeltas=deltas, actualJobs=actual_jobs,
              metricLimits=['Module phases are elapsed worker time, not CPU or job wall.',
                            'Test-process sums measure runner slots occupied during tests.',
                            'Arms start at different times; maximum shard process wall is not workflow makespan.',
                            'Common setup estimates are separate from actual paired-job cost.',
                            'Observed paired-job makespan includes staggered starts and is not attributable to an arm.',
                            'One holdout pair is directional evidence; queue/account-wide capacity is unmeasured.'])
Path(args.out).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['metricLimits', 'planSha256']}, indent=2))
