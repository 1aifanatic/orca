import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import time

from rebalance_artifacts import arm_order, load_bundle, read_cases, sha, validate_reports
from dynamic_case_title_identity import canonicalize_census, read_rules

parser = argparse.ArgumentParser()
parser.add_argument('--shard', type=int, choices=range(1, 6), required=True)
parser.add_argument('--out', required=True)
parser.add_argument('--execute', action='store_true')
args = parser.parse_args()
root, bundle, out = Path.cwd().resolve(), Path(__file__).resolve().parent, Path(args.out).resolve()
manifest, plans, manifest_hash = load_bundle(bundle)
orders = [arm_order(manifest, args.shard, round_index)
          for round_index in range(1, manifest['rounds'] + 1)]
if not args.execute:
    print(json.dumps(dict(dryRun=True, sourceSha=manifest['sourceSha'], shard=args.shard,
                         orders=orders, workers=4, normalFileCount=len(manifest['files']))))
    raise SystemExit(0)

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, timeout=30)

def clean_source():
    return (git('rev-parse', 'HEAD').decode().strip() == manifest['sourceSha'] and
            git('rev-parse', 'HEAD^{tree}').decode().strip() == manifest['sourceTreeGitOid'] and
            not git('diff', 'HEAD', '--name-only'))

def invoke(command, env, log):
    started = time.perf_counter()
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            status = process.wait(timeout=55 * 60)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            status = process.returncode
    return status, time.perf_counter() - started, timed_out

assert os.environ.get('GITHUB_ACTIONS') == 'true' and platform.system() == 'Linux'
assert platform.machine().lower() in ['arm64', 'aarch64'], 'Match the trained Linux ARM lane'
assert clean_source(), 'Use an exact clean final-source checkout'
case_identity_rules = read_rules(bundle / 'dynamic-case-title-rules.json')
for file, expected in manifest['dynamicTitleSourceHashes'].items():
    assert sha((root / file).read_bytes()) == expected, 'Case-title rule source differs: ' + file
assert not os.environ.get('NODE_COMPILE_CACHE'), 'Do not share a Node compile cache across arms'
run_id, run_attempt = os.environ.get('GITHUB_RUN_ID'), os.environ.get('GITHUB_RUN_ATTEMPT')
assert run_id and run_attempt and str(run_id) != str(manifest['training']['runId'])
assert str(run_id) != str(manifest['priorHoldout']['runId']), 'Reversed pair must be a separate holdout run'
node = subprocess.check_output(['node', '--version'], text=True).strip()
pnpm = subprocess.check_output(['pnpm', '--version'], text=True).strip()
assert node == 'v' + manifest['nodeVersion'], 'Use the same exact Node version as training'
assert pnpm == manifest['pnpmVersion']
assert out != root and root not in out.parents
out.mkdir(parents=True, exist_ok=True)
shutil.copyfile(bundle / 'holdout-manifest.json', out / 'holdout-manifest.json')
replacements = {
    "'__VITEST_NODE__'": json.dumps(str(root / 'node_modules/vitest/dist/node.js')),
    "'__ASSIGNMENT_MODULE__'": json.dumps(str(root / 'config/scripts/ci-shard-assignment.mjs')),
    "'__VITEST_CONFIG__'": json.dumps(str(root / 'node_modules/vitest/dist/config.js')),
    "'__BASE_CONFIG__'": json.dumps(str(root / 'config/vitest.config.ts'))
}
for template, name in [('frozen-assignment-sequencer.template.mjs', 'frozen-assignment-sequencer.mjs'),
                       ('paired.config.template.ts', 'paired.config.ts')]:
    text = (bundle / template).read_text()
    for pattern, replacement in replacements.items():
        text = text.replace(pattern, replacement)
    (out / name).write_text(text)

records = []
for round_index, order in enumerate(orders, start=1):
    for position, arm in enumerate(order, start=1):
        assert clean_source(), 'Source changed before arm'
        load_bundle(bundle)
        directory = out / ('round-' + str(round_index)) / arm
        assert not directory.exists(), 'Do not mix a prior run with this arm'
        directory.mkdir(parents=True)
        cache = directory / 'vite-cache'
        cache.mkdir()
        assert not list(cache.iterdir())
        plan = plans[arm]
        env = os.environ.copy()
        env.update(ORCA_BACKGROUND_LAUNCH='1', ORCA_BALANCE_UNIT_SHARDS='1',
                   ORCA_SHARD_SOURCE_SHA=manifest['sourceSha'],
                   ORCA_FROZEN_UNIT_PLAN=str(bundle / (arm + '-assignment.json')),
                   ORCA_UNIT_SELECTION_PLAN=str(bundle / 'unit-selection.json'),
                   ORCA_SHARD_MANIFEST=str(directory / 'unit-assignment.json'),
                   ORCA_UNIT_TIMING_REPORT=str(directory / 'unit-timings.json'),
                   ORCA_UNIT_SORT_LOG=str(directory / 'sort-order.json'),
                   ORCA_REBALANCE_CACHE_DIR=str(cache),
                   ORCA_REBALANCE_JSON_REPORT=str(directory / 'vitest.json'),
                   NODE_DISABLE_COMPILE_CACHE='1')
        command = ['pnpm', 'exec', 'vitest', 'run', '--config', str(out / 'paired.config.ts'),
                   '--shard=' + str(args.shard) + '/5', '--maxWorkers=4']
        status, elapsed, timed_out = invoke(command, env, directory / 'vitest.log')
        record = dict(round=round_index, position=position, treatment=arm, shard=args.shard,
                      sourceSha=manifest['sourceSha'], sourceTreeGitOid=manifest['sourceTreeGitOid'],
                      holdoutManifestSha256=manifest_hash,
                      planSha256=manifest['inputHashes'][arm + '-assignment.json'],
                      checkoutRoot=root.as_posix(), workers=4, node=node, pnpm=pnpm,
                      platformSystem=platform.system(), platformMachine=platform.machine(),
                      runId=run_id, runAttempt=run_attempt, exitCode=status, timedOut=timed_out,
                      wallSeconds=elapsed, sourceCleanAfter=bool(clean_source()),
                      cacheStartedEmpty=True, filesystemTransformCache=False,
                      nodeCompileCache=False, artifactHashes={}, valid=False)
        try:
            cases = read_cases(json.loads((directory / 'vitest.json').read_text()), record['checkoutRoot'])
            (directory / 'case-census.json').write_text(json.dumps(cases, indent=2) + '\n')
            canonical_cases = canonicalize_census(cases, case_identity_rules, manifest['dynamicTitleSourceHashes'])
            (directory / 'canonical-case-census.json').write_text(json.dumps(canonical_cases, indent=2) + '\n')
            required = ['vitest.json', 'unit-timings.json', 'unit-assignment.json', 'sort-order.json', 'case-census.json', 'canonical-case-census.json']
            record.update(artifactHashes={name: sha((directory / name).read_bytes()) for name in required},
                          moduleCount=len(cases), caseCount=sum(len(value) for value in cases.values()),
                          moduleDurationSumMs=sum(json.loads((directory / 'unit-timings.json').read_text())['timings'].values()))
            validate_reports(directory, record, manifest, plan)
            record['valid'] = True
        except (AssertionError, KeyError, FileNotFoundError, json.JSONDecodeError, ValueError) as error:
            record['validationError'] = str(error)
        records.append(record)
        (directory / 'run-record.json').write_text(json.dumps(record, indent=2) + '\n')
        (out / 'shard-summary.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps({key: value for key, value in record.items() if key != 'artifactHashes'}), flush=True)
        assert record['sourceCleanAfter'], 'Tests changed tracked source; further arms refused'
if not all(record['valid'] for record in records):
    raise SystemExit('Incomplete or invalid holdout; no gain is qualified')
