import { readFileSync, writeFileSync } from 'node:fs'
import { relative } from 'node:path'
import { BaseSequencer } from '__VITEST_NODE__'
import { writeAssignment } from '__ASSIGNMENT_MODULE__'

export default class FrozenAssignmentSequencer extends BaseSequencer {
  async shard(specs) {
    const plan = JSON.parse(readFileSync(process.env.ORCA_FROZEN_UNIT_PLAN, 'utf8'))
    const { index, count } = this.ctx.config.shard
    const key = (spec) => relative(this.ctx.config.root, spec.moduleId).replaceAll('\\', '/')
    const files = specs.map(key).sort()
    if (plan.sourceSha !== process.env.ORCA_SHARD_SOURCE_SHA || count !== 5 ||
        plan.shards.length !== count || index < 1 || index > count ||
        JSON.stringify(files) !== JSON.stringify(plan.files)) {
      throw new Error('Frozen assignment source, count or independent discovery differs')
    }
    const assigned = plan.shards.flatMap((shard) => shard.files).sort()
    if (JSON.stringify(assigned) !== JSON.stringify(files) || new Set(assigned).size !== assigned.length) {
      throw new Error('Frozen assignments must cover every trial file exactly once')
    }
    writeAssignment(process.env.ORCA_SHARD_MANIFEST, { ...plan, selectedShard: index })
    const allowed = new Set(plan.shards[index - 1].files)
    return specs.filter((spec) => allowed.has(key(spec)))
  }

  async sort(specs) {
    const sorted = await super.sort(specs)
    if (process.env.ORCA_UNIT_SORT_LOG) {
      writeFileSync(process.env.ORCA_UNIT_SORT_LOG, JSON.stringify(sorted.map((spec) =>
        relative(this.ctx.config.root, spec.moduleId).replaceAll('\\', '/'))))
    }
    return sorted
  }
}
