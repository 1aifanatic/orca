import argparse
import json
from pathlib import Path

from cursor_artifacts import compare, sha

parser = argparse.ArgumentParser()
parser.add_argument('artifacts', type=Path)
parser.add_argument('--bundle', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--run-json', type=Path, required=True)
parser.add_argument('--jobs-json', type=Path, required=True)
args = parser.parse_args()
run_bytes = args.run_json.read_bytes()
jobs_bytes = args.jobs_json.read_bytes()
result = compare(args.artifacts.resolve(), args.bundle.resolve(), json.loads(run_bytes), json.loads(jobs_bytes))
result.update(runMetadataSha256=sha(run_bytes), jobsMetadataSha256=sha(jobs_bytes))
args.out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
