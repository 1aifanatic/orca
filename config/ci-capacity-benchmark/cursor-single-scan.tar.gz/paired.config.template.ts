import { defineConfig } from '__VITEST_CONFIG__'
import base from '__BASE_CONFIG__'

if (base.test?.experimental?.fsModuleCache) {
  throw new Error('This trial keeps the filesystem transform cache disabled')
}
export default defineConfig({
  ...base,
  cacheDir: process.env.ORCA_CURSOR_PAIR_CACHE,
  test: {
    ...base.test,
    experimental: { ...base.test?.experimental, fsModuleCache: false },
    reporters: ['default', 'json'],
    outputFile: { json: process.env.ORCA_CURSOR_PAIR_REPORT }
  }
})
