import collections
from datetime import datetime
import hashlib
import json
from pathlib import Path

ARMS = ('original', 'candidate')
ORDERS = (('original', 'candidate'), ('candidate', 'original'), ('original', 'candidate'))
REQUIRED_ARTIFACTS = ('vitest.json', 'vitest.log', 'case-census.json', 'title-multiplicity.json', 'command.json',
                      'source-before-overlay.json', 'source-overlay.json', 'source-after-invocation.json',
                      'source-after-restoration.json')


def sha(contents):
    return hashlib.sha256(contents).hexdigest()


def load_bundle(bundle):
    manifest_path = bundle / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['schemaVersion'] == 1
    assert manifest['sourceSha'] == '1bec53ceb23b5f296a38ffa0e085778d32fc7849'
    assert manifest['sourcePath'] == 'src/shared/terminal-cursor-line-context.ts'
    assert manifest['testPath'] == 'src/main/runtime/readiness-census-transcripts-6.test.ts'
    assert manifest['nodeVersion'] == '24.21.0' and manifest['pnpmVersion'] == '12.8.1'
    assert manifest['workers'] == 1 and manifest['invocationTimeoutSeconds'] == 180
    assert manifest['rounds'] == 3 and manifest['expectedCaseCount'] == 49
    assert manifest['orders'] == [list(order) for order in ORDERS]
    names = set(manifest['inputHashes']) | {'manifest.json'}
    actual = {path.name for path in bundle.iterdir() if path.is_file()}
    assert actual == names, 'Missing or unexpected portable bundle files'
    for name, expected in manifest['inputHashes'].items():
        assert Path(name).name == name, 'Portable asset must be top level'
        assert sha((bundle / name).read_bytes()) == expected, 'Bundle changed: ' + name
    assert manifest['originalSha256'] == manifest['inputHashes']['original.source']
    assert manifest['candidateSha256'] == manifest['inputHashes']['candidate.source']
    assert manifest['originalSha256'] == '3460d202cbf08a5282d7aa3ef8b01b11efa6b1785eee1e1420dedc1843399049'
    assert manifest['candidateSha256'] == 'b654cb62db02c983d06aead30afdb9a0dee5565a024caeda79504ec178ac2064'
    assert manifest['sourceTreeGitOid'] == '8dda0783bd3355b2ae8068b9ca4e3e21f65240e8'
    expected_cases = json.loads((bundle / 'expected-cases.json').read_text())
    assert len(expected_cases) == 49 and all(case['status'] == 'passed' for case in expected_cases)
    guards = json.loads((bundle / 'source-guards.json').read_text())
    assert guards[manifest['sourcePath']]['sha256'] == manifest['originalSha256']
    return manifest, expected_cases, guards, sha(manifest_path.read_bytes())


def read_cases(report, root, test_path):
    modules = report['testResults']
    assert len(modules) == 1, 'Only the unchanged census suite6 module may execute'
    module = modules[0]
    assert module['name'] == str(root / test_path), 'Raw report names a different test file'
    assert module['status'] == 'passed' and not module.get('message', '')
    cases = []
    for case in module['assertionResults']:
        assert not case.get('failureMessages', [])
        cases.append({key: case[key] for key in ['ancestorTitles', 'fullName', 'status', 'title']})
    return sorted(cases, key=lambda case: json.dumps(case, sort_keys=True))


def validate_report(directory, record, manifest, expected_cases, write_census=False):
    assert record['exitCode'] == 0 and not record['timedOut']
    assert record['sourceCleanBeforeOverlay'] and record['sourceCleanAfterRestoration']
    assert record['sourceOverlayIntactAfterInvocation']
    assert record['sourceHeadBefore'] == manifest['sourceSha']
    assert record['sourceHeadAfter'] == manifest['sourceSha']
    assert record['sourceTreeBefore'] == manifest['sourceTreeGitOid']
    assert record['sourceTreeAfter'] == manifest['sourceTreeGitOid']
    assert record['filesystemTransformCache'] is False and record['nodeCompileCache'] is False
    assert record['cacheStartedEmpty'] is True and record['workers'] == 1
    assert record['node'] == 'v' + manifest['nodeVersion']
    assert record['pnpm'] == manifest['pnpmVersion']
    assert record['wallSeconds'] > 0
    report = json.loads((directory / 'vitest.json').read_text())
    assert report['success'] is True
    assert report['numTotalTests'] == 49 and report['numPassedTests'] == 49
    assert report['numFailedTests'] == 0 and report['numPendingTests'] == 0
    assert report.get('numTodoTests', 0) == 0
    assert report['numFailedTestSuites'] == 0 and report['numPendingTestSuites'] == 0
    assert report.get('numUnhandledErrors', 0) == 0
    snapshots = report['snapshot']
    assert snapshots['didUpdate'] is False and snapshots['failure'] is False
    assert snapshots['added'] == 0 and snapshots['updated'] == 0 and snapshots['unmatched'] == 0
    log = (directory / 'vitest.log').read_text(errors='replace')
    assert not any(marker in log for marker in ['Unhandled Errors', 'Unhandled Rejection', 'Uncaught Exception'])
    cases = read_cases(report, Path(record['checkoutRoot']), manifest['testPath'])
    expected = sorted(expected_cases, key=lambda case: json.dumps(case, sort_keys=True))
    assert cases == expected, 'Case titles/status/ancestry/multiplicity changed'
    assert len(cases) == 49
    census = json.dumps(cases, indent=2) + '\n'
    multiplicity = sorted(collections.Counter(case['fullName'] for case in cases).items())
    multiplicity_text = json.dumps(multiplicity, indent=2) + '\n'
    if write_census:
        (directory / 'case-census.json').write_text(census)
        (directory / 'title-multiplicity.json').write_text(multiplicity_text)
    else:
        assert (directory / 'case-census.json').read_text() == census
        assert (directory / 'title-multiplicity.json').read_text() == multiplicity_text
    return cases


def compare(directory, bundle, run_metadata=None, jobs_metadata=None, preliminary=False):
    manifest, expected_cases, guards, manifest_hash = load_bundle(bundle)
    failure_markers = sorted(str(path.relative_to(directory)) for path in directory.rglob('*.json')
                             if path.name.endswith(('-failure.json', '-failed.json', '-refused.json')))
    assert not failure_markers, 'Failure or restoration refusal evidence present: ' + ', '.join(failure_markers)
    records = json.loads((directory / 'summary.json').read_text())
    assert len(records) == 6, 'Require all three healthy original/candidate pairs'
    assert sha((directory / 'manifest.json').read_bytes()) == manifest_hash
    assert records[0]['runId'] and records[0]['runAttempt']
    assert len({(row['runId'], row['runAttempt'], row['node'], row['pnpm'], row['platformSystem'], row['platformMachine']) for row in records}) == 1
    assert records[0]['platformSystem'] == 'Linux'
    assert records[0]['platformMachine'].lower() in ['aarch64', 'arm64']
    runtime = json.loads((directory / 'runtime.json').read_text())
    assert runtime['manifestSha256'] == manifest_hash
    assert runtime['runId'] == records[0]['runId'] and runtime['runAttempt'] == records[0]['runAttempt']
    final = json.loads((directory / 'final-source.json').read_text())
    assert final['runId'] == records[0]['runId'] and final['runAttempt'] == records[0]['runAttempt']
    assert final['manifestSha256'] == manifest_hash
    assert final['head'] == manifest['sourceSha'] and final['tree'] == manifest['sourceTreeGitOid']
    assert final['status'] == '' and final['changedPaths'] == [] and final['stagedPaths'] == []
    assert final['sourceSha256'] == manifest['originalSha256']
    assert isinstance(final['capturedAtUnixMs'], int) and final['capturedAtUnixMs'] > 0
    config_hash = sha((directory / 'paired.config.ts').read_bytes())
    expected_config = (bundle / 'paired.config.template.ts').read_text()
    checkout_root = Path(records[0]['checkoutRoot'])
    expected_config = expected_config.replace("'__VITEST_CONFIG__'", json.dumps(str(checkout_root / 'node_modules/vitest/dist/config.js')))
    expected_config = expected_config.replace("'__BASE_CONFIG__'", json.dumps(str(checkout_root / 'config/vitest.config.ts')))
    assert (directory / 'paired.config.ts').read_text() == expected_config
    pairs = []
    for round_index, order in enumerate(ORDERS, 1):
        pair = {}
        for position, arm in enumerate(order, 1):
            index = (round_index - 1) * 2 + position - 1
            record = records[index]
            assert record['round'] == round_index and record['position'] == position
            assert record['arm'] == arm and record['valid'] is True
            assert not any(key in record for key in ['invocationError', 'validationError', 'restorationError'])
            assert record['manifestSha256'] == manifest_hash
            expected_source = manifest[arm + 'Sha256']
            assert record['overlaySha256'] == expected_source
            assert record['configSha256'] == config_hash
            arm_dir = directory / f'round-{round_index}' / arm
            assert json.loads((arm_dir / 'run-record.json').read_text()) == record
            assert set(record['artifactHashes']) == set(REQUIRED_ARTIFACTS)
            for name, digest in record['artifactHashes'].items():
                assert sha((arm_dir / name).read_bytes()) == digest, 'Artifact changed: ' + name
            for name, overlay in [('source-before-overlay.json', False), ('source-overlay.json', arm == 'candidate'),
                                  ('source-after-invocation.json', arm == 'candidate'), ('source-after-restoration.json', False)]:
                state = json.loads((arm_dir / name).read_text())
                assert state['head'] == manifest['sourceSha'] and state['tree'] == manifest['sourceTreeGitOid']
                assert state['stagedPaths'] == []
                assert state['changedPaths'] == ([manifest['sourcePath']] if overlay else [])
                assert state['status'] == (' M ' + manifest['sourcePath'] if overlay else '')
            command = json.loads((arm_dir / 'command.json').read_text())
            expected_argv = ['pnpm', 'exec', 'vitest', 'run', '--config', str(directory / 'paired.config.ts'),
                             manifest['testPath'], '--maxWorkers', '1', '--experimental.fsModuleCache=false']
            # Artifact download paths differ; the original command points to its recorded runner output root.
            runner_config = command['argv'][5]
            assert Path(runner_config).name == 'paired.config.ts'
            expected_argv[5] = runner_config
            assert command['argv'] == expected_argv and command['cwd'] == record['checkoutRoot']
            assert command['environment']['ORCA_BACKGROUND_LAUNCH'] == '1'
            assert command['environment']['UPDATE_READINESS_CENSUS'] == '0'
            assert command['environment']['ORCA_BALANCE_UNIT_SHARDS'] == '0'
            assert command['environment']['NODE_DISABLE_COMPILE_CACHE'] == '1'
            assert command['NODE_COMPILE_CACHEPresent'] is False and command['timeoutSeconds'] == 180
            validate_report(arm_dir, record, manifest, expected_cases)
            pair[arm] = record['wallSeconds']
        pairs.append({'round': round_index, 'order': list(order), **pair,
                      'pairedSavingSeconds': pair['original'] - pair['candidate'],
                      'pairedSavingPercent': (pair['original'] - pair['candidate']) / pair['original'] * 100})
    import statistics
    terminal = None
    if preliminary:
        assert run_metadata is None and jobs_metadata is None
    else:
        assert run_metadata is not None and jobs_metadata is not None, 'Actual completed run and attempt-specific jobs metadata required'
        run = run_metadata
        jobs_payload = jobs_metadata
        assert str(run['id']) == records[0]['runId'] and str(run['run_attempt']) == records[0]['runAttempt']
        assert run['status'] == 'completed' and run['conclusion'] == 'success'
        assert run['event'] == 'workflow_dispatch'
        assert run['path'].split('@', 1)[0] == manifest['workflowDestination']
        assert str(jobs_payload['runId']) == records[0]['runId'] and str(jobs_payload['runAttempt']) == records[0]['runAttempt']
        jobs = jobs_payload['jobs']
        assert len(jobs) == 1 and jobs_payload.get('total_count', 1) == 1
        job = jobs[0]
        assert job['name'] == 'cursor scan suite6 paired node24 ARM'
        assert str(job['run_id']) == records[0]['runId'] and str(job['run_attempt']) == records[0]['runAttempt']
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        started_ms = datetime.fromisoformat(job['started_at'].replace('Z', '+00:00')).timestamp() * 1000
        completed_ms = datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00')).timestamp() * 1000
        assert started_ms <= completed_ms
        assert started_ms - 30_000 <= final['capturedAtUnixMs'] <= completed_ms + 30_000
        bootstrap = json.loads((directory / 'bootstrap.json').read_text())
        assert bootstrap['runId'] == records[0]['runId'] and bootstrap['runAttempt'] == records[0]['runAttempt']
        assert bootstrap['bootstrapSha'] == run['head_sha'] and bootstrap['eventSha'] == run['head_sha']
        assert runtime['bootstrapEventSha'] == run['head_sha']
        shared = json.loads((directory / 'shared-setup.json').read_text())
        checkout = json.loads((directory / 'checkout.json').read_text())
        for value in [shared, checkout]:
            assert value['runId'] == records[0]['runId'] and value['runAttempt'] == records[0]['runAttempt']
            assert value['sourceSha'] == manifest['sourceSha'] and value['sourceTree'] == manifest['sourceTreeGitOid']
        assert checkout['sourceStatus'] == ''
        assert shared['node'] == records[0]['node'] and shared['pnpm'] == records[0]['pnpm']
        assert shared['platformSystem'] == 'Linux' and shared['platformMachine'].lower() in ['aarch64', 'arm64']
        report_windows = []
        for round_index, order in enumerate(ORDERS, 1):
            for arm in order:
                report = json.loads((directory / f'round-{round_index}' / arm / 'vitest.json').read_text())
                report_start = report['startTime']
                report_end = report['testResults'][0]['endTime']
                assert started_ms - 30_000 <= report_start <= report_end <= final['capturedAtUnixMs']
                assert report_end <= completed_ms + 30_000
                report_windows.append([report_start, report_end])
        assert all(left[1] <= right[0] for left, right in zip(report_windows, report_windows[1:])), 'Reported invocations overlap or run order changed'
        terminal = {'runId': str(run['id']), 'runAttempt': str(run['run_attempt']), 'runStatus': run['status'],
                    'runConclusion': run['conclusion'], 'bootstrapSha': run['head_sha'], 'jobId': str(job['id']),
                    'jobName': job['name'], 'jobStatus': job['status'], 'jobConclusion': job['conclusion'],
                    'jobStartedAt': job['started_at'], 'jobCompletedAt': job['completed_at']}
    return {'status': 'preliminary' if preliminary else 'passed',
            'qualification': 'Preliminary inside running job; terminal job outcome remains unobserved.' if preliminary else 'All six healthy reports, final source restoration and actual terminal successful run/job metadata verified.',
            'sourceSha': manifest['sourceSha'], 'sourceTreeGitOid': manifest['sourceTreeGitOid'],
            'manifestSha256': manifest_hash, 'runId': records[0]['runId'], 'runAttempt': records[0]['runAttempt'],
            'pairs': pairs, 'medianOriginalSeconds': statistics.median(row['original'] for row in pairs),
            'medianCandidateSeconds': statistics.median(row['candidate'] for row in pairs),
            'medianPairedSavingSeconds': statistics.median(row['pairedSavingSeconds'] for row in pairs),
            'medianPairedSavingPercent': statistics.median(row['pairedSavingPercent'] for row in pairs),
            'terminalMetadata': terminal,
            'finalSourceSha256': sha((directory / 'final-source.json').read_bytes()),
            'limitation': 'One fixed focused suite workload; no full-shard, PR latency, queue or organization capacity forecast.'}
