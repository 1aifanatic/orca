# Prepared fused cursor scan timing bundle

This bundle prepares one manual Linux ARM job. It does not authorize dispatch or qualify rollout. Root publishes these assets only after complete semantic review and qualification; the current visible-read trace investigation remains separate. No primary worktree files were changed to prepare the bundle.

The fixed source is `1bec53ceb23b5f296a38ffa0e085778d32fc7849`, the parent of the local dashboard branch. Source/tree identity, raw named-blob input guards, original/candidate source hashes and exact unchanged suite6 census are recorded in the manifest and supporting ledgers.

The six complete one-worker Vitest invocations use these pair orders:

1. Original, candidate.
2. Candidate, original.
3. Original, candidate.

All 49 ordinary cases run in every invocation. No capture wrapper, mutation, proposed new test or updated readiness baseline enters timing. Each invocation starts with a distinct empty Vite cache, filesystem transform caching explicitly disabled, `NODE_DISABLE_COMPILE_CACHE=1`, no `NODE_COMPILE_CACHE`, and the existing config/setup modules. Node is exactly 24.21.0 and pnpm exactly 12.8.1.

The runner first checks out the benchmark support branch, safely extracts the top-level bundle outside the repository, records bootstrap SHA/tree/run/archive hash and copies every input into upload evidence. It then checks out the fixed source, runs the existing dependency installer with the Node native runtime and Electron archive cache, and installs the Electron package binary with the existing script. Shared dependency setup is recorded separately from timing.

The driver requires a clean fixed checkout before each overlay and after restoring it. The sole temporary tracked change is the frozen cursor source for candidate invocations. Source bytes, guarded input modes and all tracked/untracked changes are checked before and after each invocation. Unknown concurrent source bytes, missing/symlink paths or a changed checkout are preserved and reject the run. Outputs and generated config live outside the checkout.

Each invocation has a real 180-second deadline. The owned process group is created with `start_new_session=True`; timeout sends TERM, waits at most five seconds, then sends KILL to the original group even if its leader exited. Interrupted invocations also terminate their owned group. Raw logs/reports, commands, overlay/source records, per-arm records, available hashes and a failure record are retained on rejection. The complete GitHub job has a 45-minute cap and always uploads evidence, including failed setup runs after extraction.

All six reports must succeed with exactly the same 49 full titles, ancestors, individual titles, passed statuses and multiplicities. Zero pending, todo, failed or unhandled errors and no snapshot updates are required. Raw report/log/census/multiplicity and source-record bytes are hashed. No title normalization applies. The comparer refuses partial or unhealthy pairs, conflicting run/attempt/toolchain/platform tuples, changed manifests or changed raw evidence. It also requires the final clean source/tree/original bytes and matching run/attempt/manifest recorded after outer cleanup, and rejects all failure/refusal marker files. It reports all pair walls, original/candidate medians and median paired differences.

Inside-job comparison runs only after successful outer `finally`, writes `preliminary-comparison.json` and explicitly records that the terminal job outcome remains unobserved. External qualification additionally requires the actual completed successful GitHub run and its attempt-specific completed successful job metadata. It binds the bootstrap commit, the fixed-source checkout/setup records, raw report time windows and final-source time to that physical job. A passing preliminary file alone cannot qualify a hosted result.

Run the completed-artifact comparer with:

```sh
python3 compare-paired-cursor.py ARTIFACT_DIRECTORY --bundle BUNDLE_DIRECTORY \
  --run-json RUN_JSON --jobs-json ATTEMPT_JOBS_JSON --out RESULT_JSON
```

This measures a fixed focused workload, not full-shard, PR, queue or organization concurrency improvement. Estimated cost is roughly 6–8 test runner minutes plus shared installation/upload overhead; those are trial costs, not expected savings. Actual normal Linux PR gates and complete semantic/consumer evidence qualify separately.

`RUN_JSON` is the raw GitHub Actions run API response. `ATTEMPT_JOBS_JSON` contains `{ "runId": "…", "runAttempt": "…", "total_count": 1, "jobs": […] }` with unmodified snake_case jobs from the run's attempt-specific jobs endpoint. The sole expected job name is `cursor scan suite6 paired node24 ARM`. The external receipt hashes both metadata inputs. Do not substitute live/incomplete metadata, a later attempt or camelCase display summaries.

The manual workflow replaces the existing registered `ci-pnpm-verification-pilot.yml` only on an isolated TEMP benchmark branch. Package only the exact top-level files listed in `manifest.json`; do not merge or publish this temporary workflow/archive as a production CI change. Python bytecode or result directories are excluded.

Prepared guard design: source/tree/mode/case/hash mismatch; partial/failing/pending/todo/error reports; changed title ancestry/status/multiplicity; nonempty shared cache; wrong toolchain/platform; changed config/bundle; extra tracked/untracked edits; original leader exit after TERM with a lingering owned child. These guards need review and appropriate isolated controls before dispatch. No test, timing or deadline control was run by this preparation agent.
