import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const output = resolve(process.argv[2] || join(root, 'artifacts/profile-binary-benchmark'))
const bundle = import.meta.dirname
const controlsOnly = process.argv.includes('--controls-only')
const files = JSON.parse(readFileSync(join(bundle, 'files.json'), 'utf8'))
const candidate = new Map(files.map((file) => [file, readFileSync(join(root, file), 'utf8')]))
const baseline = new Map(files.map((file) => [file, readFileSync(join(bundle, 'baseline', file), 'utf8')]))
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const digest = (data) => createHash('sha256').update(data).digest('hex')
mkdirSync(output, { recursive: true })
function install(arm) { for (const [file, source] of arm) writeFileSync(join(root, file), source) }
function execute(label, selectedFiles = files, extraArgs = [], allowFailure = false) {
  const reportPath = join(output, `${label}.json`)
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, 'test', ...selectedFiles, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], cwd: root, env: { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  const wallMs = performance.now() - started
  if (!allowFailure) assert.equal(result.code, 0, describeProcessFailure(result))
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  const tests = report.testResults.flatMap((file) => file.assertionResults)
  return { label, wallMs, bodyMs: tests.reduce((sum, test) => sum + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, failures: report.numFailedTests, cases: tests.map((test) => ({ name: test.fullName, status: test.status })).sort((a, b) => a.name.localeCompare(b.name)), witnesses: tests.filter((test) => test.status === 'failed').map((test) => test.fullName) }
}
try {
  const samples = []
  let expectedCases
  for (let pair = 1; !controlsOnly && pair <= 3; pair++) {
    for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
      install(arm === 'baseline' ? baseline : candidate)
      const run = execute(`${arm}-${pair}`)
      assert.equal(run.failures, 0)
      if (!expectedCases) expectedCases = run.cases
      assert.deepEqual(run.cases, expectedCases)
      samples.push({ pair, arm, ...run })
      console.log(JSON.stringify({ pair, arm, wallMs: run.wallMs, bodyMs: run.bodyMs, passes: run.passes, skips: run.skips }))
    }
  }
  const summary = {
    environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion },
    hashes: { baseline: Object.fromEntries([...baseline].map(([file, source]) => [file, digest(source)])), candidate: Object.fromEntries([...candidate].map(([file, source]) => [file, digest(source)])) },
    samples
  }
  if (!controlsOnly) {
    summary.baseline = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs))
    summary.candidate = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs))
    summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
  }
  const negativeControls = []
  const witnessNames = [
    'mutates, flushes, and reloads without writing the legacy JSON file',
    'backs up a selective sync commit without rewriting retained JSON',
    'a mismatched stored hash',
    'requires explicit recovery for unreleased schema 1 without changing its bytes',
    'publishes a hardened self-contained snapshot including committed WAL pages',
    'latches a future schema read-only without changing the database file'
  ]
  const mutationMarker = /expect\((readFileSync\([^\n]+\))\.equals\(([^\n]+)\)\)\.toBe\(true\)/
  for (const [index, file] of files.entries()) {
    install(candidate)
    const source = candidate.get(file)
    assert(mutationMarker.test(source), `missing byte assertion: ${file}`)
    const fault = source.replace(mutationMarker, 'expect(corruptFinalByte($1).equals($2)).toBe(true)') + `\nfunction corruptFinalByte(bytes: Buffer): Buffer {
  const damaged = Buffer.from(bytes)
  damaged[damaged.length - 1] ^= 1
  return damaged
}\n`
    writeFileSync(join(root, file), fault)
    const run = execute(`negative-last-byte-${index + 1}`, [file], ['--testNamePattern', witnessNames[index]], true)
    assert.equal(run.failures, 1, `last-byte fault survived or selected extra cases: ${file}`)
    negativeControls.push({ name: 'last-byte', file, failures: run.failures, witnesses: run.witnesses })
  }
  install(candidate)
  const file = files[5]
  const source = candidate.get(file)
  const fault = source.replace(mutationMarker, 'expect($1.subarray(0, $1.length - 1).equals($2)).toBe(true)')
  writeFileSync(join(root, file), fault)
  const run = execute('negative-missing-last-byte', [file], ['--testNamePattern', witnessNames[5]], true)
  assert.equal(run.failures, 1, 'length mismatch fault survived')
  negativeControls.push({ name: 'missing-last-byte', file, failures: run.failures, witnesses: run.witnesses })
  summary.negativeControls = negativeControls
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
  console.log(JSON.stringify({ baseline: summary.baseline, candidate: summary.candidate, changePercent: summary.changePercent, negativeControls }))
} finally { install(candidate) }
