import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
target = root / 'src/main/opencode/hook-plugin-opencode2-tui-ownership.test.ts'
candidate = bundle / 'candidate-hook-plugin-opencode2-tui-ownership.test.ts'
production = json.loads((bundle / 'production-source-hashes.json').read_text())
hashes = json.loads((bundle / 'source-hashes.json').read_text())
original = target.read_bytes()
assert hashlib.sha256(original).hexdigest() == hashes['candidate'], 'Live test must be frozen candidate'
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == hashes['candidate']
for path, expected in production.items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path

source = candidate.read_text()
needle = 'writeFileSync(pluginPath, _internals.getOpenCodePluginSource())'
assert source.count(needle) == 1
controls = [
    ('poll-period', 'const TUI_TICK_MS = 100;', 'const TUI_TICK_MS = 101;',
     'settles an owned turn once the session data says it ended'),
    ('permission-early', 'const TUI_PERMISSION_SETTLE_MS = 500;', 'const TUI_PERMISSION_SETTLE_MS = 400;',
     "shows a child's permission as Needs input"),
    ('permission-late', 'const TUI_PERMISSION_SETTLE_MS = 500;', 'const TUI_PERMISSION_SETTLE_MS = 501;',
     "shows a child's permission as Needs input"),
    ('reload-memory', 'return ctx.storage.memory("pane-status", { initial });',
     'return (() => { const reset = structuredClone(initial); return [reset, (mutate) => mutate(reset)]; })();',
     'lands the start boundary only once across reloads of an idle pane'),
    ('failed-reload-delivery', 'if (statusDeliveryDirty) forgetUndelivered();',
     'if (false) forgetUndelivered();', 're-posts a level the previous generation could not deliver'),
    ('pane-identity', 'const paneKey = process.env.ORCA_PANE_KEY;',
     'const paneKey = "wrong-pane";', 'gives each overlapping pane only its own session'),
    ('slow-post-order', 'const run = lifecycleQueue.then(async () => {',
     'const run = Promise.resolve().then(async () => {', 'posts each level once and in order while posts are slow'),
    ('endpoint-early', 'const TUI_ENDPOINT_CHECK_TICKS = 50;',
     'const TUI_ENDPOINT_CHECK_TICKS = 49;', 're-posts the current level once the hook endpoint moves'),
    ('endpoint-missing', '++ticks % TUI_ENDPOINT_CHECK_TICKS === 0',
     'false', 're-posts the current level once the hook endpoint moves'),
    ('interval-cleanup', 'clearInterval(tick);',
     'void tick;', 'settles an owned turn once the session data says it ended'),
    ('retry-cleanup', 'if (statusRetryTimer) clearTimeout(statusRetryTimer);',
     'void statusRetryTimer;', 're-posts a level the previous generation could not deliver'),
]
rows = []
try:
    for label, before, after, selected in controls:
        replacement = 'writeFileSync(pluginPath, (() => { const source = _internals.getOpenCodePluginSource(); const before = ' + json.dumps(before) + '; if (source.split(before).length !== 2) throw new Error("Mutation must match one generated-source location"); return source.replace(before, ' + json.dumps(after) + '); })())'
        target.write_text(source.replace(needle, replacement))
        env = os.environ.copy()
        env['ORCA_BACKGROUND_LAUNCH'] = '1'
        output = bundle / ('control-' + label + '.json')
        result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                 '--maxWorkers=1', '--reporter=default', '--reporter=json',
                                 '--outputFile=' + str(output), str(target.relative_to(root)), '-t', selected],
                                cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=20)
        (bundle / ('control-' + label + '.log')).write_text(result.stdout)
        report = json.loads(output.read_text())
        failed = [assertion for item in report['testResults'] for assertion in item['assertionResults']
                  if assertion['status'] == 'failed']
        assert result.returncode != 0 and len(failed) == 1 and 'AssertionError' in result.stdout, result.stdout
        assert selected in failed[0]['fullName']
        row = dict(control=label, failed_case=failed[0]['fullName'], intended_assertion_failed=True)
        rows.append(row)
        print(json.dumps(row), flush=True)
        (bundle / 'controls-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    target.write_bytes(original)
