import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
target = root / 'src/main/opencode/hook-plugin-opencode2-tui-ownership.test.ts'
original = target.read_bytes()
hashes = json.loads((bundle / 'source-hashes.json').read_text())
production = json.loads((bundle / 'production-source-hashes.json').read_text())
assert hashlib.sha256(original).hexdigest() == hashes['candidate']
for path, expected in production.items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path

source = (bundle / 'candidate-hook-plugin-opencode2-tui-ownership.test.ts').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == hashes['candidate']
source = source.replace('import { afterEach,', 'import { afterAll, afterEach,')
source += '''
const controlFetch = globalThis.fetch
const controlArgv = process.argv
const controlEnv = Object.fromEntries(ENV_KEYS.map((key) => [key, process.env[key]]))
afterAll(() => {
  const restored = {
    realTimers: !vi.isFakeTimers(),
    fetch: globalThis.fetch === controlFetch,
    argv: process.argv === controlArgv,
    environment: ENV_KEYS.every((key) => process.env[key] === controlEnv[key])
  }
  console.log('TUI_FAILURE_RESTORATION=' + JSON.stringify(restored))
  expect(Object.values(restored).every(Boolean)).toBe(true)
})
'''
needle = 'writeFileSync(pluginPath, _internals.getOpenCodePluginSource())'
assert source.count(needle) == 1
selected = 'settles an owned turn once the session data says it ended'
controls = [
    ('import-refusal', None, 'throw new Error("TUI_IMPORT_REFUSAL");\n',
     'TUI_IMPORT_REFUSAL', 5),
    ('setup-refusal', 'async function setupOpenCode2Tui(ctx) {',
     'async function setupOpenCode2Tui(ctx) { throw new Error("TUI_SETUP_REFUSAL");',
     'TUI_SETUP_REFUSAL', 5),
    ('cleanup-rejection', 'return async () => {\n      try {\n        disposed = true;',
     'return async () => { throw new Error("TUI_CLEANUP_REJECTION");\n      try {\n        disposed = true;',
     'TUI_CLEANUP_REJECTION', 5),
    ('cleanup-timeout', 'await releaseTuiStatusDelivery(factoryID, () => setMemory((draft) => { draft.last = ""; }));',
     'await new Promise(() => {});', 'Test timed out in 200ms', 7),
]
rows = []
try:
    for label, before, after, failure, bound in controls:
        if before is None:
            replacement = 'writeFileSync(pluginPath, ' + json.dumps(after) + ' + _internals.getOpenCodePluginSource())'
        else:
            replacement = 'writeFileSync(pluginPath, (() => { const source = _internals.getOpenCodePluginSource(); const before = ' + json.dumps(before) + '; if (source.split(before).length !== 2) throw new Error("Mutation must match one generated-source location"); return source.replace(before, ' + json.dumps(after) + '); })())'
        target.write_text(source.replace(needle, replacement))
        env = os.environ.copy()
        env['ORCA_BACKGROUND_LAUNCH'] = '1'
        output = bundle / ('cleanup-control-' + label + '.json')
        started = time.perf_counter()
        result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                 '--maxWorkers=1', '--testTimeout=200', '--reporter=default', '--reporter=json',
                                 '--outputFile=' + str(output), str(target.relative_to(root)), '-t', selected],
                                cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=15)
        elapsed = time.perf_counter() - started
        (bundle / ('cleanup-control-' + label + '.log')).write_text(result.stdout)
        report = json.loads(output.read_text())
        failed = [assertion for item in report['testResults'] for assertion in item['assertionResults']
                  if assertion['status'] == 'failed']
        marker = 'TUI_FAILURE_RESTORATION='
        restoration = json.loads(result.stdout.split(marker)[1].splitlines()[0])
        assert result.returncode != 0 and len(failed) == 1 and failure in result.stdout, result.stdout
        assert selected in failed[0]['fullName'] and all(restoration.values()), result.stdout
        assert elapsed < bound, (label, elapsed, bound)
        row = dict(control=label, expected_failure=failure, failed_case=failed[0]['fullName'],
                   wall_seconds=elapsed, real_bounded_cleanup=True, restoration=restoration)
        rows.append(row)
        print(json.dumps(row), flush=True)
        (bundle / 'cleanup-controls-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    target.write_bytes(original)
