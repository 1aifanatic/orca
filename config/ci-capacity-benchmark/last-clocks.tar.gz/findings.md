# OpenCode 2 TUI test clock qualification

The generated plugin still runs unchanged against the existing fake TUI and mocked fetch. Its dynamic native module import completes before starting the first scoped clock. Async advancement covers Date, timeout, interval and Promise work; the test's original event pumps, reloads, real generated source, payload assertions and observation windows remain.

All 41 original case-name/status entries pass unchanged. Parameterized verdict tests legitimately repeat full names; the runner checks the exact sorted multiset rather than just a count. There are no real child processes or network operations in this fixture.

## Measurement

Three one-worker, alternating full-file pairs used baseline/candidate, candidate/baseline, baseline/candidate order:

| Pair | Baseline wall | Candidate wall |
| --- | ---: | ---: |
| 1 | 16.0668 s | 1.4432 s |
| 2 | 16.0789 s | 1.3931 s |
| 3 | 16.1123 s | 1.3889 s |

Median wall time fell from 16.0789 to 1.3931 s, 91.3%. Median case-body time fell from 15.4684 to 0.7726 s. These are local measurements; hosted qualification is required before claiming a CI gain.

Untimed instrumented baseline and candidate both passed all original cases and emitted exactly 1,040 captured observations: 678 TUI operations/delivered events and 362 POST starts/completions. The full ordered TUI stream and full ordered POST stream match exactly, including all POST payloads, failures and completion statuses. Relative clock values are recorded in raw traces and omitted from comparison. Cross-stream event/POST interleaving is not asserted because native I/O timing can vary; each complete stream preserves its original order.

## Preserved coverage and stronger boundaries

- Existing 20/150/250/300/650 ms pumps and absence windows remain; the endpoint case retains its complete 5,000 ms repeat window and final 50 ms observation.
- Missing-end reconciliation must remain Busy before the next 100 ms poll and reach Idle exactly at that poll.
- A delayed mock POST must remain pending through 119 ms and complete its initial FIFO entry at 120 ms; the original eventual full FIFO assertion remains.
- Child permission attention remains Busy before the 500 ms settlement and becomes Needs input at its exact deadline, aligned to polling.
- The moved endpoint must not re-post before tick 50 (4,999 ms), must re-post at 5,000 ms, and must remain deduplicated throughout the next original 5,000 ms window.
- The scoped assertion waiter retains the original 1,000/3,000 ms budgets and 50 ms steps, checks the exact final deadline, caps its final advance by remaining budget, and uses the real Vitest waiter when the scoped clock is inactive.

## Fault controls

Eleven independently modified locations in the actual generated source fail the intended assertions: poll period 100→101 ms; permission settle 500→400/501 ms; forgotten reload memory; missing failed-generation re-delivery; wrong pane identity; unqueued slow POSTs; endpoint check tick 50→49; removed endpoint check; leaked interval; leaked retry timer. Every mutation is guarded to match exactly one generated-source location. No production file is edited.

Four additional failure controls prove cleanup after generated import refusal, generated setup refusal, rejecting disposer and indefinitely pending disposer. Each intended case fails; a separate outer afterAll confirms real timers, original fetch/argv and all managed environment values are restored. The pending-disposer test times out at 200 ms, and teardown uses a real 2,000 ms fallback; local process wall time was 2.760 s. Import/setup/disposer rejection processes exited in 0.60–0.64 s. Normal explicit disposer calls also assert no remaining scoped timers.

The failure teardown starts tracked disposers, releases only unfinished mock POST delays, restores real timers before awaiting anything, and bounds any remaining disposer wait with the existing shared timeout helper. Its fallback false is asserted, so a refusal cannot silently pass.

## Verification

Default oxlint, anti-slop oxlint, oxfmt check and tc:node all pass. No production edits, line-limit suppression or weakened case exists.

## Portable commands

Run from the primary worktree root, with this bundle unpacked anywhere:

```
python3 /path/to/bundle/run-tui-clock-benchmark.py
python3 /path/to/bundle/run-tui-clock-controls.py
python3 /path/to/bundle/run-tui-clock-cleanup-controls.py
python3 /path/to/bundle/run-tui-clock-capture.py
```

All four drivers require the live file to match the frozen candidate, verify the exact frozen production/config inputs and restore the original live bytes in finally. Subprocess timeouts are 60 s for whole-file pairs/captures, 20 s for semantic faults and 15 s for cleanup controls. Run drivers sequentially, without other writers or measurements. JSON/log output is stored beside each script. Every process receives ORCA_BACKGROUND_LAUNCH=1 and maxWorkers=1.

Source snapshots are `hook-plugin-opencode2-tui-ownership.test.ts` (baseline) and `candidate-hook-plugin-opencode2-tui-ownership.test.ts` (candidate). Source hashes are in `source-hashes.json`; the unchanged generated-source, hook, fixture, shared fallback and unit-config hashes are in `production-source-hashes.json`. The candidate is the only source to restore after qualification; baseline is evidence only.
