from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle, root, out = Path(__file__).resolve().parent, Path.cwd(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/main/runtime/quarter-circle-title-send-authorization.test.ts')
production = {
    'presence': (Path('src/main/runtime/runtime-terminal-agent-presence.ts'), 'presence-original.source'),
    'guard': (Path('src/main/runtime/rpc/terminal-agent-send-guard.ts'), 'guard-original.source'),
    'query': (Path('src/main/runtime/runtime-terminal-agent-status-query.ts'), 'query-original.source')
}
manifest = json.loads((bundle / 'manifest.json').read_text())
for filename, expected in manifest.items():
    if hashlib.sha256((bundle / filename).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Frozen input changed: {filename}')
candidate = (bundle / 'candidate.source').read_text()
names = json.loads((bundle / 'case-names.json').read_text())
original = {family: (bundle / frozen).read_text() for family, (_, frozen) in production.items()}
if (root / test).read_text() != candidate:
    raise RuntimeError('Candidate test differs from frozen source')
for family, (relative, _) in production.items():
    if (root / relative).read_text() != original[family]:
        raise RuntimeError(f'Production differs from frozen source: {relative}')
restore = (root / test).read_bytes()
wrapper = 'refuses a guarded send when a quarter-circle spinner is the only agent evidence'
unknown = 'refuses a guarded send when the foreground process cannot be read at all'
mutants = [
    ('wrapper-before-original-final-tick', 'presence', 'WRAPPER_RETRY_TIMEOUT_MS = 6_500', 'WRAPPER_RETRY_TIMEOUT_MS = 6_450', wrapper, 'agent evidence settled before its deadline'),
    ('wrapper-after-original-final-tick', 'presence', 'WRAPPER_RETRY_TIMEOUT_MS = 6_500', 'WRAPPER_RETRY_TIMEOUT_MS = 6_601', wrapper, 'agent evidence did not settle at its deadline'),
    ('guard-one-ms-early', 'guard', 'AGENT_STATUS_RECHECK_TIMEOUT_MS = 1_050', 'AGENT_STATUS_RECHECK_TIMEOUT_MS = 1_049', unknown, 'agent evidence settled before its deadline'),
    ('guard-one-ms-late', 'guard', 'AGENT_STATUS_RECHECK_TIMEOUT_MS = 1_050', 'AGENT_STATUS_RECHECK_TIMEOUT_MS = 1_051', unknown, 'agent evidence did not settle at its deadline'),
    ('spinner-activity-trusted-as-identity', 'query', 'isOpenCodeNativeTitle(terminal.title) ||\n        isQuarterCircleSpinnerOnlyAgentTitle(terminal.title)', 'isOpenCodeNativeTitle(terminal.title)', wrapper, 'agent evidence settled before its deadline'),
    ('unknown-agent-authorized', 'guard', 'if (agentStatus.isRunningAgent)', 'if (true)', unknown, 'agent evidence settled before its deadline')
]
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_QUARTERCIRCLE_MUTANT_IMPORTED': '0'}
rows = []
try:
    for label, family, pattern, replacement, selected, expected in mutants:
        relative, _ = production[family]
        if original[family].count(pattern) != 1:
            raise RuntimeError(f'Changed mutation site: {pattern}')
        mutated = original[family].replace(pattern, replacement)
        mutated = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                         lambda match: 'from ' + json.dumps((root / relative.parent / match.group(2)).resolve().as_posix()),
                         mutated)
        mutated += "\nprocess.env.ORCA_QUARTERCIRCLE_MUTANT_IMPORTED = '1'\n"
        module_file = out / f'{label}.ts'
        module_file.write_text(mutated)
        config = out / f'{label}.config.ts'
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*' + re.escape(relative.stem) +
                          '$/, replacement: ' + json.dumps(module_file.as_posix()) +
                          ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        source = candidate.replace('import { afterEach,', 'import { afterAll, afterEach,')
        source = source.replace("const PTY_ID = 'pty-1'", """const PTY_ID = 'pty-1'
const hostSetTimeout = globalThis.setTimeout
const hostDate = globalThis.Date
const mockCleanupChecks: (() => void)[] = []""", 1)
        source = source.replace("  vi.spyOn(internals, 'resolveTerminalWorkspaceLaunchScope')", """  mockCleanupChecks.push(() => expect(vi.isMockFunction(internals.resolveTerminalWorkspaceLaunchScope), 'failure cleanup must restore the runtime host mock').toBe(false))
  vi.spyOn(internals, 'resolveTerminalWorkspaceLaunchScope')""", 1)
        source = source.replace('  vi.restoreAllMocks()\n', '''  vi.restoreAllMocks()
  expect(vi.isFakeTimers(), 'failure cleanup must restore real timers').toBe(false)
  expect(globalThis.setTimeout, 'failure cleanup must restore the host clock').toBe(hostSetTimeout)
  expect(globalThis.Date, 'failure cleanup must restore the host Date').toBe(hostDate)
  for (const check of mockCleanupChecks.splice(0)) check()
''', 1)
        source += "\nafterAll(() => expect(process.env.ORCA_QUARTERCIRCLE_MUTANT_IMPORTED).toBe('1'))\n"
        (root / test).write_text(source)
        target = out / f'{label}.json'
        started = time.perf_counter()
        with (out / f'{label}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(test),
                                   '--maxWorkers=1', '--experimental.fsModuleCache=false',
                                   '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        report = json.loads(target.read_text())
        cases = [case for suite in report['testResults'] for case in suite['assertionResults']]
        failed = [case for case in cases if case['status'] == 'failed']
        if sorted(case['fullName'] for case in cases) != names or proc.returncode != 1 or \
                report['numPassedTests'] != 0 or report['numFailedTests'] != 1 or \
                report['numPendingTests'] != 8 or len(failed) != 1 or failed[0]['title'] != selected or \
                len(failed[0]['failureMessages']) != 1 or expected not in failed[0]['failureMessages'][0]:
            raise RuntimeError(f'{label} failed at an unexpected oracle; inspect {target}')
        row = {'mutation': label, 'productionSha256': hashlib.sha256(mutated.encode()).hexdigest(),
               'testSha256': hashlib.sha256(source.encode()).hexdigest(),
               'processWallSeconds': time.perf_counter() - started, 'bodyMs': failed[0].get('duration', 0),
               'failed': 1, 'pending': 8, 'failure': failed[0]['failureMessages'][0].split('\n')[0]}
        rows.append(row)
        print(json.dumps(row), flush=True)
        (root / test).write_bytes(restore)
finally:
    (root / test).write_bytes(restore)
    if (root / test).read_bytes() != restore:
        raise RuntimeError('Test restoration failed')
    for family, (relative, _) in production.items():
        if (root / relative).read_text() != original[family]:
            raise RuntimeError(f'Production changed during controls: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
