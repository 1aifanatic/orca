import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
target = root / 'src/main/opencode/hook-plugin-opencode2-tui-ownership.test.ts'
original = target.read_bytes()
hashes = json.loads((bundle / 'source-hashes.json').read_text())
production = json.loads((bundle / 'production-source-hashes.json').read_text())
assert hashlib.sha256(original).hexdigest() == hashes['candidate']
for path, expected in production.items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path

collector = bundle / 'tui-capture.mjs'
collector.write_text(f'''import {{ appendFileSync }} from 'node:fs'
import {{ expect }} from {json.dumps(str(root / 'node_modules/vitest/dist/index.js'))}
let ordinal = 0
let origin = 0
export function capture(kind, value) {{
  if (kind === 'case-start') {{ ordinal += 1; origin = Date.now() }}
  appendFileSync(process.env.ORCA_TUI_CAPTURE, JSON.stringify({{ordinal, name: expect.getState().currentTestName, at: Date.now() - origin, kind, value}}) + '\\n')
}}
''')
fixture = (root / 'src/main/opencode/opencode-tui-session-fixture.ts').read_text()
fixture = fixture.replace("import { vi } from 'vitest'", f"import {{ vi }} from {json.dumps(str(root / 'node_modules/vitest/dist/index.js'))}\nimport {{ capture }} from {json.dumps(str(collector))}\nlet nextTui = 0")
fixture = fixture.replace("export function fakeTui(version = '2.0.14') {", "export function fakeTui(version = '2.0.14') {\n  const tuiID = ++nextTui\n  capture('tui-created', {tuiID, version})")
fixture = fixture.replace('handler({ details: event })', "capture('delivered-event', {tuiID, event}); handler({ details: event })")
for method, parameter in [('navigate', 'sessionID'), ('loseEnd', 'sessionID'), ('loseStart', 'sessionID'), ('emit', 'event')]:
    signature = method + '(' + parameter + (': BusEvent' if method == 'emit' else ': string') + ') {'
    fixture = fixture.replace(signature, signature + "\n      capture('" + method + "', {tuiID, " + parameter + "})")
fixture = fixture.replace('holdPermissionFetch(): () => void {', "holdPermissionFetch(): () => void {\n      capture('hold-permission-fetch', {tuiID})")
fixture = fixture.replace('return release', "return () => { capture('release-permission-fetch', {tuiID}); release() }")
fixture_path = bundle / 'opencode-tui-session-fixture.capture.ts'
fixture_path.write_text(fixture)
config = bundle / 'capture.config.ts'
config.write_text(f'''import {{ mergeConfig }} from {json.dumps(str(root / 'node_modules/vitest/dist/config.js'))}
import base from {json.dumps(str(root / 'config/vitest.config.ts'))}
export default mergeConfig(base, {{ plugins: [{{
  name: 'opencode-tui-observation-capture', enforce: 'pre',
  resolveId(source, importer) {{
    if (source === './opencode-tui-session-fixture' && importer?.endsWith('hook-plugin-opencode2-tui-ownership.test.ts')) return {json.dumps(str(fixture_path))}
  }}
}}] }})
''')
rows = []
canonical = None
try:
    for treatment, snapshot in [('baseline', 'hook-plugin-opencode2-tui-ownership.test.ts'), ('candidate', 'candidate-hook-plugin-opencode2-tui-ownership.test.ts')]:
        text = (bundle / snapshot).read_text()
        assert hashlib.sha256(text.encode()).hexdigest() == hashes[treatment]
        text = f'import {{ capture }} from {json.dumps(str(collector))}\n' + text
        text = text.replace('beforeEach(() => {', "beforeEach(() => {\n    capture('case-start', {})")
        text = text.replace('const body = JSON.parse(String(init?.body))', "const body = JSON.parse(String(init?.body))\n      capture('post-start', {url: String(_input), body, postDelayMs, failPosts})")
        text = text.replace("return new Response('{}', { status: 500 })", "capture('post-complete', {body, status: 500})\n        return new Response('{}', { status: 500 })")
        text = text.replace('allPosts.push(body)', "capture('post-complete', {body, status: 200})\n      allPosts.push(body)")
        target.write_text(text)
        capture_path = bundle / ('capture-' + treatment + '.jsonl')
        capture_path.unlink(missing_ok=True)
        env = os.environ.copy()
        env.update(ORCA_BACKGROUND_LAUNCH='1', ORCA_TUI_CAPTURE=str(capture_path),
                   ORCA_AGENT_LAUNCH_TOKEN='capture-launch-token', ORCA_TAB_ID='capture-tab',
                   ORCA_WORKTREE_ID='capture-worktree', ORCA_AGENT_HOOK_ENV='capture-environment',
                   ORCA_AGENT_HOOK_VERSION='capture-version', TMUX='', TMUX_PANE='')
        output = bundle / ('capture-' + treatment + '.json')
        result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config),
                                 '--maxWorkers=1', '--reporter=default', '--reporter=json',
                                 '--outputFile=' + str(output), str(target.relative_to(root))],
                                cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=60)
        (bundle / ('capture-' + treatment + '.log')).write_text(result.stdout)
        assert result.returncode == 0, result.stdout
        report = json.loads(output.read_text())
        cases = sorted((assertion['fullName'], assertion['status']) for item in report['testResults']
                       for assertion in item['assertionResults'])
        assert cases == [tuple(case) for case in json.loads((bundle / 'expected-cases.json').read_text())]
        observations = [json.loads(line) for line in capture_path.read_text().splitlines()]
        comparable = [{key: value for key, value in row.items() if key != 'at'} for row in observations]
        # Ordering between an event and its async POST completion can vary with native I/O jitter.
        # Compare the full TUI operation/event stream and ordered POST begin/completion stream.
        streams = {'tui-events': [row for row in comparable if not row['kind'].startswith('post-')], 'posts': [row for row in comparable if row['kind'].startswith('post-')]}
        if canonical is None:
            canonical = streams
            (bundle / 'capture-canonical.json').write_text(json.dumps(streams, indent=2) + '\n')
        assert streams == canonical, 'Observation streams differ: ' + treatment
        row = dict(treatment=treatment, cases=41, observations=len(observations),
                   stream_counts={kind: len(values) for kind, values in streams.items()},
                   full_ordered_event_payload_parity=True, relative_clock_recorded=True)
        rows.append(row)
        print(json.dumps(row), flush=True)
        (bundle / 'capture-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    target.write_bytes(original)
