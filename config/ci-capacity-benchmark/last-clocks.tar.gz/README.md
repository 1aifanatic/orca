# Quarter-circle send authorization clock benchmark

Run from the primary checkout with the frozen candidate installed:

```
python3 /tmp/orca-ci-quartercircle-clock-20261004/run-controls.py --out /tmp/orca-ci-quartercircle-clock-20261004/controls-hosted
python3 /tmp/orca-ci-quartercircle-clock-20261004/run-benchmark.py --out /tmp/orca-ci-quartercircle-clock-20261004/pairs-hosted
```

The benchmark executes three fresh-process counterbalanced original/candidate pairs at maxWorkers=1, with filesystem and Node module caches disabled. Every original case name and pass/skip status must match: nine passes, zero skips. It guards frozen source/production hashes, changes only the owned test, and restores incoming source in finally. Controls never mutate production: disposable copies of the real production modules are installed by one-module aliases, checked with a loaded-module sentinel. All runs set ORCA_BACKGROUND_LAUNCH=1.

The original first case reads a persistent `node` foreground twice, via actual getTerminalAgentStatus and the guarded send. Each foreground wrapper read retries every 150ms until its unchanged 6,500ms budget is crossed at 6,600ms. The guard's own 1,050ms wall deadline has already expired when the second wrapper read returns. Three additional negative cases each wait out that guard deadline. This explains the refreshed 13.282s first-case body and the other 1.060/1.056/1.070s refusal cases without an initialization hypothesis.

The candidate leaves real runtime/terminal creation, fake controller spawning, managed launch metadata, window/graph registration, stale/replacement incarnation checks, foreground process reads, recognized-agent cases and title activity/identity assertions intact. Only the negative agent-evidence reads install scoped fake Date/setTimeout/clearTimeout after real creation and graph binding. Checks require each operation to remain unsettled at 6,599ms or1,049ms, settle at6,600ms or1,050ms, and leave no fake timers. Finally drains remaining fake ticks, clears timers and restores real clocks; afterEach restores runtime-instance spies even after creation/assertion failure. Positive cases retain real clocks. All nine original cases remain.

Six actual production faults must fail the selected original case, with the other eight cases skipped: foreground retry ending one tick early/late, send guard deadline one millisecond early/late, quarter-spinner activity incorrectly accepted as agent identity, and unknown-agent send authorization. Temporary afterEach assertions additionally verify that native Date/setTimeout and the real runtime workspace resolver have been restored after every intentional failure. They are excluded from ordinary CI source.

Codex teardown was separately audited and deferred: its four cases each launch 40 actual providers, supervisors and descendants, for160 launches total. The first case already closes all40 connections concurrently. The other cases observe each root exit or stdin-close race only after descendant reap. Fake parent clocks cannot advance separate child process clocks, and lowering supervisor grace or replacing the native launches changes the lifecycle proof.

Local qualification retained nine passes and zero skips in all six runs. Original process walls were22.037/21.727/21.968s; candidate5.981/5.606/5.470s, for medians21.968→5.606s (74.5% lower). Body median16,251.18→29.11ms. All six actual-production controls failed at the intended assertion and passed clock/mock cleanup checks. Independent frozen-source review found no issues. Focused oxlint, oxfmt --check, git diff --check and full pnpm tc:node passed. Live source was restored byte-for-byte to candidate.source afterward.
