import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import time

root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
target = root / 'src/main/opencode/hook-plugin-opencode2-tui-ownership.test.ts'
baseline = bundle / 'hook-plugin-opencode2-tui-ownership.test.ts'
candidate = bundle / 'candidate-hook-plugin-opencode2-tui-ownership.test.ts'
hashes = json.loads((bundle / 'source-hashes.json').read_text())
production = json.loads((bundle / 'production-source-hashes.json').read_text())
original = target.read_bytes()
rows = []
expected = None

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for treatment, snapshot in [('baseline', baseline), ('candidate', candidate)]:
    assert digest(snapshot) == hashes[treatment], treatment + ' snapshot changed'
assert digest(target) == hashes['candidate'], 'Live source must match frozen candidate'

def guard_production():
    for path, expected in production.items():
        assert digest(root / path) == expected, 'Production source changed: ' + path

try:
    for index, treatment in enumerate(['baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate'], 1):
        guard_production()
        target.write_bytes((baseline if treatment == 'baseline' else candidate).read_bytes())
        output = bundle / (treatment + '-' + str(index) + '.json')
        env = os.environ.copy()
        env['ORCA_BACKGROUND_LAUNCH'] = '1'
        start = time.perf_counter()
        result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                 '--maxWorkers=1', '--reporter=default', '--reporter=json',
                                 '--outputFile=' + str(output), str(target.relative_to(root))],
                                cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=60)
        wall = time.perf_counter() - start
        (bundle / (output.stem + '.log')).write_text(result.stdout)
        assert result.returncode == 0, result.stdout
        report = json.loads(output.read_text())
        cases = sorted((assertion['fullName'], assertion['status']) for item in report['testResults']
                       for assertion in item['assertionResults'])
        assert len(cases) == 41 and all(status == 'passed' for _, status in cases)
        if expected is None:
            expected = cases
            (bundle / 'expected-cases.json').write_text(json.dumps(cases, indent=2) + '\n')
        assert cases == expected, 'Original case names/statuses changed'
        row = dict(treatment=treatment, wall=wall, cases=len(cases), exact_case_status_equality=True,
                   body=sum(item['endTime'] - item['startTime'] for item in report['testResults']) / 1000,
                   phases=re.findall(r'Duration\s+[^\n]+', result.stdout))
        rows.append(row)
        print(json.dumps(row), flush=True)
        (bundle / 'alternating-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    target.write_bytes(original)

print(json.dumps({kind: statistics.median(row['wall'] for row in rows if row['treatment'] == kind)
                  for kind in ['baseline', 'candidate']}), flush=True)
