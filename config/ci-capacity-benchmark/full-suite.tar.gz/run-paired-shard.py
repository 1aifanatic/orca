import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import time

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root)

def file_key(name):
    return Path(name).resolve().relative_to(root).as_posix()

def read_cases(report):
    return {file_key(item['name']): sorted([entry['fullName'], entry['status']]
        for entry in item['assertionResults']) for item in report['testResults']}

def invoke(command, env, log, timeout):
    started = time.perf_counter()
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        timed_out = False
        try:
            return_code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            return_code = process.returncode
    return return_code, time.perf_counter() - started, timed_out

parser = argparse.ArgumentParser()
parser.add_argument('--shard', type=int, choices=range(1, 6), required=True)
parser.add_argument('--rounds', type=int, choices=[1, 2, 3], default=1)
parser.add_argument('--out', required=True)
parser.add_argument('--execute', action='store_true')
parser.add_argument('--qualify', action='store_true')
args = parser.parse_args()
root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
out = Path(args.out).resolve()
manifest = json.loads((bundle / 'overlay-manifest.json').read_text())
plan = json.loads((bundle / 'fixed-plan.json').read_text())
ledger = json.loads((bundle / 'frozen-case-ledger.json').read_text())
assert sha((bundle / 'fixed-plan.json').read_bytes()) == manifest['fixedPlanSha256']
assert sha((bundle / 'frozen-case-ledger.json').read_bytes()) == manifest['approvedCaseLedgerSha256']
assert args.qualify or args.rounds == manifest['rounds'], 'Run every prepared comparison round'
orders = [['baseline', 'candidate'] if (args.shard + index) % 2 else ['candidate', 'baseline']
          for index in range(args.rounds)]
if not args.execute:
    print(json.dumps(dict(dryRun=True, shard=args.shard, rounds=orders, workers=4,
                         baseSourceSha=manifest['finalSourceSha'], files=len(plan['shards'][args.shard - 1]['files']),
                         untimedQualification=args.qualify)))
    raise SystemExit(0)
assert os.environ.get('GITHUB_ACTIONS') == 'true' and platform.system() == 'Linux', 'Execution is restricted to a disposable Linux CI checkout'
assert platform.machine().lower() in ['aarch64', 'arm64'], 'Use the same hosted Linux ARM platform as qualification'
assert git('rev-parse', 'HEAD').decode().strip() == manifest['finalSourceSha']
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == manifest['baseTreeGitOid']
assert not git('diff', 'HEAD', '--name-only'), 'Tracked checkout must be clean before overlays'
assert not os.environ.get('NODE_COMPILE_CACHE'), 'Normal CI compile cache is disabled; do not share one between arms'
node = subprocess.check_output(['node', '--version'], text=True).strip()
assert node.startswith('v24.'), node
pnpm = subprocess.check_output(['pnpm', '--version'], text=True).strip()
out.mkdir(parents=True, exist_ok=True)
assert out != root and root not in out.parents
for name in ['overlay-manifest.json', 'fixed-plan.json', 'toolchain.json']:
    shutil.copyfile(bundle / name, out / name)
backup = {value: (root / value).read_bytes() for value in manifest['overlayFiles']}
for value, data in backup.items():
    assert sha(data) == manifest['overlayFiles'][value]['candidateSha256'], value
for value, expected in manifest['candidateSupportHashes'].items():
    assert sha((root / value).read_bytes()) == expected, value

render = {
    "'__VITEST_NODE__'": json.dumps(str(root / 'node_modules/vitest/dist/node.js')),
    "'__ASSIGNMENT_MODULE__'": json.dumps(str(root / 'config/scripts/ci-shard-assignment.mjs')),
    "'__VITEST_CONFIG__'": json.dumps(str(root / 'node_modules/vitest/dist/config.js')),
    "'__BASE_CONFIG__'": json.dumps(str(root / 'config/vitest.config.ts')),
    '__QUALIFICATION_EXCLUSIONS__': json.dumps([entry['file'] for entry in plan['qualificationExclusions']])
}
for template, destination in [('frozen-assignment-sequencer.template.mjs', 'frozen-assignment-sequencer.mjs'),
                              ('paired.config.template.ts', 'paired.config.ts')]:
    text = (bundle / template).read_text()
    for before, after in render.items():
        text = text.replace(before, after)
    (out / destination).write_text(text)

if args.qualify:
    assert args.shard == 1, 'Run the untimed qualification only once, on shard1'
    run_dir = out / 'untimed-qualification'
    run_dir.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env['ORCA_BACKGROUND_LAUNCH'] = '1'
    command = ['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
               '--maxWorkers=4', '--reporter=json', '--outputFile=' + str(run_dir / 'vitest.json'),
               *[entry['file'] for entry in plan['qualificationExclusions']]]
    status, elapsed, timed_out = invoke(command, env, run_dir / 'vitest.log', 5 * 60)
    record = dict(baseSourceSha=manifest['baseSourceSha'], runId=os.environ.get('GITHUB_RUN_ID', ''),
                  runAttempt=os.environ.get('GITHUB_RUN_ATTEMPT', ''), exitCode=status,
                  timedOut=timed_out, outsideComparisonTiming=True, wallSeconds=elapsed,
                  platformSystem=platform.system(), platformMachine=platform.machine(), valid=False)
    try:
        assert status == 0 and not timed_out, 'Untimed qualification failed or timed out'
        report = json.loads((run_dir / 'vitest.json').read_text())
        cases = read_cases(report)
        assert report['success'] and report['numFailedTests'] == 0
        assert sorted(cases) == sorted(entry['file'] for entry in plan['qualificationExclusions'])
        for entry in plan['qualificationExclusions']:
            values = cases[entry['file']]
            assert len(values) == entry['expectedCaseCount'] and all(value[1] == 'passed' for value in values)
        assert not git('diff', 'HEAD', '--name-only'), 'Untimed qualification changed tracked sources'
        (run_dir / 'case-census.json').write_text(json.dumps(cases, indent=2) + '\n')
        record.update(valid=True, caseCensusSha256=sha((run_dir / 'case-census.json').read_bytes()))
    except (AssertionError, KeyError, FileNotFoundError, json.JSONDecodeError) as error:
        record['validationError'] = str(error)
    (run_dir / 'qualification-record.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    raise SystemExit(0 if record['valid'] else 1)

records = []
try:
    for round_index, arms in enumerate(orders, start=1):
        for position, arm in enumerate(arms, start=1):
            run_dir = out / ('round-' + str(round_index)) / arm
            run_dir.mkdir(parents=True, exist_ok=True)
            active_hashes = {}
            for value, entry in manifest['overlayFiles'].items():
                data = (bundle / 'snapshots' / arm / value).read_bytes()
                expected = entry[arm + 'Sha256']
                assert sha(data) == expected, value
                (root / value).write_bytes(data)
                active_hashes[value] = sha((root / value).read_bytes())
                assert active_hashes[value] == expected
            for value, expected in manifest['candidateSupportHashes'].items():
                assert sha((root / value).read_bytes()) == expected, value
            expected_changed = sorted(value for value, entry in manifest['overlayFiles'].items()
                                      if entry[arm + 'Sha256'] != entry['candidateSha256'])
            assert sorted(git('diff', 'HEAD', '--name-only').decode().splitlines()) == expected_changed
            source_manifest = dict(baseSourceSha=manifest['baseSourceSha'], baseTreeGitOid=manifest['baseTreeGitOid'],
                                   trackedOverlaySha256=dict(sorted(active_hashes.items())),
                                   representation='Complete fixed tracked git tree plus explicit replacement path/sha256 manifest')
            source_bytes = json.dumps(source_manifest, sort_keys=True, separators=(',', ':')).encode()
            (run_dir / 'treatment-source-manifest.json').write_bytes(source_bytes)
            cache_dir = run_dir / 'vite-cache'
            shutil.rmtree(cache_dir, ignore_errors=True)
            cache_dir.mkdir()
            assert not list(cache_dir.iterdir())
            env = os.environ.copy()
            env.update(ORCA_BACKGROUND_LAUNCH='1', ORCA_BALANCE_UNIT_SHARDS='1',
                       ORCA_SHARD_SOURCE_SHA=manifest['finalSourceSha'],
                       ORCA_FROZEN_UNIT_PLAN=str(bundle / 'fixed-plan.json'),
                       ORCA_UNIT_SELECTION_PLAN=str(bundle / 'unit-selection.json'),
                       ORCA_SHARD_MANIFEST=str(run_dir / 'unit-assignment.json'),
                       ORCA_UNIT_TIMING_REPORT=str(run_dir / 'unit-timings.json'),
                       ORCA_UNIT_SORT_LOG=str(run_dir / 'sort-order.json'),
                       ORCA_PAIRED_CACHE_DIR=str(cache_dir),
                       ORCA_PAIRED_JSON_REPORT=str(run_dir / 'vitest.json'))
            command = ['pnpm', 'exec', 'vitest', 'run', '--config', str(out / 'paired.config.ts'),
                       '--shard=' + str(args.shard) + '/5', '--maxWorkers=4']
            status, elapsed, timed_out = invoke(command, env, run_dir / 'vitest.log', 55 * 60)
            record = dict(round=round_index, position=position, treatment=arm,
                          shard=args.shard, baseSourceSha=manifest['baseSourceSha'],
                          baseTreeGitOid=manifest['baseTreeGitOid'],
                          treatmentSourceManifestSha256=sha(source_bytes),
                          reporterSourceShaConvention=manifest['reporterSourceShaConvention'],
                          fixedPlanSha256=manifest['fixedPlanSha256'], workers=4,
                          node=node, pnpm=pnpm, wallSeconds=elapsed, exitCode=status,
                          platformSystem=platform.system(), platformMachine=platform.machine(),
                          timedOut=timed_out, activeOverlayHashes=active_hashes, valid=False)
            try:
                assert status == 0 and not timed_out, 'Vitest failed or exceeded the real process deadline'
                report = json.loads((run_dir / 'vitest.json').read_text())
                timings = json.loads((run_dir / 'unit-timings.json').read_text())
                assignment = json.loads((run_dir / 'unit-assignment.json').read_text())
                cases = read_cases(report)
                selected = sorted(plan['shards'][args.shard - 1]['files'])
                assert report['success'] and report['numFailedTests'] == 0
                assert sorted(cases) == selected
                assert timings['sourceSha'] == manifest['finalSourceSha']
                assert timings['metric'] == 'module-duration-v1' and timings['nodeVersion'] == node[1:]
                assert timings['shard'] == dict(index=args.shard, count=5)
                assert timings['status'] == 'passed' and timings['unhandledErrors'] == 0
                assert sorted(timings['timings']) == selected and sorted(timings['results']) == selected
                assert all(value in ['passed', 'skipped'] for value in timings['results'].values())
                assert assignment['shards'] == plan['shards'] and assignment['selectedShard'] == args.shard
                assert sorted(git('diff', 'HEAD', '--name-only').decode().splitlines()) == expected_changed
                assert all(sha((root / value).read_bytes()) == expected for value, expected in active_hashes.items())
                for value in selected:
                    if value in ledger:
                        assert cases[value] == ledger[value][arm]['cases'], 'Approved case ledger differs: ' + value
                (run_dir / 'case-census.json').write_text(json.dumps(cases, indent=2) + '\n')
                record.update(valid=True, moduleCount=len(cases),
                              caseCount=sum(len(value) for value in cases.values()),
                              caseCensusSha256=sha((run_dir / 'case-census.json').read_bytes()),
                              moduleDurationSumMs=sum(timings['timings'].values()))
            except (AssertionError, KeyError, FileNotFoundError, json.JSONDecodeError) as error:
                record['validationError'] = str(error)
            records.append(record)
            (run_dir / 'run-record.json').write_text(json.dumps(record, indent=2) + '\n')
            (out / 'shard-summary.json').write_text(json.dumps(records, indent=2) + '\n')
            print(json.dumps({key: value for key, value in record.items() if key != 'activeOverlayHashes'}), flush=True)
finally:
    for value, data in backup.items():
        (root / value).write_bytes(data)
    assert all(sha((root / value).read_bytes()) == manifest['overlayFiles'][value]['candidateSha256'] for value in backup)
if not all(record['valid'] for record in records):
    raise SystemExit('Incomplete or invalid treatment: timing gain is unqualified')
