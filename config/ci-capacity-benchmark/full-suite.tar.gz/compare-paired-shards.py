import argparse
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
from dynamic_case_title_identity import canonicalize_census, read_rules

def sha(data):
    return hashlib.sha256(data).hexdigest()

def changed_cases(before, after):
    left = Counter(tuple(value) for value in before)
    right = Counter(tuple(value) for value in after)
    return dict(removed=[list(key) for key in sorted((left - right).elements())],
                added=[list(key) for key in sorted((right - left).elements())])

parser = argparse.ArgumentParser()
parser.add_argument('artifacts')
parser.add_argument('--bundle', required=True)
parser.add_argument('--jobs-json')
parser.add_argument('--out', required=True)
args = parser.parse_args()
bundle = Path(args.bundle)
artifacts = Path(args.artifacts)
manifest = json.loads((bundle / 'overlay-manifest.json').read_text())
plan = json.loads((bundle / 'fixed-plan.json').read_text())
ledger = json.loads((bundle / 'frozen-case-ledger.json').read_text())
assert sha((bundle / 'frozen-case-ledger.json').read_bytes()) == manifest['approvedCaseLedgerSha256']
assert sha((bundle / 'fixed-plan.json').read_bytes()) == manifest['fixedPlanSha256']
for value, expected in manifest.get('caseLedgerCorrections', {}).items():
    assert sha((bundle / value).read_bytes()) == expected, value
for value, expected in manifest['caseTitleIdentityHashes'].items():
    assert sha((bundle / value).read_bytes()) == expected, value
title_rules = read_rules(bundle / 'dynamic-case-title-rules.json')
records = {}
cases = {}
raw_cases = {}
timings = {}
for path in artifacts.rglob('run-record.json'):
    record = json.loads(path.read_text())
    assert record['valid'] and record['exitCode'] == 0 and not record['timedOut'], str(path)
    assert record['baseSourceSha'] == manifest['baseSourceSha']
    assert record.get('commonFixtureHashes', {}) == manifest.get('commonFixtureHashes', {})
    assert record['fixedPlanSha256'] == manifest['fixedPlanSha256'] and record['workers'] == 4
    key = (record['round'], record['treatment'], record['shard'])
    assert key not in records, 'Duplicate run record: ' + str(key)
    assert record['treatment'] in ['baseline', 'candidate'] and record['shard'] in range(1, 6)
    assert set(record['activeOverlayHashes']) == set(manifest['overlayFiles'])
    for value, entry in manifest['overlayFiles'].items():
        assert record['activeOverlayHashes'][value] == entry[record['treatment'] + 'Sha256']
    source_bytes = (path.parent / 'treatment-source-manifest.json').read_bytes()
    assert sha(source_bytes) == record['treatmentSourceManifestSha256']
    source_manifest = json.loads(source_bytes)
    assert source_manifest['baseSourceSha'] == manifest['baseSourceSha']
    assert source_manifest['baseTreeGitOid'] == manifest['baseTreeGitOid']
    assert source_manifest['trackedOverlaySha256'] == record['activeOverlayHashes']
    census_path = path.parent / 'case-census.json'
    assert sha(census_path.read_bytes()) == record['caseCensusSha256']
    raw_census = json.loads(census_path.read_text())
    assert record['caseTitleIdentityHashes'] == manifest['caseTitleIdentityHashes']
    assert record['caseTitleSourceHashes'] == {value: rule['sourceSha256'] for value, rule in title_rules['files'].items()}
    canonical_path = path.parent / 'canonical-case-census.json'
    assert sha(canonical_path.read_bytes()) == record['canonicalCaseCensusSha256']
    census = canonicalize_census(raw_census, title_rules, record['caseTitleSourceHashes'])
    assert json.loads(canonical_path.read_text()) == census, 'Canonical case census differs from immutable raw titles'
    raw_cases[key] = raw_census
    selected = sorted(plan['shards'][record['shard'] - 1]['files'])
    assert sorted(census) == selected
    module_report = json.loads((path.parent / 'unit-timings.json').read_text())
    assert module_report['sourceSha'] == record['baseSourceSha'] and module_report['status'] == 'passed'
    assert module_report['metric'] == 'module-duration-v1' and module_report['nodeVersion'] == record['node'][1:]
    assert module_report['unhandledErrors'] == 0 and sorted(module_report['timings']) == selected
    assert sorted(module_report['results']) == selected
    assert module_report['shard'] == dict(index=record['shard'], count=5)
    assert all(value in ['passed', 'skipped'] for value in module_report['results'].values())
    assignment = json.loads((path.parent / 'unit-assignment.json').read_text())
    assert assignment['shards'] == plan['shards'] and assignment['selectedShard'] == record['shard']
    assert assignment['sourceSha'] == manifest['baseSourceSha']
    records[key], cases[key], timings[key] = record, census, module_report

rounds = sorted(set(key[0] for key in records))
assert rounds == list(range(1, manifest['rounds'] + 1)), 'Require all planned comparison rounds'
assert len(records) == manifest['rounds'] * 10, 'Need exactly five shards in each arm of every round'
assert len(set((record['node'], record['pnpm']) for record in records.values())) == 1
assert len(set((record.get('platformSystem'), record.get('platformMachine')) for record in records.values())) == 1
assert all(record.get('platformSystem') == 'Linux' and record.get('platformMachine', '').lower() in ['arm64', 'aarch64']
           for record in records.values()), 'Pilot must use one Linux ARM platform'
assert len(set((report['sourceSha'], report['runId'], report['runAttempt'], report['nodeVersion'])
               for report in timings.values())) == 1, 'Pair evidence mixes source/run/attempt/Node'
for arm in ['baseline', 'candidate']:
    assert len(set(record['treatmentSourceManifestSha256'] for record in records.values()
                   if record['treatment'] == arm)) == 1, 'Treatment source provenance differs across shards/rounds'
qualification_paths = list(artifacts.rglob('qualification-record.json'))
assert len(qualification_paths) == 1, 'Require one successful untimed qualification from shard1'
qualification_path = qualification_paths[0]
qualification = json.loads(qualification_path.read_text())
assert qualification['valid'] and qualification['exitCode'] == 0 and not qualification['timedOut']
assert qualification['outsideComparisonTiming']
assert qualification.get('commonFixtureHashes', {}) == manifest.get('commonFixtureHashes', {})
assert (qualification['baseSourceSha'], qualification['runId'], qualification['runAttempt']) == next(iter(
    (report['sourceSha'], report['runId'], report['runAttempt']) for report in timings.values()))
assert qualification['platformSystem'] == 'Linux' and qualification['platformMachine'].lower() in ['arm64', 'aarch64']
qualification_cases_path = qualification_path.parent / 'case-census.json'
assert sha(qualification_cases_path.read_bytes()) == qualification['caseCensusSha256']
qualification_cases = json.loads(qualification_cases_path.read_text())
assert sorted(qualification_cases) == sorted(entry['file'] for entry in plan['qualificationExclusions'])
for entry in plan['qualificationExclusions']:
    values = qualification_cases[entry['file']]
    assert len(values) == entry['expectedCaseCount'] and all(value[1] == 'passed' for value in values)
accepted_changes = {}
raw_title_differences = []
rows = []
for round_index in rounds:
    merged = {}
    for arm in ['baseline', 'candidate']:
        arm_cases = {}
        arm_wall = []
        report_provenance = set()
        for index in range(1, 6):
            key = (round_index, arm, index)
            record = records[key]
            expected_position = (1 if (index + round_index - 1) % 2 else 2) if arm == 'baseline' else (2 if (index + round_index - 1) % 2 else 1)
            assert record['position'] == expected_position
            arm_wall.append(record['wallSeconds'])
            for value, entries in cases[key].items():
                assert value not in arm_cases
                arm_cases[value] = entries
                if value in ledger:
                    assert entries == ledger[value][arm]['cases'], value
            report = timings[key]
            report_provenance.add((report['sourceSha'], report['runId'], report['runAttempt'], report['nodeVersion']))
        assert len(report_provenance) == 1, 'Shard timing evidence mixes source/run/attempt/Node'
        assert sorted(arm_cases) == plan['files'], 'Trial suite coverage differs from frozen independent discovery'
        merged[arm] = arm_cases
        rows.append(dict(round=round_index, treatment=arm,
                         summedTestProcessSeconds=sum(arm_wall), maximumShardTestProcessSeconds=max(arm_wall),
                         shardTestProcessSeconds=arm_wall,
                         modules=len(arm_cases), cases=sum(len(value) for value in arm_cases.values())))
    for value in title_rules['files']:
        raw_arms = {arm: next(census[value] for key, census in raw_cases.items() if key[0] == round_index and key[1] == arm and value in census) for arm in ['baseline', 'candidate']}
        raw_title_differences.append(dict(round=round_index, file=value, **changed_cases(raw_arms['baseline'], raw_arms['candidate'])))
    for value in plan['files']:
        difference = changed_cases(merged['baseline'][value], merged['candidate'][value])
        if difference['removed'] or difference['added']:
            assert value in ledger and ledger[value]['approvedCaseChange'], 'Unapproved case/status difference: ' + value
            accepted_changes[value] = dict(reason=ledger[value]['reason'], **difference)
        else:
            assert merged['baseline'][value] == merged['candidate'][value]
    if round_index > 1:
        for arm in ['baseline', 'candidate']:
            for index in range(1, 6):
                assert cases[(round_index, arm, index)] == cases[(1, arm, index)], 'Same-arm case/status drift'

setup = {}
for path in artifacts.rglob('shared-setup.json'):
    record = json.loads(path.read_text())
    assert record['shard'] not in setup
    setup[record['shard']] = record['dependencySetupSeconds']
if setup:
    assert sorted(setup) == list(range(1, 6)), 'Need one common dependency setup record per paired shard job'
    for row in rows:
        row['summedDependencySetupPlusTestSeconds'] = sum(setup.values()) + row['summedTestProcessSeconds']
        row['maximumDependencySetupPlusTestSeconds'] = max(setup[index + 1] + row['shardTestProcessSeconds'][index] for index in range(5))
actual_jobs = None
if args.jobs_json:
    payload = json.loads(Path(args.jobs_json).read_text())
    jobs = payload['jobs'] if isinstance(payload, dict) else payload
    jobs = [job for job in jobs if job['name'].startswith('paired unit node 24 shard ')]
    assert len(jobs) == 5 and all(job['conclusion'] == 'success' for job in jobs)
    assert set(job['name'] for job in jobs) == {f'paired unit node 24 shard {index}/5' for index in range(1, 6)}
    parse = lambda value: datetime.fromisoformat(value.replace('Z', '+00:00'))
    starts = [parse(job['started_at']) for job in jobs]
    ends = [parse(job['completed_at']) for job in jobs]
    active = [(end - start).total_seconds() for start, end in zip(starts, ends)]
    actual_jobs = dict(summedActualPairedJobActiveSeconds=sum(active),
                       maximumActualPairedJobActiveSeconds=max(active),
                       observedPairedJobMakespanSeconds=(max(ends) - min(starts)).total_seconds(),
                       scope='Combined pilot jobs: both treatments, shared setup, uploads and post-actions. Not attributable to either arm.')
changes = []
for round_index in rounds:
    baseline = next(row for row in rows if row['round'] == round_index and row['treatment'] == 'baseline')
    candidate = next(row for row in rows if row['round'] == round_index and row['treatment'] == 'candidate')
    saved_sum = baseline['summedTestProcessSeconds'] - candidate['summedTestProcessSeconds']
    saved_max = baseline['maximumShardTestProcessSeconds'] - candidate['maximumShardTestProcessSeconds']
    changes.append(dict(round=round_index, summedTestProcessSecondsSaved=saved_sum,
                        summedTestProcessSavingPercent=100 * saved_sum / baseline['summedTestProcessSeconds'],
                        maximumShardTestProcessSecondsSaved=saved_max,
                        maximumShardSavingPercent=100 * saved_max / baseline['maximumShardTestProcessSeconds']))
result = dict(baseSourceSha=manifest['baseSourceSha'], fixedPlanSha256=manifest['fixedPlanSha256'],
              ordinaryFileCount=len(plan['ordinaryFiles']), timedFileCount=len(plan['files']),
              qualificationExclusions=plan['qualificationExclusions'], untimedQualification=qualification, approvedCaseChanges=accepted_changes,
              rounds=rows, pairedChanges=changes, actualJobs=actual_jobs,
              titleCanonicalization=dict(inputHashes=manifest['caseTitleIdentityHashes'], sourceHashes={value: rule['sourceSha256'] for value, rule in title_rules['files'].items()}, rawTitleDifferences=raw_title_differences),
              metricLimit='Test-process sums are runner capacity consumed during tests. Maximum shard wall measures the test critical path; neither includes queueing or the complete PR workflow.')
Path(args.out).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(baseSourceSha=result['baseSourceSha'], timedFiles=result['timedFileCount'],
                     excludedQualificationFiles=len(result['qualificationExclusions']), rounds=rows,
                     pairedChanges=changes, approvedCaseChangeFiles=len(accepted_changes), actualJobs=actual_jobs), indent=2))
