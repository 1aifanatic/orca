import argparse
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import time

from qoder_artifacts import ARMS, ORDERS, REQUIRED_ARTIFACTS, compare, load_bundle, sha, validate_report

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--execute', action='store_true')
args = parser.parse_args()
root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
out = args.out.resolve()
assert out != root and root not in out.parents and bundle != root and root not in bundle.parents
out.mkdir(parents=True, exist_ok=True)
shutil.copyfile(bundle / 'manifest.json', out / 'manifest.json')
records = []
failure = None


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, timeout=30).decode().strip()


def source_snapshot():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=root, timeout=30).decode().rstrip('\n'),
            'changedPaths': git('diff', 'HEAD', '--name-only').splitlines(),
            'stagedPaths': git('diff', '--cached', '--name-only').splitlines()}


def verify_source(manifest, guards, arm):
    state = source_snapshot()
    assert state['head'] == manifest['sourceSha']
    assert state['tree'] == manifest['sourceTreeGitOid']
    assert not state['stagedPaths'], 'Never stage the temporary source overlay'
    expected_paths = [] if arm == 'original' else sorted(row['file'] for row in manifest['subjects'])
    assert state['changedPaths'] == expected_paths, 'Unexpected tracked source change'
    assert state['status'] == '\n'.join(' M ' + path for path in expected_paths), 'Unexpected checkout changes or untracked files'
    subjects_by_path = {row['file']: row for row in manifest['subjects']}
    for path, guard in guards.items():
        target = root / path
        assert target.is_file() and not target.is_symlink(), 'Unexpected input path: ' + path
        expected = subjects_by_path[path][arm + 'Sha256'] if path in subjects_by_path else guard['sha256']
        assert sha(target.read_bytes()) == expected, 'Source input changed: ' + path
        assert bool(target.stat().st_mode & 0o111) == (guard['gitMode'] == '100755'), 'Input executable mode changed: ' + path
    return state


def terminate_owned_group(process):
    # Kill the original group even when its leader exits after TERM.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=5)


class Interrupted(Exception):
    pass


def on_signal(number, frame):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    raise Interrupted('Signal ' + str(number))


signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT, on_signal)


def invoke(command, env, log, timeout):
    started = time.perf_counter()
    timed_out = False
    with log.open('x') as stream:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            terminate_owned_group(process)
            status = process.returncode
        except BaseException:
            terminate_owned_group(process)
            raise
    return status, time.perf_counter() - started, timed_out


manifest = None
sources = None


def require_owned_source_paths():
    assert git('rev-parse', 'HEAD') == manifest['sourceSha']
    assert git('rev-parse', 'HEAD^{tree}') == manifest['sourceTreeGitOid']
    # Preflight both subjects before writing either, preserving concurrent edits.
    for row in manifest['subjects']:
        path = row['file']
        source = root / path
        assert source.is_file() and not source.is_symlink(), 'Missing or unexpected owned path: ' + path
        assert source.read_bytes() in sources[path].values(), 'Unknown concurrent owned bytes: ' + path


def restore_owned_sources():
    refused = {}
    checkout_changed = git('rev-parse', 'HEAD') != manifest['sourceSha'] or git('rev-parse', 'HEAD^{tree}') != manifest['sourceTreeGitOid']
    for row in manifest['subjects']:
        path = row['file']
        source = root / path
        reason = None
        if checkout_changed:
            reason = 'Checkout changed; preserving the new checkout'
        elif not source.is_file() or source.is_symlink():
            reason = 'Missing or unexpected subject path; preserving it'
        elif source.read_bytes() not in sources[path].values():
            reason = 'Unknown concurrent subject bytes; preserving them'
        if reason is not None:
            refused[path] = {'reason': reason, 'savedOriginalPath': str(bundle / row['originalAsset'])}
        else:
            source.write_bytes(sources[path]['original'])
    if refused:
        write_json(out / 'restore-refused.json', {'refused': refused, 'runId': os.environ.get('GITHUB_RUN_ID'),
                                                'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT')})
        raise RuntimeError('Subject restoration refused; unknown contents preserved and known subjects restored')


try:
    manifest, expected_cases, guards, manifest_hash = load_bundle(bundle)
    if not args.execute:
        print(json.dumps({'dryRun': True, 'sourceSha': manifest['sourceSha'], 'orders': manifest['orders'],
                          'workers': 4, 'cases': 85, 'invocationTimeoutSeconds': 180}))
        raise SystemExit(0)
    assert os.environ.get('GITHUB_ACTIONS') == 'true' and platform.system() == 'Linux'
    assert platform.machine().lower() in ['arm64', 'aarch64'], 'Use the Linux ARM runner'
    assert not os.environ.get('NODE_COMPILE_CACHE'), 'Do not share a Node compile cache'
    assert '--compile-cache' not in os.environ.get('NODE_OPTIONS', '')
    assert not any(key.startswith('ORCA_CURSOR_CAPTURE') for key in os.environ), 'Capture and timing are separate'
    run_id, run_attempt = os.environ.get('GITHUB_RUN_ID'), os.environ.get('GITHUB_RUN_ATTEMPT')
    assert run_id and run_attempt
    node = subprocess.check_output(['node', '--version'], text=True).strip()
    pnpm = subprocess.check_output(['pnpm', '--version'], text=True).strip()
    assert node == 'v' + manifest['nodeVersion'] and pnpm == manifest['pnpmVersion']
    runtime = {'runId': run_id, 'runAttempt': run_attempt, 'workflowRef': os.environ.get('GITHUB_WORKFLOW_REF'),
               'bootstrapEventSha': os.environ.get('GITHUB_SHA'), 'node': node, 'pnpm': pnpm,
               'platformSystem': platform.system(), 'platformMachine': platform.machine(),
               'runnerName': os.environ.get('RUNNER_NAME'), 'runnerOS': os.environ.get('RUNNER_OS'),
               'runnerArch': os.environ.get('RUNNER_ARCH'), 'manifestSha256': manifest_hash}
    write_json(out / 'runtime.json', runtime)
    sources = {row['file']: {arm: (bundle / row[arm + 'Asset']).read_bytes() for arm in ARMS}
               for row in manifest['subjects']}
    require_owned_source_paths()
    assert all((root / path).read_bytes() == arms['original'] for path, arms in sources.items())
    write_json(out / 'initial-source.json', verify_source(manifest, guards, 'original'))
    installed_hashes = {}
    for path, expected in manifest['installedToolHashes'].items():
        installed_hashes[path] = sha((root / path).read_bytes())
        assert installed_hashes[path] == expected, 'Installed tool input changed: ' + path
    write_json(out / 'installed-tools.json', installed_hashes)
    config_text = (bundle / 'paired.config.template.ts').read_text()
    config_text = config_text.replace("'__VITEST_CONFIG__'", json.dumps(str(root / 'node_modules/vitest/dist/config.js')))
    config_text = config_text.replace("'__BASE_CONFIG__'", json.dumps(str(root / 'config/vitest.config.ts')))
    config_text = config_text.replace("'__OBSERVED_REPORTER__'", json.dumps(str(bundle / 'observed-runtime-reporter.mjs')))
    assert all(token not in config_text for token in ['__VITEST_CONFIG__', '__BASE_CONFIG__', '__OBSERVED_REPORTER__'])
    config = out / 'paired.config.ts'
    config.write_text(config_text)
    config_hash = sha(config.read_bytes())
    for round_index, order in enumerate(ORDERS, 1):
        for position, arm in enumerate(order, 1):
            load_bundle(bundle)
            before = verify_source(manifest, guards, 'original')
            assert all(sha((root / path).read_bytes()) == digest for path, digest in installed_hashes.items())
            directory = out / f'round-{round_index}' / arm
            directory.mkdir(parents=True, exist_ok=False)
            cache = directory / 'vite-cache'
            cache.mkdir()
            assert not list(cache.iterdir())
            write_json(directory / 'source-before-overlay.json', before)
            record = {**runtime, 'round': round_index, 'position': position, 'arm': arm,
                      'checkoutRoot': str(root), 'bundleRoot': str(bundle), 'outputRoot': str(out),
                      'cacheRoot': str(cache), 'sourceHeadBefore': before['head'], 'sourceTreeBefore': before['tree'],
                      'sourceCleanBeforeOverlay': not before['status'], 'overlaySha256ByPath': {path: sha(arms[arm]) for path, arms in sources.items()},
                      'cacheStartedEmpty': True, 'filesystemTransformCache': False, 'nodeCompileCache': False,
                      'workers': 4, 'configSha256': config_hash, 'exitCode': None, 'timedOut': False,
                      'wallSeconds': None, 'sourceOverlayIntactAfterInvocation': False,
                      'sourceCleanAfterRestoration': False, 'artifactHashes': {}, 'valid': False}
            write_json(directory / 'run-record.json', record)
            invocation_error = None
            try:
                require_owned_source_paths()
                for path, arms in sources.items():
                    source = root / path
                    assert source.is_file() and not source.is_symlink() and source.read_bytes() in arms.values()
                    source.write_bytes(arms[arm])
                write_json(directory / 'source-overlay.json', verify_source(manifest, guards, arm))
                env = os.environ.copy()
                env.pop('NODE_COMPILE_CACHE', None)
                env.update(ORCA_BACKGROUND_LAUNCH='1', UPDATE_READINESS_CENSUS='0', ORCA_BALANCE_UNIT_SHARDS='0',
                           NODE_DISABLE_COMPILE_CACHE='1', NO_COLOR='1',
                           ORCA_QODER_PAIR_CACHE=str(cache), ORCA_QODER_PAIR_REPORT=str(directory / 'vitest.json'),
                           ORCA_QODER_SCREEN_RUNTIME_RECEIPT=str(directory / 'observed-runtime.json'))
                command = ['pnpm', 'exec', 'vitest', 'run', '--config', str(config), *manifest['testPaths'],
                           '--maxWorkers', '4', '--experimental.fsModuleCache=false']
                write_json(directory / 'command.json', {'argv': command, 'cwd': str(root), 'environment': {
                    key: env[key] for key in ['ORCA_BACKGROUND_LAUNCH', 'UPDATE_READINESS_CENSUS', 'ORCA_BALANCE_UNIT_SHARDS',
                                             'NODE_DISABLE_COMPILE_CACHE', 'NO_COLOR', 'ORCA_QODER_PAIR_CACHE', 'ORCA_QODER_PAIR_REPORT',
                                             'ORCA_QODER_SCREEN_RUNTIME_RECEIPT']},
                    'NODE_COMPILE_CACHEPresent': 'NODE_COMPILE_CACHE' in env, 'timeoutSeconds': 180})
                code, elapsed, timed_out = invoke(command, env, directory / 'vitest.log', 180)
                record.update(exitCode=code, wallSeconds=elapsed, timedOut=timed_out)
                after_overlay = verify_source(manifest, guards, arm)
                assert all(sha((root / path).read_bytes()) == digest for path, digest in installed_hashes.items())
                write_json(directory / 'source-after-invocation.json', after_overlay)
                record['sourceOverlayIntactAfterInvocation'] = True
            except BaseException as error:
                invocation_error = error
                record['invocationError'] = repr(error)
            finally:
                restore_owned_sources()
                after = verify_source(manifest, guards, 'original')
                write_json(directory / 'source-after-restoration.json', after)
                record.update(sourceHeadAfter=after['head'], sourceTreeAfter=after['tree'], sourceCleanAfterRestoration=not after['status'])
                try:
                    assert sha(config.read_bytes()) == config_hash
                    validate_report(directory, record, manifest, expected_cases, write_census=True)
                    record['valid'] = True
                except (AssertionError, KeyError, FileNotFoundError, json.JSONDecodeError, TypeError, ValueError) as error:
                    record['validationError'] = str(error)
                record['artifactHashes'] = {name: sha((directory / name).read_bytes()) for name in REQUIRED_ARTIFACTS if (directory / name).exists()}
                records.append(record)
                write_json(directory / 'run-record.json', record)
                write_json(out / 'summary.json', records)
                print(json.dumps({key: value for key, value in record.items() if key != 'artifactHashes'}), flush=True)
            if invocation_error is not None:
                raise invocation_error
            assert record['valid'], 'Invalid invocation; no additional timing arms'
except BaseException as error:
    if not isinstance(error, SystemExit) or error.code not in [0, None]:
        failure = repr(error)
        write_json(out / 'driver-failure.json', {'error': failure, 'completedRecords': len(records),
                                              'runId': os.environ.get('GITHUB_RUN_ID'), 'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT')})
    raise
finally:
    if sources is not None:
        try:
            restore_owned_sources()
            load_bundle(bundle)
            final = verify_source(manifest, guards, 'original')
            assert all(sha((root / path).read_bytes()) == digest for path, digest in manifest['installedToolHashes'].items())
            final.update(runId=os.environ.get('GITHUB_RUN_ID'), runAttempt=os.environ.get('GITHUB_RUN_ATTEMPT'),
                         manifestSha256=manifest_hash,
                         sourceSha256ByPath={path: sha((root / path).read_bytes()) for path in sources},
                         capturedAtUnixMs=time.time_ns() // 1_000_000)
            write_json(out / 'final-source.json', final)
        except BaseException as error:
            write_json(out / 'final-source-failed.json', {'error': repr(error)})
            if failure is None:
                raise

if args.execute:
    try:
        write_json(out / 'preliminary-comparison.json', compare(out, bundle, preliminary=True))
    except BaseException as error:
        write_json(out / 'comparison-failed.json', {'error': repr(error), 'runId': os.environ.get('GITHUB_RUN_ID'),
                                                'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT')})
        raise
