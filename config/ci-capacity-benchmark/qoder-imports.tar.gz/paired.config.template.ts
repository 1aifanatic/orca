import { defineConfig } from '__VITEST_CONFIG__'
import base from '__BASE_CONFIG__'

if (base.test?.experimental?.fsModuleCache) {
  throw new Error('This trial keeps the filesystem transform cache disabled')
}
export default defineConfig({
  ...base,
  cacheDir: process.env.ORCA_QODER_PAIR_CACHE,
  test: {
    ...base.test,
    cache: false,
    maxWorkers: 4,
    pool: 'forks',
    isolate: true,
    experimental: { ...base.test?.experimental, fsModuleCache: false },
    reporters: ['default', 'json', '__OBSERVED_REPORTER__'],
    outputFile: { json: process.env.ORCA_QODER_PAIR_REPORT }
  }
})
