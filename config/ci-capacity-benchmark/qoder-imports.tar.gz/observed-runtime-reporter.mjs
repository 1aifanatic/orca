import { writeFileSync } from 'node:fs'

export default class ObservedRuntimeReporter {
  onInit(ctx) {
    this.ctx = ctx
  }

  onTestRunEnd(testModules, unhandledErrors, reason) {
    const destination = process.env.ORCA_QODER_SCREEN_RUNTIME_RECEIPT
    if (!destination) {
      throw new Error('Runtime receipt destination is required')
    }
    const config = this.ctx.config
    writeFileSync(
      destination,
      JSON.stringify(
        {
          reporterReached: true,
          reason,
          moduleCount: testModules.length,
          unhandledErrorCount: unhandledErrors.length,
          unhandledErrors: unhandledErrors.map((error) => ({
            name: error?.name,
            message: error?.message ?? String(error),
            stack: error?.stack
          })),
          root: config.root,
          maxWorkers: config.maxWorkers,
          pool: config.pool,
          isolate: config.isolate,
          resultsCacheDisabled: config.cache === false,
          fsModuleCacheDisabled: config.experimental?.fsModuleCache === false,
          nodeVersion: process.version,
          nodeCompileCacheDisabled: process.env.NODE_DISABLE_COMPILE_CACHE === '1',
          backgroundLaunch: process.env.ORCA_BACKGROUND_LAUNCH === '1',
          projects: this.ctx.projects.map((project) => ({
            name: project.name,
            viteCacheDir: project.vite.config.cacheDir
          }))
        },
        null,
        2
      ) + '\n'
    )
  }
}
