import collections
from datetime import datetime
import hashlib
import json
from pathlib import Path

ARMS = ('original', 'candidate')
ORDERS = (('original', 'candidate'), ('candidate', 'original'), ('original', 'candidate'))
REQUIRED_ARTIFACTS = ('vitest.json', 'vitest.log', 'case-census.json', 'title-multiplicity.json', 'command.json',
                      'source-before-overlay.json', 'source-overlay.json', 'source-after-invocation.json',
                      'source-after-restoration.json', 'observed-runtime.json')


def sha(contents):
    return hashlib.sha256(contents).hexdigest()


def load_bundle(bundle):
    manifest_path = bundle / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert manifest['schemaVersion'] == 1
    assert manifest['sourceSha'] == 'e46fa0df137ff1ac54ac8c92d88b943bcd46454c'
    assert manifest['sourceTreeGitOid'] == 'de5ed878ba2e7688ee22400e5abdfced882e2132'
    assert manifest['nodeVersion'] == '24.21.0' and manifest['pnpmVersion'] == '12.8.1'
    assert manifest['workers'] == 4 and manifest['invocationTimeoutSeconds'] == 180
    assert manifest['rounds'] == 3 and manifest['expectedCaseCount'] == 1415
    assert manifest['orders'] == [list(order) for order in ORDERS]
    assert manifest['testPaths'] == [
        'src/main/runtime/orca-runtime.test.ts',
        'src/main/runtime/rpc/methods/structured-agent-session.test.ts',
        'src/main/runtime/rpc/methods/mobile-web-bundle-range.test.ts',
        'src/main/runtime/rpc/methods/client-events.test.ts']
    assert [row['file'] for row in manifest['subjects']] == manifest['testPaths'][:1]
    assert manifest['countsByFile'] == dict(zip(manifest['testPaths'], [1352, 54, 7, 2]))
    names = set(manifest['inputHashes']) | {'manifest.json'}
    actual = {path.name for path in bundle.iterdir() if path.is_file()}
    assert actual == names, 'Missing or unexpected portable bundle files'
    for name, expected in manifest['inputHashes'].items():
        assert Path(name).name == name, 'Portable asset must be top level'
        assert sha((bundle / name).read_bytes()) == expected, 'Bundle changed: ' + name
    expected_hashes = [['94b59084fbe2aa0d8eaac657e541b20ed5cbd491c9cc6c7863debd03713c35d0', 'c6235ad11836b95228de60502fb95d949845179e0e334ad2bb893ed307d61ee6']]
    guards = json.loads((bundle / 'source-guards.json').read_text())
    assert len(guards) == manifest['sourceGuardCount']
    for index, row in enumerate(manifest['subjects']):
        for arm_index, arm in enumerate(ARMS):
            assert row[arm + 'Sha256'] == expected_hashes[index][arm_index]
            assert manifest['inputHashes'][row[arm + 'Asset']] == row[arm + 'Sha256']
        assert row['addedBytes'] == "import './rpc/unused-default-rpc-methods.test-fixture'\n\n"
        assert (bundle / row['candidateAsset']).read_bytes() == row['addedBytes'].encode() + (bundle / row['originalAsset']).read_bytes()
        assert guards[row['file']]['sha256'] == row['originalSha256']
    expected_cases = json.loads((bundle / 'expected-cases.json').read_text())
    assert len(expected_cases) == 1415
    assert [case for case in expected_cases if case['status'] != 'passed'] == [{'file': 'src/main/runtime/orca-runtime.test.ts', 'ancestorTitles': ['OrcaRuntimeService'], 'fullName': 'OrcaRuntimeService lists drive roots for a server-root browse', 'status': 'skipped', 'title': 'lists drive roots for a server-root browse'}]
    assert collections.Counter(case['file'] for case in expected_cases) == manifest['countsByFile']
    return manifest, expected_cases, guards, sha(manifest_path.read_bytes())


def read_cases(report, root, test_paths):
    modules = report['testResults']
    assert len(modules) == 4, 'Runtime compatibility entry and three actual catalogs must execute'
    expected_names = {str(root / path): path for path in test_paths}
    actual_names = [module['name'] for module in modules]
    assert len(set(actual_names)) == 4 and set(actual_names) == set(expected_names), 'Raw report names missing/additional/duplicate files'
    cases = []
    for module in modules:
        assert module['status'] == 'passed' and not module.get('message', '')
        for case in module['assertionResults']:
            assert not case.get('failureMessages', [])
            cases.append({'file': expected_names[module['name']],
                          **{key: case[key] for key in ['ancestorTitles', 'fullName', 'status', 'title']}})
    return sorted(cases, key=lambda case: json.dumps(case, sort_keys=True))


def validate_report(directory, record, manifest, expected_cases, write_census=False):
    assert record['exitCode'] == 0 and not record['timedOut']
    assert record['sourceCleanBeforeOverlay'] and record['sourceCleanAfterRestoration']
    assert record['sourceOverlayIntactAfterInvocation']
    assert record['sourceHeadBefore'] == manifest['sourceSha']
    assert record['sourceHeadAfter'] == manifest['sourceSha']
    assert record['sourceTreeBefore'] == manifest['sourceTreeGitOid']
    assert record['sourceTreeAfter'] == manifest['sourceTreeGitOid']
    assert record['filesystemTransformCache'] is False and record['nodeCompileCache'] is False
    assert record['cacheStartedEmpty'] is True and record['workers'] == 4
    assert record['node'] == 'v' + manifest['nodeVersion']
    assert record['pnpm'] == manifest['pnpmVersion']
    assert record['wallSeconds'] > 0
    report = json.loads((directory / 'vitest.json').read_text())
    assert report['success'] is True
    assert report['numTotalTests'] == 1415 and report['numPassedTests'] == 1414
    assert report['numFailedTests'] == 0 and report['numPendingTests'] == 1
    assert report.get('numTodoTests', 0) == 0
    assert report['numFailedTestSuites'] == 0 and report['numPendingTestSuites'] == 0
    assert report.get('numUnhandledErrors', 0) == 0
    assert report.get('numRuntimeErrorTestSuites', 0) == 0
    assert not report.get('unhandledErrors', [])
    snapshots = report['snapshot']
    assert snapshots['didUpdate'] is False and snapshots['failure'] is False
    assert snapshots['added'] == 0 and snapshots['updated'] == 0 and snapshots['unmatched'] == 0
    log = (directory / 'vitest.log').read_text(errors='replace')
    assert not any(marker in log for marker in ['Unhandled Errors', 'Unhandled Rejection', 'Uncaught Exception'])
    cases = read_cases(report, Path(record['checkoutRoot']), manifest['testPaths'])
    expected = sorted(expected_cases, key=lambda case: json.dumps(case, sort_keys=True))
    assert cases == expected, 'Case titles/status/ancestry/multiplicity changed'
    assert len(cases) == 1415
    assert collections.Counter(case['file'] for case in cases) == manifest['countsByFile']
    observed = json.loads((directory / 'observed-runtime.json').read_text())
    assert observed['reporterReached'] is True and observed['reason'] == 'passed'
    assert observed['moduleCount'] == 4
    assert observed['unhandledErrorCount'] == 0 and observed['unhandledErrors'] == []
    assert observed['root'] == record['checkoutRoot']
    assert observed['maxWorkers'] == 4 and observed['pool'] == 'forks'
    assert observed['isolate'] is True and observed['backgroundLaunch'] is True
    assert observed['resultsCacheDisabled'] is True and observed['fsModuleCacheDisabled'] is True
    assert observed['nodeCompileCacheDisabled'] is True and observed['nodeVersion'] == record['node']
    assert len(observed['projects']) == 1 and observed['projects'][0]['name'] == ''
    expected_cache = Path(record['cacheRoot']) / 'vitest' / hashlib.sha1(b'').hexdigest()
    assert observed['projects'][0]['viteCacheDir'] == str(expected_cache)
    census = json.dumps(cases, indent=2) + '\n'
    multiplicity = sorted(collections.Counter((case['file'], case['fullName']) for case in cases).items())
    multiplicity_text = json.dumps(multiplicity, indent=2) + '\n'
    if write_census:
        (directory / 'case-census.json').write_text(census)
        (directory / 'title-multiplicity.json').write_text(multiplicity_text)
    else:
        assert (directory / 'case-census.json').read_text() == census
        assert (directory / 'title-multiplicity.json').read_text() == multiplicity_text
    return cases


def compare(directory, bundle, run_metadata=None, jobs_metadata=None, preliminary=False):
    manifest, expected_cases, guards, manifest_hash = load_bundle(bundle)
    failure_markers = sorted(str(path.relative_to(directory)) for path in directory.rglob('*.json')
                             if path.name.endswith(('-failure.json', '-failed.json', '-refused.json')))
    assert not failure_markers, 'Failure or restoration refusal evidence present: ' + ', '.join(failure_markers)
    records = json.loads((directory / 'summary.json').read_text())
    assert len(records) == 6, 'Require all three healthy original/candidate pairs'
    assert sha((directory / 'manifest.json').read_bytes()) == manifest_hash
    assert records[0]['runId'] and records[0]['runAttempt']
    assert len({(row['runId'], row['runAttempt'], row['node'], row['pnpm'], row['platformSystem'], row['platformMachine'],
                 row['checkoutRoot'], row['bundleRoot'], row['outputRoot']) for row in records}) == 1
    assert records[0]['platformSystem'] == 'Linux'
    assert records[0]['platformMachine'].lower() in ['aarch64', 'arm64']
    assert json.loads((directory / 'installed-tools.json').read_text()) == manifest['installedToolHashes']
    runtime = json.loads((directory / 'runtime.json').read_text())
    assert runtime['manifestSha256'] == manifest_hash
    assert runtime['runId'] == records[0]['runId'] and runtime['runAttempt'] == records[0]['runAttempt']
    final = json.loads((directory / 'final-source.json').read_text())
    assert final['runId'] == records[0]['runId'] and final['runAttempt'] == records[0]['runAttempt']
    assert final['manifestSha256'] == manifest_hash
    assert final['head'] == manifest['sourceSha'] and final['tree'] == manifest['sourceTreeGitOid']
    assert final['status'] == '' and final['changedPaths'] == [] and final['stagedPaths'] == []
    assert final['sourceSha256ByPath'] == {row['file']: row['originalSha256'] for row in manifest['subjects']}
    assert isinstance(final['capturedAtUnixMs'], int) and final['capturedAtUnixMs'] > 0
    config_hash = sha((directory / 'paired.config.ts').read_bytes())
    expected_config = (bundle / 'paired.config.template.ts').read_text()
    checkout_root = Path(records[0]['checkoutRoot'])
    expected_config = expected_config.replace("'__VITEST_CONFIG__'", json.dumps(str(checkout_root / 'node_modules/vitest/dist/config.js')))
    expected_config = expected_config.replace("'__BASE_CONFIG__'", json.dumps(str(checkout_root / 'config/vitest.config.ts')))
    expected_config = expected_config.replace("'__OBSERVED_REPORTER__'", json.dumps(str(Path(records[0]['bundleRoot']) / 'observed-runtime-reporter.mjs')))
    assert (directory / 'paired.config.ts').read_text() == expected_config
    pairs = []
    for round_index, order in enumerate(ORDERS, 1):
        pair = {}
        for position, arm in enumerate(order, 1):
            index = (round_index - 1) * 2 + position - 1
            record = records[index]
            assert record['round'] == round_index and record['position'] == position
            assert record['arm'] == arm and record['valid'] is True
            assert not any(key in record for key in ['invocationError', 'validationError', 'restorationError'])
            assert record['manifestSha256'] == manifest_hash
            expected_sources = {row['file']: row[arm + 'Sha256'] for row in manifest['subjects']}
            assert record['overlaySha256ByPath'] == expected_sources
            assert record['configSha256'] == config_hash
            arm_dir = directory / f'round-{round_index}' / arm
            assert json.loads((arm_dir / 'run-record.json').read_text()) == record
            assert set(record['artifactHashes']) == set(REQUIRED_ARTIFACTS)
            for name, digest in record['artifactHashes'].items():
                assert sha((arm_dir / name).read_bytes()) == digest, 'Artifact changed: ' + name
            for name, overlay in [('source-before-overlay.json', False), ('source-overlay.json', arm == 'candidate'),
                                  ('source-after-invocation.json', arm == 'candidate'), ('source-after-restoration.json', False)]:
                state = json.loads((arm_dir / name).read_text())
                assert state['head'] == manifest['sourceSha'] and state['tree'] == manifest['sourceTreeGitOid']
                assert state['stagedPaths'] == []
                expected_paths = sorted(row['file'] for row in manifest['subjects']) if overlay else []
                assert state['changedPaths'] == expected_paths
                assert state['status'] == '\n'.join(' M ' + path for path in expected_paths)
            command = json.loads((arm_dir / 'command.json').read_text())
            expected_argv = ['pnpm', 'exec', 'vitest', 'run', '--config', str(directory / 'paired.config.ts'),
                             *manifest['testPaths'], '--maxWorkers', '4', '--experimental.fsModuleCache=false']
            # Artifact download paths differ; the original command points to its recorded runner output root.
            runner_config = command['argv'][5]
            assert runner_config == str(Path(record['outputRoot']) / 'paired.config.ts')
            expected_argv[5] = runner_config
            assert command['argv'] == expected_argv and command['cwd'] == record['checkoutRoot']
            assert command['environment']['ORCA_BACKGROUND_LAUNCH'] == '1'
            assert command['environment']['UPDATE_READINESS_CENSUS'] == '0'
            assert command['environment']['ORCA_BALANCE_UNIT_SHARDS'] == '0'
            assert command['environment']['NODE_DISABLE_COMPILE_CACHE'] == '1'
            assert command['NODE_COMPILE_CACHEPresent'] is False and command['timeoutSeconds'] == 180
            assert command['environment']['ORCA_QODER_PAIR_CACHE'] == record['cacheRoot']
            assert command['environment']['ORCA_QODER_PAIR_REPORT'] == str(Path(record['outputRoot']) / f'round-{round_index}' / arm / 'vitest.json')
            assert command['environment']['ORCA_QODER_SCREEN_RUNTIME_RECEIPT'] == str(Path(record['outputRoot']) / f'round-{round_index}' / arm / 'observed-runtime.json')
            assert command['environment']['NO_COLOR'] == '1'
            assert record['cacheRoot'] == str(Path(record['outputRoot']) / f'round-{round_index}' / arm / 'vite-cache')
            validate_report(arm_dir, record, manifest, expected_cases)
            pair[arm] = record['wallSeconds']
        pairs.append({'round': round_index, 'order': list(order), **pair,
                      'pairedSavingSeconds': pair['original'] - pair['candidate'],
                      'pairedSavingPercent': (pair['original'] - pair['candidate']) / pair['original'] * 100})
    import statistics
    terminal = None
    if preliminary:
        assert run_metadata is None and jobs_metadata is None
    else:
        assert run_metadata is not None and jobs_metadata is not None, 'Actual completed run and attempt-specific jobs metadata required'
        run = run_metadata
        jobs_payload = jobs_metadata
        assert str(run['id']) == records[0]['runId'] and str(run['run_attempt']) == records[0]['runAttempt']
        assert run['status'] == 'completed' and run['conclusion'] == 'success'
        assert run['event'] == 'workflow_dispatch'
        assert run['path'].split('@', 1)[0] == manifest['workflowDestination']
        assert str(jobs_payload['runId']) == records[0]['runId'] and str(jobs_payload['runAttempt']) == records[0]['runAttempt']
        jobs = jobs_payload['jobs']
        assert len(jobs) == 1 and jobs_payload.get('total_count', 1) == 1
        job = jobs[0]
        assert job['name'] == 'Runtime compatibility import guard paired node24 ARM4'
        assert str(job['run_id']) == records[0]['runId'] and str(job['run_attempt']) == records[0]['runAttempt']
        assert job['status'] == 'completed' and job['conclusion'] == 'success'
        started_ms = datetime.fromisoformat(job['started_at'].replace('Z', '+00:00')).timestamp() * 1000
        completed_ms = datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00')).timestamp() * 1000
        assert started_ms <= completed_ms
        assert started_ms - 30_000 <= final['capturedAtUnixMs'] <= completed_ms + 30_000
        bootstrap = json.loads((directory / 'bootstrap.json').read_text())
        assert bootstrap['runId'] == records[0]['runId'] and bootstrap['runAttempt'] == records[0]['runAttempt']
        assert bootstrap['bootstrapSha'] == run['head_sha'] and bootstrap['eventSha'] == run['head_sha']
        assert runtime['bootstrapEventSha'] == run['head_sha']
        shared = json.loads((directory / 'shared-setup.json').read_text())
        checkout = json.loads((directory / 'checkout.json').read_text())
        for value in [shared, checkout]:
            assert value['runId'] == records[0]['runId'] and value['runAttempt'] == records[0]['runAttempt']
            assert value['sourceSha'] == manifest['sourceSha'] and value['sourceTree'] == manifest['sourceTreeGitOid']
        assert checkout['sourceStatus'] == ''
        assert shared['node'] == records[0]['node'] and shared['pnpm'] == records[0]['pnpm']
        assert shared['platformSystem'] == 'Linux' and shared['platformMachine'].lower() in ['aarch64', 'arm64']
        report_windows = []
        for round_index, order in enumerate(ORDERS, 1):
            for arm in order:
                report = json.loads((directory / f'round-{round_index}' / arm / 'vitest.json').read_text())
                report_start = report['startTime']
                report_end = max(module['endTime'] for module in report['testResults'])
                assert all(report_start <= module['startTime'] <= module['endTime'] <= report_end for module in report['testResults'])
                assert started_ms - 30_000 <= report_start <= report_end <= final['capturedAtUnixMs']
                assert report_end <= completed_ms + 30_000
                report_windows.append([report_start, report_end])
        assert all(left[1] <= right[0] for left, right in zip(report_windows, report_windows[1:])), 'Reported invocations overlap or run order changed'
        terminal = {'runId': str(run['id']), 'runAttempt': str(run['run_attempt']), 'runStatus': run['status'],
                    'runConclusion': run['conclusion'], 'bootstrapSha': run['head_sha'], 'jobId': str(job['id']),
                    'jobName': job['name'], 'jobStatus': job['status'], 'jobConclusion': job['conclusion'],
                    'jobStartedAt': job['started_at'], 'jobCompletedAt': job['completed_at']}
    return {'status': 'preliminary' if preliminary else 'passed',
            'qualification': 'Preliminary inside running job; terminal job outcome remains unobserved.' if preliminary else 'All six healthy reports, final source restoration and actual terminal successful run/job metadata verified.',
            'sourceSha': manifest['sourceSha'], 'sourceTreeGitOid': manifest['sourceTreeGitOid'],
            'manifestSha256': manifest_hash, 'runId': records[0]['runId'], 'runAttempt': records[0]['runAttempt'],
            'pairs': pairs, 'medianOriginalSeconds': statistics.median(row['original'] for row in pairs),
            'medianCandidateSeconds': statistics.median(row['candidate'] for row in pairs),
            'medianPairedSavingSeconds': statistics.median(row['pairedSavingSeconds'] for row in pairs),
            'medianPairedSavingPercent': statistics.median(row['pairedSavingPercent'] for row in pairs),
            'terminalMetadata': terminal,
            'finalSourceSha256': sha((directory / 'final-source.json').read_bytes()),
            'limitation': 'One fixed four-worker four-file 1415-case cohort; no full-shard, PR latency, queue or organization capacity forecast.'}
