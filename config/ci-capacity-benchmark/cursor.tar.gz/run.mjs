import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const output = resolve(process.argv[2] || join(root, 'artifacts/cursor-scratch-benchmark'))
const controlsOnly = process.argv.includes('--controls-only')
const captureSmoke = process.argv.includes('--capture-smoke')
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const sourcePath = join(root, 'src/shared/terminal-cursor-line-context.ts')
const projectionPath = join(root, 'src/main/runtime/orca-runtime-terminal-projection.ts')
const focusedFile = 'src/main/daemon/terminal-cursor-line-context.test.ts'
const shardFiles = Array.from({ length: 6 }, (_, index) => `src/main/runtime/readiness-census-transcripts-${index + 1}.test.ts`)
const consumerFiles = [focusedFile, 'src/shared/terminal-composer-draft.test.ts', 'src/renderer/src/components/terminal-pane/terminal-ime-composer-placeholder-mask.test.ts']
const candidate = readFileSync(sourcePath, 'utf8')
const baseline = readFileSync(join(import.meta.dirname, 'baseline-cursor-context.ts'), 'utf8')
const projection = readFileSync(projectionPath, 'utf8')
const setupPath = join(root, 'artifacts/cursor-scratch-capture.setup.ts')
const captureConfigPath = join(root, 'artifacts/cursor-scratch-capture.config.ts')
mkdirSync(output, { recursive: true })
mkdirSync(join(root, 'artifacts'), { recursive: true })
const digest = (data) => createHash('sha256').update(data).digest('hex')

function execute(label, files, extraArgs = [], allowFailure = false, capture = false) {
  const reportPath = join(output, `${label}.json`)
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, ...(capture ? ['exec', 'vitest', 'run', '--config', captureConfigPath] : ['test']), ...files, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], cwd: root, env: { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  const wallMs = performance.now() - started
  if (!allowFailure) assert.equal(result.code, 0, describeProcessFailure(result))
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  const tests = report.testResults.flatMap((file) => file.assertionResults)
  return { label, wallMs, bodyMs: tests.reduce((sum, test) => sum + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, failures: report.numFailedTests, cases: tests.map((test) => ({ name: test.fullName, status: test.status })).sort((a, b) => a.name.localeCompare(b.name)), witnesses: tests.filter((test) => test.status === 'failed').map((test) => test.fullName) }
}

function instrumentCursor(source) {
  const generic = source.includes('readTerminalCursorLineContext<Cell')
  return source.replace('export function readTerminalCursorLineContext', 'function readCursorContextUncaptured') + `\nexport function readTerminalCursorLineContext${generic ? '<Cell extends TerminalCursorCell>' : ''}(terminal: TerminalCursorContextSource${generic ? '<Cell>' : ''}, rowsAroundCursor: number): TerminalCursorContext | null {
  const context = readCursorContextUncaptured(terminal, rowsAroundCursor)
  const capture = Reflect.get(globalThis, '__orcaCursorCapture')
  if (typeof capture === 'function') capture('context', context)
  return context
}\n`
}

function instrumentProjection(source) {
  return source.replace('export function projectTerminalVisibleLines', 'function projectVisibleLinesUncaptured') + `\nexport function projectTerminalVisibleLines(emulator: HeadlessEmulator): ReturnType<typeof projectVisibleLinesUncaptured> {
  const projection = projectVisibleLinesUncaptured(emulator)
  const capture = Reflect.get(globalThis, '__orcaCursorCapture')
  if (typeof capture === 'function') capture('projection', projection)
  return projection
}\n`
}

function captureSetup(label) {
  return `import { afterAll, expect } from 'vitest'
import { createHash } from 'node:crypto'
import { appendFileSync } from 'node:fs'
const captures = new Map()
Reflect.set(globalThis, '__orcaCursorCapture', (kind, value) => {
  const key = JSON.stringify([expect.getState().currentTestName, kind])
  let record = captures.get(key)
  if (!record) {
    record = { count: 0, bytes: 0, hash: createHash('sha256') }
    captures.set(key, record)
  }
  const bytes = Buffer.from(JSON.stringify(value), 'utf8')
  const prefix = Buffer.alloc(4)
  prefix.writeUInt32LE(bytes.length)
  record.hash.update(prefix).update(bytes)
  record.count++
  record.bytes += prefix.length + bytes.length
})
afterAll(() => {
  const rows = [...captures].map(([key, record]) => ({ key, count: record.count, bytes: record.bytes, sha256: record.hash.digest('hex') }))
  appendFileSync(${JSON.stringify(join(output, `${label}-capture-`))} + process.pid + '.jsonl', JSON.stringify(rows) + '\\n')
  Reflect.deleteProperty(globalThis, '__orcaCursorCapture')
})\n`
}

function readCapture(label) {
  const rows = readdirSync(output).filter((name) => name.startsWith(`${label}-capture-`) && name.endsWith('.jsonl')).flatMap((name) => readFileSync(join(output, name), 'utf8').trim().split('\n').flatMap((line) => JSON.parse(line))).sort((a, b) => a.key.localeCompare(b.key))
  assert.equal(new Set(rows.map((row) => row.key)).size, rows.length)
  assert(rows.length > (captureSmoke ? 1 : 192), 'capture omitted contexts or projections')
  const payload = JSON.stringify(rows)
  return { rows, contexts: rows.filter((row) => JSON.parse(row.key)[1] === 'context').reduce((sum, row) => sum + row.count, 0), projections: rows.filter((row) => JSON.parse(row.key)[1] === 'projection').reduce((sum, row) => sum + row.count, 0), bytes: rows.reduce((sum, row) => sum + row.bytes, 0), canonicalSha256: digest(payload) }
}

try {
  const samples = []
  const summary = { environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion }, hashes: { baseline: digest(baseline), candidate: digest(candidate), projection: digest(projection) } }
  if (!controlsOnly) {
    let expectedCases
    for (let pair = 1; !captureSmoke && pair <= 3; pair++) {
      for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
        writeFileSync(sourcePath, arm === 'baseline' ? baseline : candidate)
        const run = execute(`${arm}-${pair}`, [shardFiles[1]])
        assert.equal(run.passes, 19)
        assert.equal(run.skips, 0)
        if (!expectedCases) expectedCases = run.cases
        assert.deepEqual(run.cases, expectedCases)
        samples.push({ pair, arm, ...run })
        console.log(JSON.stringify({ pair, arm, wallMs: run.wallMs, bodyMs: run.bodyMs, passes: run.passes }))
      }
    }
    const captures = {}
    let expectedFullCases
    for (const arm of ['baseline', 'candidate']) {
      writeFileSync(sourcePath, instrumentCursor(arm === 'baseline' ? baseline : candidate))
      writeFileSync(projectionPath, instrumentProjection(projection))
      writeFileSync(setupPath, captureSetup(arm))
      writeFileSync(captureConfigPath, `import { mergeConfig } from 'vitest/config'\nimport base from '../config/vitest.config'\nexport default mergeConfig(base, { test: { setupFiles: [${JSON.stringify(setupPath)}] } })\n`)
      const run = execute(`${arm}-full-capture`, captureSmoke ? [shardFiles[1]] : shardFiles, captureSmoke ? ['--testNamePattern', 'codex-0157-plain-ready@unknown'] : [], false, true)
      assert.equal(run.passes, captureSmoke ? 1 : 192)
      assert.equal(run.skips, captureSmoke ? 18 : 0)
      if (!expectedFullCases) expectedFullCases = run.cases
      assert.deepEqual(run.cases, expectedFullCases)
      captures[arm] = readCapture(arm)
      writeFileSync(join(output, `${arm}-canonical-capture.json`), JSON.stringify(captures[arm], null, 2) + '\n')
      console.log(JSON.stringify({ arm, fullCapturePasses: run.passes, contexts: captures[arm].contexts, projections: captures[arm].projections, bytes: captures[arm].bytes, canonicalSha256: captures[arm].canonicalSha256 }))
    }
    assert.deepEqual(captures.candidate, captures.baseline)
    summary.capture = { contexts: captures.candidate.contexts, projections: captures.candidate.projections, bytes: captures.candidate.bytes, canonicalSha256: captures.candidate.canonicalSha256, cases: expectedFullCases }
    summary.samples = samples
    if (!captureSmoke) {
      summary.baseline = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs))
      summary.candidate = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs))
      summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
    }
  }
  writeFileSync(sourcePath, candidate)
  writeFileSync(projectionPath, projection)
  summary.consumers = execute('consumer-controls', consumerFiles)
  assert.equal(summary.consumers.failures, 0)
  const negativeControls = []
  for (const [name, before, after] of [
    ['lost-dim-filter', '!cell || cell.isDim() || cell.getWidth() === 0', '!cell || cell.getWidth() === 0'],
    ['lost-wide-continuation-filter', 'cell.getWidth() === 0', 'false'],
    ['lost-bold-prompt', 'return Boolean(cell.isBold())', 'return false'],
    ['lost-custom-foreground', 'return !cell.isFgDefault()', 'return false'],
    ['trimmed-wrap-boundary', 'return trimRight ? text.trimEnd() : text', 'return text.trimEnd()'],
    ['missing-adapter-fallback', 'buffer.getNullCell?.()', 'buffer.getNullCell()'],
    ['lost-scratch-reuse', 'line.getCell(x, reusableCell)', 'line.getCell(x)']
  ]) {
    assert(candidate.includes(before), `missing mutation marker: ${name}`)
    writeFileSync(sourcePath, candidate.replaceAll(before, after))
    const run = execute(`negative-${name}`, [focusedFile], [], true)
    assert(run.failures > 0, `fault survived: ${name}`)
    negativeControls.push({ name, failures: run.failures, witnesses: run.witnesses })
  }
  summary.negativeControls = negativeControls
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
  console.log(JSON.stringify({ baseline: summary.baseline, candidate: summary.candidate, changePercent: summary.changePercent, controls: summary.consumers.passes, negativeControls }))
} finally {
  writeFileSync(sourcePath, candidate)
  writeFileSync(projectionPath, projection)
  rmSync(setupPath, { force: true })
  rmSync(captureConfigPath, { force: true })
}
