import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path.cwd()
evidence = Path(__file__).resolve().parent
target = root / 'src/renderer/src/components/native-chat/NativeChatStructuredSessionDelivery.test.tsx'
saved = target.read_bytes()
hashes = json.loads((evidence / 'source-hashes.json').read_text())
assert hashlib.sha256(saved).hexdigest() == hashes['candidate-NativeChatStructuredSessionDelivery.test.tsx']
hook = root / 'src/renderer/src/components/native-chat/use-structured-agent-session-outbox-unconfirmed-probe.ts'
assert hashlib.sha256(hook.read_bytes()).hexdigest() == hashes[str(hook.relative_to(root))]
env = os.environ.copy()
env['ORCA_BACKGROUND_LAUNCH'] = '1'
rows = []
try:
    target.write_bytes((evidence / 'NativeChatStructuredSessionDelivery.test.tsx').read_bytes())
    for name, selected in [('early-probe', 'probes the same operation without'),
                           ('target-delay-not-reset', 'restarts probe delay')]:
        config = evidence / 'controls' / (name + '.config.ts')
        assert config.is_file(), 'Run candidate fault controls first'
        result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config),
                                 str(target.relative_to(root)), '--maxWorkers=1', '-t', selected],
                                cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=60)
        (evidence / ('original-' + name + '.log')).write_text(result.stdout)
        if result.returncode:
            print(result.stdout)
            raise AssertionError('Original coarse timing unexpectedly caught ' + name)
        row = {'control': name, 'original_passed': True,
               'candidate_result': 'intended timing assertion failed'}
        rows.append(row)
        print(json.dumps(row), flush=True)
finally:
    target.write_bytes(saved)
(evidence / 'original-boundary-controls-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
