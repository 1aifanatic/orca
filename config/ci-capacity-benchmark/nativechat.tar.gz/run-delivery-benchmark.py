import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path.cwd()
evidence = Path(__file__).resolve().parent
target = root / 'src/renderer/src/components/native-chat/NativeChatStructuredSessionDelivery.test.tsx'
baseline = (evidence / 'NativeChatStructuredSessionDelivery.test.tsx').read_bytes()
candidate = (evidence / 'candidate-NativeChatStructuredSessionDelivery.test.tsx').read_bytes()
original = target.read_bytes()
hashes = json.loads((evidence / 'source-hashes.json').read_text())
for name, data in [('NativeChatStructuredSessionDelivery.test.tsx', baseline),
                   ('candidate-NativeChatStructuredSessionDelivery.test.tsx', candidate)]:
    assert hashlib.sha256(data).hexdigest() == hashes[name], 'Frozen input changed: ' + name
hook = root / 'src/renderer/src/components/native-chat/use-structured-agent-session-outbox-unconfirmed-probe.ts'
assert hashlib.sha256(hook.read_bytes()).hexdigest() == hashes[str(hook.relative_to(root))]
env = os.environ.copy()
env['ORCA_BACKGROUND_LAUNCH'] = '1'
rows = []
expected_cases = None
try:
    for index, variant in enumerate(['baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate'], 1):
        target.write_bytes(baseline if variant == 'baseline' else candidate)
        name = f'{variant}-{index}'
        cmd = ['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
               str(target.relative_to(root)), '--maxWorkers=1', '--reporter=default',
               '--reporter=json', '--outputFile=' + str(evidence / (name + '.json'))]
        start = time.perf_counter()
        result = subprocess.run(cmd, cwd=root, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=180)
        wall = time.perf_counter() - start
        (evidence / (name + '.log')).write_text(result.stdout)
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
        data = json.loads((evidence / (name + '.json')).read_text())
        assert data['numPassedTests'] == 15
        suite = next(item for item in data['testResults'] if item['name'].endswith(target.name))
        cases = sorted((case['fullName'], case['status']) for case in suite['assertionResults'])
        assert len(cases) == 15 and len({name for name, _ in cases}) == 15
        assert all(status == 'passed' for _, status in cases)
        if expected_cases is None:
            assert variant == 'baseline'
            expected_cases = cases
            (evidence / 'expected-cases.json').write_text(json.dumps(cases, indent=2) + '\n')
        assert cases == expected_cases, 'Case names/statuses differ: ' + name
        row = {'variant': variant, 'index': index, 'wall': wall,
               'module_seconds': (suite['endTime'] - suite['startTime']) / 1000,
               'passed': data['numPassedTests'], 'cases_identical': True}
        rows.append(row)
        print(json.dumps(row), flush=True)
        (evidence / 'alternating-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
finally:
    target.write_bytes(original)
for variant in ['baseline', 'candidate']:
    group = [row for row in rows if row['variant'] == variant]
    print(json.dumps({'variant': variant, 'median_wall': statistics.median(row['wall'] for row in group),
                      'median_module': statistics.median(row['module_seconds'] for row in group)}))
print('Restored source hash:', hashlib.sha256(target.read_bytes()).hexdigest())
