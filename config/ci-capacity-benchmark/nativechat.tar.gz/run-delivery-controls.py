import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path.cwd()
evidence = Path(__file__).resolve().parent
control_root = evidence / 'controls'
control_root.mkdir(exist_ok=True)
directory = root / 'src/renderer/src/components/native-chat'
source_path = directory / 'use-structured-agent-session-outbox-unconfirmed-probe.ts'
source = source_path.read_text()
target = directory / 'NativeChatStructuredSessionDelivery.test.tsx'
hashes = json.loads((evidence / 'source-hashes.json').read_text())
assert hashlib.sha256(target.read_bytes()).hexdigest() == hashes['candidate-NativeChatStructuredSessionDelivery.test.tsx'], 'Candidate source differs from frozen input'
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == hashes[str(source_path.relative_to(root))], 'Production hook differs from frozen input'
env = os.environ.copy()
env['ORCA_BACKGROUND_LAUNCH'] = '1'
variants = [
    ('early-probe', 'const UNCONFIRMED_PROBE_BASE_DELAY_MS = 1_000',
     'const UNCONFIRMED_PROBE_BASE_DELAY_MS = 999', 'probes the same operation without'),
    ('missing-probe', 'if (probeId === null || probeSettled || !owner.attached)',
     'if (true)', 'probes the same operation without'),
    ('host-confirmed-replay', 'probeId === null || probeSettled || !owner.attached',
     'probeId === null || !owner.attached', 'parks a host-confirmed unknown'),
    ('forced-retry-replay', '    blocker.retryAfterUnknownSubmittedAt === null &&\n',
     '', 'never auto-probes an entry'),
    ('target-delay-not-reset', '}, [owner.attached, owner.ownerChange, owner.targetKey, probeId, probeSettled, sessionId])',
     '}, [owner.attached, owner.ownerChange, probeId, probeSettled, sessionId])', 'restarts probe delay'),
    ('stream-churn-restarts-delay', '}, [owner.attached, owner.ownerChange, owner.targetKey, probeId, probeSettled, sessionId])',
     '}, [owner.attached, owner.ownerChange, owner.targetKey, probeId, probeSettled, sessionId, submissions])',
     'still probes while streaming'),
    ('pending-replay', "outbox.find((entry) => entry.state === 'unconfirmed')",
     "outbox.find((entry) => entry.state === 'unconfirmed' || entry.state === 'dispatching')",
     'does not hot-loop when the host answers pending'),
    ('five-attempt-ceiling', 'if (probeId === null || probeSettled || !owner.attached)',
     'if (probeId === null || probeSettled || !owner.attached || probeAttemptsRef.current.attempts >= 5)',
     'keeps probing past the old five-attempt budget')
]
results = []
for name, before, after, selected in [('unaltered-control', '', '', ''), *variants]:
    if before:
        assert source.count(before) == 1, name
        mutant = source.replace(before, after)
    else:
        mutant = source
    mutant = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                    lambda match: 'from ' + json.dumps(str((directory / match[2]).resolve())), mutant)
    mutant = mutant.replace("from 'react'", 'from ' + json.dumps(str(root / 'node_modules/react/index.js')))
    fixture = control_root / (name + '.ts')
    fixture.write_text(mutant)
    config = control_root / (name + '.config.ts')
    config.write_text(f'''import {{ mergeConfig }} from {json.dumps(str(root / 'node_modules/vitest/dist/config.js'))}
import base from {json.dumps(str(root / 'config/vitest.config.ts'))}
export default mergeConfig(base, {{
  resolve: {{ alias: [{{
    find: './use-structured-agent-session-outbox-unconfirmed-probe',
    replacement: {json.dumps(str(fixture))}
  }}] }}
}})
''')
    output = control_root / (name + '.json')
    cmd = ['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(target.relative_to(root)),
           '--maxWorkers=1', '--reporter=default', '--reporter=json', '--outputFile=' + str(output)]
    if selected:
        cmd += ['-t', selected]
    result = subprocess.run(cmd, cwd=root, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, timeout=60)
    (control_root / (name + '.log')).write_text(result.stdout)
    should_pass = name == 'unaltered-control'
    if (result.returncode == 0) != should_pass:
        print(result.stdout)
        raise AssertionError('Unexpected control result: ' + name)
    data = json.loads(output.read_text())
    if should_pass:
        expected = json.loads((evidence / 'expected-cases.json').read_text())
        actual = sorted([case['fullName'], case['status']] for suite in data['testResults'] for case in suite['assertionResults'])
        assert actual == expected, 'Unaltered control cases differ from frozen baseline'
    if not should_pass:
        failures = [assertion for suite in data['testResults'] for assertion in suite['assertionResults']
                    if assertion['status'] == 'failed']
        assert len(failures) == 1, name
        assert selected in failures[0]['fullName'], name
        assert any('AssertionError' in message for message in failures[0]['failureMessages']), name
    row = {'control': name, 'passed': data['numPassedTests'], 'failed': data['numFailedTests'],
           'expected_pass': should_pass}
    results.append(row)
    print(json.dumps(row), flush=True)
(evidence / 'controls-summary.json').write_text(json.dumps(results, indent=2) + '\n')
