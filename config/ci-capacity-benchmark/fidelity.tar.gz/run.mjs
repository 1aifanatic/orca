import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createReadStream, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { createInterface } from 'node:readline'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const output = resolve(process.argv[2] || join(root, 'artifacts/terminal-parity-writes-benchmark'))
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const fixturePath = join(root, 'src/shared/terminal-restore-parity-fixture.ts')
const candidate = readFileSync(fixturePath, 'utf8')
const baseline = readFileSync(join(import.meta.dirname, 'baseline-fixture.ts'), 'utf8')
const files = ['src/main/daemon/headless-emulator-fidelity.fuzz.test.ts', 'src/renderer/src/components/terminal-pane/hidden-reveal-reconciliation.fuzz.test.ts', 'src/main/daemon/terminal-snapshot-color-parity.test.ts']
const controlsFile = 'src/shared/terminal-restore-parity-writes.test.ts'
const otherConsumers = ['src/renderer/src/components/terminal-pane/terminal-replay-application-continuity.test.ts', 'src/renderer/src/components/terminal-pane/terminal-snapshot-replay-paint.test.ts']
const env = { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }
for (const key of ['FUZZ_ITERATIONS', 'FUZZ_SEED', 'PARITY_WRITES_CAPTURE']) delete env[key]
mkdirSync(output, { recursive: true })
const digest = (data) => createHash('sha256').update(data).digest('hex')
const results = []
function install(arm) { writeFileSync(fixturePath, arm === 'baseline' ? baseline : candidate) }
function execute(args, extraEnv = {}) {
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, ...args], cwd: root, env: { ...env, ...extraEnv }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  return { ...result, wallMs: performance.now() - started }
}
function testRun(label, selected, extraEnv = {}, allowFailure = false, extraArgs = []) {
  const reportPath = join(output, `${label}.json`)
  const result = execute(['exec', 'vitest', 'run', '--config', 'config/vitest.config.ts', ...selected, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], extraEnv)
  if (!allowFailure) assert.equal(result.code, 0, describeProcessFailure(result))
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  return { label, wallMs: result.wallMs, bodyMs: report.testResults.flatMap((file) => file.assertionResults).reduce((total, test) => total + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, failures: report.numFailedTests, witnesses: report.testResults.flatMap((file) => file.assertionResults.filter((test) => test.status === 'failed').map((test) => test.fullName)) }
}
function instrument(source) {
  const createMarker = 'return { terminal, serializeAddon }'
  assert.equal(source.split(createMarker).length, 2)
  source = `import { appendFileSync as appendParityCapture } from 'node:fs'\nimport { expect as parityCaptureExpect } from 'vitest'\n${source}`
  source = source.replace('export type ParityTerminal = {', `const parityCaptureStates = new WeakMap<Terminal, { id: number; batch: number; serializeAddon: SerializeAddon }>()
let nextParityCaptureId = 0

export type ParityTerminal = {`)
  source = source.replace(createMarker, `parityCaptureStates.set(terminal, { id: nextParityCaptureId++, batch: 0, serializeAddon })
  ${createMarker}`)
  assert(source.includes('function writeChunksToTerminal('))
  source = source.replace('export async function writeChunksToTerminal(', 'async function writeChunksWithoutCapture(')
  source = source.replace('export function writeChunksToTerminal(', 'function writeChunksWithoutCapture(')
  source += `
export async function writeChunksToTerminal(terminal: Terminal, chunks: string[]): Promise<void> {
  const state = parityCaptureStates.get(terminal)
  if (!state) throw new Error('Capture expected a fixture-owned terminal')
  const batch = state.batch++
  await writeChunksWithoutCapture(terminal, chunks)
  const testState = parityCaptureExpect.getState()
  const record = {
    testPath: testState.testPath,
    testName: testState.currentTestName,
    terminalId: state.id,
    batch,
    chunks,
    snapshot: buildParityMainBufferSnapshot({ terminal, serializeAddon: state.serializeAddon }, 1),
    rows: visibleRows(terminal),
    styles: visibleRowStyles(terminal),
    wraps: visibleRowWraps(terminal),
    normalRows: normalBufferRowsTrimmed(terminal),
    normalStyles: normalBufferStylesTrimmed(terminal),
    cursor: cursorPosition(terminal),
    savedCursor: readSavedCursorRegister(terminal),
    modes: terminal.modes,
    activeBuffer: terminal.buffer.active.type
  }
  appendParityCapture(process.env.PARITY_WRITES_CAPTURE!, JSON.stringify(record) + String.fromCharCode(10))
}
`
  return source
}
async function captureSummary(capturePath) {
  const rawHash = createHash('sha256')
  let bytes = 0, batches = 0, chunks = 0, inputBytes = 0
  const terminals = new Set(), signatures = []
  const stream = createReadStream(capturePath)
  stream.on('data', (chunk) => { rawHash.update(chunk); bytes += chunk.length })
  const lines = createInterface({ input: stream, crlfDelay: Infinity })
  for await (const line of lines) {
    const record = JSON.parse(line)
    batches++
    chunks += record.chunks.length
    inputBytes += record.chunks.reduce((total, chunk) => total + Buffer.byteLength(chunk), 0)
    const identity = JSON.stringify([record.testPath, record.testName, record.terminalId])
    terminals.add(identity)
    signatures.push(JSON.stringify([identity, record.batch, digest(line)]))
  }
  // Concurrent independent terminals complete in different orders; each terminal's batch order is pinned.
  signatures.sort()
  return { canonicalSha256: digest(signatures.join(String.fromCharCode(10))), rawSha256: rawHash.digest('hex'), bytes, batches, chunks, inputBytes, terminals: terminals.size }
}
try {
  for (let pair = 1; pair <= 3; pair++) {
    for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
      install(arm)
      const sample = testRun(`${arm}-${pair}`, files)
      assert.equal(sample.passes, 16)
      assert.equal(sample.skips, 0)
      assert.equal(sample.failures, 0)
      results.push({ pair, arm, ...sample })
      console.log(JSON.stringify(results.at(-1)))
    }
  }
  const captures = {}
  for (const arm of ['baseline', 'candidate']) {
    install(arm)
    writeFileSync(fixturePath, instrument(readFileSync(fixturePath, 'utf8')))
    const capturePath = join(output, `${arm}-capture.jsonl`)
    writeFileSync(capturePath, '')
    const run = testRun(`${arm}-capture`, files, { PARITY_WRITES_CAPTURE: capturePath })
    assert.equal(run.passes, 16)
    assert.equal(run.failures, 0)
    captures[arm] = { ...run, ...await captureSummary(capturePath) }
    assert(captures[arm].batches >= 1000)
  }
  const keys = ['canonicalSha256', 'bytes', 'batches', 'chunks', 'inputBytes', 'terminals']
  assert.deepEqual(keys.map((key) => captures.baseline[key]), keys.map((key) => captures.candidate[key]))
  install('candidate')
  const controls = testRun('candidate-controls', [controlsFile, ...otherConsumers])
  assert.equal(controls.failures, 0)
  const negativeControls = []
  for (const [name, before, after] of [
    ['first-callback', 'index === chunks.length - 1 ? resolve : undefined', 'index === 0 ? resolve : undefined'],
    ['reversed-chunks', 'terminal.write(chunks[index]!', 'terminal.write(chunks[chunks.length - 1 - index]!'],
    ['lost-empty-boundary', 'terminal.write(chunks[index]!', "if (chunks[index] !== '') terminal.write(chunks[index]!"],
    ['early-resolution', 'index === chunks.length - 1 ? resolve : undefined)', 'undefined); resolve()']
  ]) {
    assert(candidate.includes(before))
    writeFileSync(fixturePath, candidate.replace(before, after))
    const run = testRun(`negative-${name}`, [controlsFile], {}, true, ['--testNamePattern', 'queues every original chunk'])
    assert(run.failures > 0, `fault survived: ${name}`)
    negativeControls.push({ name, failures: run.failures, witnesses: run.witnesses })
  }
  install('candidate')
  const summary = {
    environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion },
    hashes: { baseline: digest(baseline), candidate: digest(candidate) },
    samples: results,
    baseline: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs)),
    candidate: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs)),
    captures,
    controls,
    negativeControls
  }
  summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + String.fromCharCode(10))
  console.log(JSON.stringify(summary))
} finally { writeFileSync(fixturePath, candidate) }
