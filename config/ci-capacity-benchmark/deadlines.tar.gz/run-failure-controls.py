from pathlib import Path
import argparse, hashlib, json, os, subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd()
bundle = Path(__file__).resolve().parent
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/main/native-chat/agent-session-wire/structured-agent-session-claude-stop-ends-session.test.ts')
fixture = Path('src/main/native-chat/agent-session-wire/structured-agent-session-stop-deadline.test-fixture.ts')
candidate = (bundle / 'claude-candidate.source').read_text()
candidate_fixture = (bundle / 'stop-deadline-fixture-candidate.source').read_text()
old_fixture = (bundle / 'stop-deadline-fixture-before-cleanup.source').read_text()
restore = {relative: (root / relative).read_text() for relative in [test, fixture]}
if restore[test] != candidate or restore[fixture] != candidate_fixture:
    raise RuntimeError('Deadline candidates differ from frozen inputs')
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1'}
prefix = '''
let deadlineControlSignal: AbortSignal | undefined

function deadlineFailureControl(stopOperation: typeof stop) {
  return createStoppedClaudeDeadline({
    host: () => host,
    adapter: () => adapter,
    claude: () => claude,
    sessionId: SESSION,
    stop: stopOperation,
    laneDrained
  })
}

function expectDeadlineFailureCleanup(wait: typeof adapter.awaitStoppedRequestEnd, interrupt: typeof claude.routes.interrupt) {
  expect(vi.isFakeTimers()).toBe(false)
  expect(adapter.awaitStoppedRequestEnd).toBe(wait)
  expect(claude.routes.interrupt).toBe(interrupt)
}
'''
cases = {
    'reject': '''
it('deadline failure control propagates early rejection', async ({ signal }) => {
  deadlineControlSignal = signal
  const wait = adapter.awaitStoppedRequestEnd
  const interrupt = claude.routes.interrupt
  const refusal = new Error('deadline-control early rejection')
  await expect(deadlineFailureControl(async () => { throw refusal })(claude.connections[0]!, 'request-end')).rejects.toBe(refusal)
  expectDeadlineFailureCleanup(wait, interrupt)
}, 500)
''',
    'refusal': '''
it('deadline failure control returns early missing-prompt refusal unchanged', async ({ signal }) => {
  deadlineControlSignal = signal
  const wait = adapter.awaitStoppedRequestEnd
  const interrupt = claude.routes.interrupt
  let refusal: Awaited<ReturnType<typeof stop>> | undefined
  const controlled = deadlineFailureControl(async () => {
    const fields = { turnId: 'deadline-control-turn', prompt: { itemId: 'deadline-control-missing-prompt', expectedRevision: 1 } }
    const response = await host.cancel(CALLER, {
      envelope: envelope('agentSession.cancel', fields), ...fields
    })
    expect(response.ok).toBe(false)
    refusal = response
    return response
  })
  expect(await controlled(claude.connections[0]!, 'request-end')).toBe(refusal)
  expectDeadlineFailureCleanup(wait, interrupt)
}, 500)
''',
    'inactive': '''
it('deadline failure control returns inactive cancellation unchanged', async ({ signal }) => {
  deadlineControlSignal = signal
  await stop()
  await laneDrained()
  const wait = adapter.awaitStoppedRequestEnd
  const interrupt = claude.routes.interrupt
  let refused: Awaited<ReturnType<typeof stop>> | undefined
  const controlled = deadlineFailureControl(async () => {
    const response = await stop()
    expect(response).toMatchObject({ ok: true, value: { cancelled: false } })
    refused = response
    return response
  })
  expect(await controlled(claude.connections[0]!, 'request-end')).toBe(refused)
  expectDeadlineFailureCleanup(wait, interrupt)
}, 500)
''',
    'throw': '''
it('deadline failure control propagates synchronous failure', async ({ signal }) => {
  deadlineControlSignal = signal
  const wait = adapter.awaitStoppedRequestEnd
  const interrupt = claude.routes.interrupt
  const refusal = new Error('deadline-control synchronous failure')
  await expect(deadlineFailureControl(() => { throw refusal })(claude.connections[0]!, 'interrupt')).rejects.toBe(refusal)
  expectDeadlineFailureCleanup(wait, interrupt)
}, 500)
'''
}
rows = []

def run(label, source, helper, selected, passed, failed, timeout_ms=None):
    signal_capture = out / f'{label}-signal.json'
    signal_capture.unlink(missing_ok=True)
    if "import { writeFileSync } from 'node:fs'" not in source:
        source = "import { writeFileSync } from 'node:fs'\n" + source
    signal_hook = '  if (deadlineControlSignal) writeFileSync(' + json.dumps(signal_capture.as_posix()) + ', JSON.stringify({ aborted: deadlineControlSignal.aborted }))\n'
    source = source.replace('afterEach(async () => {\n', 'afterEach(async () => {\n' + signal_hook)
    (root / test).write_text(source)
    (root / fixture).write_text(helper)
    target = out / f'{label}.json'
    with (out / f'{label}.log').open('w') as log:
        proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                               str(test), '--maxWorkers=1', '--experimental.fsModuleCache=false',
                               '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                              cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
    report = json.loads(target.read_text())
    outcomes = [case for file in report['testResults'] for case in file['assertionResults']]
    failures = [case for case in outcomes if case['status'] == 'failed']
    if (proc.returncode == 0) != (failed == 0) or report['numPassedTests'] != passed or \
            report['numFailedTests'] != failed or report['numPendingTests'] != 22 or \
            report.get('unhandledErrors'):
        raise RuntimeError(f'{label} changed case outcomes; inspect {target}')
    signal_state = json.loads(signal_capture.read_text())
    if signal_state != {'aborted': timeout_ms is not None} or \
            timeout_ms is not None and any(case.get('duration', 0) < timeout_ms - 2 for case in failures):
        raise RuntimeError(f'{label} failed at an unexpected timeout oracle; inspect {target}')
    row = {'control': label, 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
           'fixtureSha256': hashlib.sha256(helper.encode()).hexdigest(), 'passed': passed,
           'failed': failed, 'pending': 22, 'signal': signal_state,
           'bodyMs': sum(case.get('duration', 0) for case in outcomes if case['status'] in ['passed', 'failed']),
           'caseNames': sorted(case['fullName'] for case in outcomes if case['status'] in ['passed', 'failed'])}
    rows.append(row)
    print(json.dumps(row), flush=True)

try:
    run('healthy-early-failures', candidate + prefix + ''.join(cases.values()), candidate_fixture,
        'deadline failure control', 4, 0)
    for key in ['reject', 'refusal', 'inactive']:
        run(f'old-helper-{key}-barrier-hang', candidate + prefix + cases[key], old_fixture,
            'deadline failure control', 0, 1, timeout_ms=500)
    timeout_case = '''
let deadlineCleanupAdapter: typeof adapter | undefined
let deadlineCleanupWait: typeof adapter.awaitStoppedRequestEnd | undefined

it('deadline failure control restores a timed out helper', async ({ signal }) => {
  deadlineControlSignal = signal
  deadlineCleanupAdapter = adapter
  deadlineCleanupWait = adapter.awaitStoppedRequestEnd
  await deadlineFailureControl(async () => await new Promise<Awaited<ReturnType<typeof stop>>>(() => {}))(claude.connections[0]!, 'request-end')
}, 300)
'''
    hook = 'afterEach(async () => {\n  vi.restoreAllMocks()\n  vi.useRealTimers()\n'
    if candidate.count(hook) != 1:
        raise RuntimeError('Claude cleanup hook changed')
    for label, keep_cleanup in [('test-timeout-cleanup', True), ('removed-cleanup-negative-control', False)]:
        capture = out / f'{label}-cleanup.json'
        capture.unlink(missing_ok=True)
        inspection = '''
  if (deadlineCleanupAdapter) {
    writeFileSync(CAPTURE, JSON.stringify({
      clockRestored: !vi.isFakeTimers(),
      spyRestored: deadlineCleanupAdapter.awaitStoppedRequestEnd === deadlineCleanupWait
    }))
    vi.restoreAllMocks()
    vi.useRealTimers()
  }
'''.replace('CAPTURE', json.dumps(capture.as_posix()))
        replacement = (hook if keep_cleanup else 'afterEach(async () => {\n') + inspection
        source = "import { writeFileSync } from 'node:fs'\n" + candidate.replace(hook, replacement) + prefix + timeout_case
        run(label, source, candidate_fixture, 'deadline failure control', 0, 1, timeout_ms=300)
        observed = json.loads(capture.read_text())
        if observed != {'clockRestored': keep_cleanup, 'spyRestored': keep_cleanup}:
            raise RuntimeError(f'{label} had unexpected cleanup state: {observed}')
        rows[-1]['cleanup'] = observed
finally:
    for relative, source in restore.items():
        (root / relative).write_text(source)
        if (root / relative).read_text() != source:
            raise RuntimeError(f'Failed to restore {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
