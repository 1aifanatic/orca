from pathlib import Path
import argparse, hashlib, json, os, re, subprocess
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
root = Path.cwd()
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
tests = {'codex': Path('src/main/runtime/structured-agent-session-codex-turn-end-settlement.test.ts'),
         'claude': Path('src/main/native-chat/agent-session-wire/structured-agent-session-claude-stop-ends-session.test.ts')}
candidate = {label: (bundle / f'{label}-candidate.source').read_text() for label in tests}
restore = {label: (root / relative).read_text() for label, relative in tests.items()}
production = {
    'codex': (Path('src/main/codex/codex-structured-turn-open-wait.ts'), 'codex-structured-turn-open-wait'),
    'claude': (Path('src/main/claude/claude-request-end-wait.ts'), 'claude-request-end-wait')
}
original = {label: (bundle / f'{label}-wait-production.source').read_text() for label in production}
close_test = 'lets a chat closed behind it close within its bound and one eviction'
grace_test = 'ends the child once the grace runs out when Claude says nothing after a Stop before the echo'
mutants = [
    ('codex-early-deadline', 'codex', 'const bound = setTimeout(endWait, withinMs)',
     'const bound = setTimeout(endWait, Math.max(0, withinMs - 1))', close_test, 'expected'),
    ('codex-late-deadline', 'codex', 'const bound = setTimeout(endWait, withinMs)',
     'const bound = setTimeout(endWait, withinMs + 1)', close_test, 'expected'),
    ('claude-early-deadline', 'claude', '    }, ms)',
     '    }, Math.max(0, ms - 1))', grace_test, 'expected true to be false'),
    ('claude-late-deadline', 'claude', '    }, ms)',
     '    }, ms + 1)', grace_test, 'expected false to be true')
]
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_SESSION_DEADLINE_MUTANT_IMPORTED': '0'}
rows = []

def run(label, family, source, selected, expected, config='config/vitest.config.ts'):
    (root / tests[family]).write_text(source)
    target = out / f'{label}.json'
    with (out / f'{label}.log').open('w') as log:
        proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config),
                               str(tests[family]), '--maxWorkers=1', '--experimental.fsModuleCache=false',
                               '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                              cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
    report = json.loads(target.read_text())
    cases = [case for file in report['testResults'] for case in file['assertionResults']]
    failed = [case for case in cases if case['status'] == 'failed']
    pending = 12 if family == 'codex' else 21
    if proc.returncode == 0 or report['numPassedTests'] != 0 or report['numFailedTests'] != 1 or \
            report['numPendingTests'] != pending or len(failed) != 1 or expected not in failed[0]['failureMessages'][0]:
        raise RuntimeError(f'{label} failed at an unexpected oracle; inspect {target}')
    row = {'mutation': label, 'testSha256': hashlib.sha256(source.encode()).hexdigest(),
           'bodyMs': failed[0]['duration'], 'failed': 1, 'pending': pending,
           'failure': failed[0]['failureMessages'][0].split('\n')[0]}
    rows.append(row)
    print(json.dumps(row), flush=True)

try:
    for label, family, pattern, replacement, selected, expected in mutants:
        relative, module = production[family]
        if (root / relative).read_text() != original[family] or original[family].count(pattern) != 1:
            raise RuntimeError(f'Changed production source or mutation site: {relative}')
        mutated = original[family].replace(pattern, replacement)
        mutated = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                         lambda match: 'from ' + json.dumps((root / relative.parent / match.group(2)).resolve().as_posix()), mutated)
        mutated += "\nprocess.env.ORCA_SESSION_DEADLINE_MUTANT_IMPORTED = '1'\n"
        module_file = out / f'{label}.ts'
        module_file.write_text(mutated)
        config = out / f'{label}.config.ts'
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*' + module +
                          '$/, replacement: ' + json.dumps(module_file.as_posix()) +
                          ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        source = candidate[family].replace('import { afterEach,', 'import { afterAll, afterEach,')
        source += "\nafterAll(() => expect(process.env.ORCA_SESSION_DEADLINE_MUTANT_IMPORTED).toBe('1'))\n"
        run(label, family, source, selected, expected, config)
        (root / tests[family]).write_text(restore[family])
    queue = candidate['codex'].replace('    clock.start()\n', '''    clock.start()
    let lateSend: Promise<string> | null = null
    setTimeout(() => { lateSend = send('unwanted late resend') }, 2_500)
''').replace('      await clock.observe(2_500)\n', '''      await clock.observe(2_500)
      if (lateSend) await lateSend
      await vi.waitFor(() => expect(steers + answers).toBe(3))
''')
    run('late-resend-at-observation-end', 'codex', queue,
        'comes back as a paused waiting card, and nothing sends it again', 'expected 3 to be 2')
    readiness = candidate['claude'].replace("it('" + grace_test + "', async () => {\n  const connection = claude.connections[0]!\n",
                                           "it('" + grace_test + "', async () => {\n  const connection = claude.connections[0]!\n  connection.send = async () => {}\n")
    if readiness == candidate['claude']:
        raise RuntimeError('Readiness mutation was not applied')
    run('child-never-observes-send', 'claude', readiness, grace_test, 'expected false to be true')
finally:
    for family, source in restore.items():
        (root / tests[family]).write_text(source)
        if (root / tests[family]).read_text() != source:
            raise RuntimeError(f'Failed to restore {tests[family]}')
    for family, (relative, _) in production.items():
        if (root / relative).read_text() != original[family]:
            raise RuntimeError(f'Production source changed during controls: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
