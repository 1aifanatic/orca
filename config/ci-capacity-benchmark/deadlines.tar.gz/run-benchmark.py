from pathlib import Path
import argparse, hashlib, json, os, subprocess, time
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent
root = Path.cwd()
inputs = [('codex', Path('src/main/runtime/structured-agent-session-codex-turn-end-settlement.test.ts')),
          ('claude', Path('src/main/native-chat/agent-session-wire/structured-agent-session-claude-stop-ends-session.test.ts'))]
fixture = Path('src/main/native-chat/agent-session-wire/structured-agent-session-stop-deadline.test-fixture.ts')
fixture_source = (bundle / 'stop-deadline-fixture-candidate.source').read_text()
if (root / fixture).read_text() != fixture_source:
    raise RuntimeError('Deadline fixture differs from frozen candidate')
sources = {mode: {label: (bundle / f'{label}-{mode}.source').read_text() for label, _ in inputs}
           for mode in ['original', 'candidate']}
restore = {relative: (root / relative).read_text() for _, relative in inputs}
args.out.mkdir(parents=True, exist_ok=True)
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1'}
rows = []
expected_names = None
try:
    for index, mode in enumerate(['original', 'candidate', 'candidate', 'original', 'original', 'candidate']):
        for label, relative in inputs:
            (root / relative).write_text(sources[mode][label])
        target = (args.out / f'{index}-{mode}.json').resolve()
        started = time.perf_counter()
        with (args.out / f'{index}-{mode}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
                                   *[str(relative) for _, relative in inputs], '--maxWorkers=1',
                                   '--experimental.fsModuleCache=false', '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        wall = time.perf_counter() - started
        report = json.loads(target.read_text())
        if proc.returncode != 0 or report['numPassedTests'] != 35 or report['numFailedTests'] or report['numPendingTests']:
            raise RuntimeError(f'{mode} failed its original35 cases; inspect {target}')
        cases = [case for file in report['testResults'] for case in file['assertionResults']]
        names = sorted(case['fullName'] for case in cases)
        if expected_names is None:
            expected_names = names
        if names != expected_names:
            raise RuntimeError('Original test titles changed between treatments')
        row = {'mode': mode, 'sourceSha256': {label: hashlib.sha256(source.encode()).hexdigest()
                                            for label, source in sources[mode].items()},
               'fixtureSha256': hashlib.sha256(fixture_source.encode()).hexdigest(),
               'processWallSeconds': wall, 'bodyMs': sum(case.get('duration', 0) for case in cases),
               'passed': report['numPassedTests'], 'caseNames': [case['fullName'] for case in cases]}
        rows.append(row)
        print(json.dumps(row), flush=True)
finally:
    for relative, source in restore.items():
        (root / relative).write_text(source)
        if (root / relative).read_text() != source:
            raise RuntimeError(f'Failed to restore {relative}')
(args.out / 'summary.json').write_text(json.dumps(rows, indent=2))
