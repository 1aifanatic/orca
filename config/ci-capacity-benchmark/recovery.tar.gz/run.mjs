import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const output = resolve(process.argv[2] || join(root, 'artifacts/profile-recovery-crash-benchmark'))
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const testFile = 'src/main/persistence/profile-state/profile-state-recovery-crash-boundaries.test.ts'
const testPath = join(root, testFile)
const candidate = readFileSync(testPath, 'utf8')
const baseline = readFileSync(join(import.meta.dirname, 'baseline.test.fixture.ts'), 'utf8')
mkdirSync(output, { recursive: true })
const digest = (data) => createHash('sha256').update(data).digest('hex')
const results = []
function execute(label, extraArgs = [], allowFailure = false) {
  const reportPath = join(output, `${label}.json`)
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, 'test', testFile, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], cwd: root, env: { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  const wallMs = performance.now() - started
  if (!allowFailure) assert.equal(result.code, 0, describeProcessFailure(result))
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  const tests = report.testResults.flatMap((file) => file.assertionResults)
  return { label, wallMs, bodyMs: tests.reduce((sum, test) => sum + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, failures: report.numFailedTests, originalCases: tests.filter((test) => !test.fullName.startsWith('seeded recovery fixture copies')).map((test) => ({ name: test.fullName, status: test.status })), witnesses: tests.filter((test) => test.status === 'failed').map((test) => test.fullName) }
}
try {
  let expectedOriginalCases
  for (let pair = 1; pair <= 3; pair++) {
    for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
      writeFileSync(testPath, arm === 'baseline' ? baseline : candidate)
      const run = execute(`${arm}-${pair}`)
      assert.equal(run.failures, 0)
      assert.equal(run.passes, (platform() === 'win32' ? 45 : 46) + (arm === 'candidate' ? 4 : 0))
      assert.equal(run.skips, platform() === 'win32' ? 1 : 0)
      if (!expectedOriginalCases) expectedOriginalCases = run.originalCases
      assert.deepEqual(run.originalCases, expectedOriginalCases)
      results.push({ pair, arm, ...run })
      console.log(JSON.stringify({ pair, arm, wallMs: run.wallMs, bodyMs: run.bodyMs, passes: run.passes, skips: run.skips }))
    }
  }
  const negativeControls = []
  const firstCase = 'accepted prior JSON=false.*marker-invalidated$'
  for (const [name, before, after, pattern] of [
    ['database-last-byte', 'for (const [suffix, bytes] of profile.originalFamily)', `const faultPath = join(directory, 'profile-state.db')
  const faultBytes = readFileSync(faultPath)
  faultBytes[faultBytes.length - 1] ^= 1
  writeFileSync(faultPath, faultBytes)
  for (const [suffix, bytes] of profile.originalFamily)`, firstCase],
    ['wal-last-byte', 'for (const [suffix, bytes] of profile.originalFamily)', `const faultPath = join(directory, 'profile-state.db-wal')
  const faultBytes = readFileSync(faultPath)
  faultBytes[faultBytes.length - 1] ^= 1
  writeFileSync(faultPath, faultBytes)
  for (const [suffix, bytes] of profile.originalFamily)`, firstCase],
    ['shared-database-path', 'databasePath: join(root, relative(seed.root, seed.databasePath))', 'databasePath: seed.databasePath', 'seeded recovery fixture copies'],
    ['missing-wal-copy', 'cpSync(seed.root, root, { recursive: true })', "cpSync(seed.root, root, { recursive: true, filter: (source) => !source.endsWith('-wal') })", firstCase],
    ['accepted-variant-collision', 'const key = `${kind}/${accepted}`', 'const key = `${kind}`', 'accepted prior JSON=false.*marker-invalidated$|accepted prior JSON=true.*json-publish:after$']
  ]) {
    assert(candidate.includes(before), `missing mutation marker: ${name}`)
    writeFileSync(testPath, candidate.replace(before, after))
    const run = execute(`negative-${name}`, ['--testNamePattern', pattern], true)
    assert(run.failures > 0, `fault survived: ${name}`)
    negativeControls.push({ name, failures: run.failures, witnesses: run.witnesses })
  }
  writeFileSync(testPath, candidate)
  const summary = {
    environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion },
    hashes: { baseline: digest(baseline), candidate: digest(candidate) },
    samples: results,
    baseline: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs)),
    candidate: summarizeBenchmarkSamples(results.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs)),
    negativeControls
  }
  summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + String.fromCharCode(10))
  console.log(JSON.stringify({ baseline: summary.baseline, candidate: summary.candidate, changePercent: summary.changePercent, negativeControls }))
} finally { writeFileSync(testPath, candidate) }
