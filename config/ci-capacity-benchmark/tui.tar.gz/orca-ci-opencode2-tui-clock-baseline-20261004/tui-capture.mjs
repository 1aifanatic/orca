import { appendFileSync } from 'node:fs'
import { expect } from "/Users/nwparker/orca/workspaces/orca/CI-Concurrency-2/node_modules/vitest/dist/index.js"
let ordinal = 0
let origin = 0
export function capture(kind, value) {
  if (kind === 'case-start') { ordinal += 1; origin = Date.now() }
  appendFileSync(process.env.ORCA_TUI_CAPTURE, JSON.stringify({ordinal, name: expect.getState().currentTestName, at: Date.now() - origin, kind, value}) + '\n')
}
