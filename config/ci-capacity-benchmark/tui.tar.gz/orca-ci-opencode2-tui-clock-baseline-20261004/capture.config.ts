import { mergeConfig } from "/Users/nwparker/orca/workspaces/orca/CI-Concurrency-2/node_modules/vitest/dist/config.js"
import base from "/Users/nwparker/orca/workspaces/orca/CI-Concurrency-2/config/vitest.config.ts"
export default mergeConfig(base, { plugins: [{
  name: 'opencode-tui-observation-capture', enforce: 'pre',
  resolveId(source, importer) {
    if (source === './opencode-tui-session-fixture' && importer?.endsWith('hook-plugin-opencode2-tui-ownership.test.ts')) return "/private/tmp/orca-ci-opencode2-tui-clock-baseline-20261004/opencode-tui-session-fixture.capture.ts"
  }
}] })
