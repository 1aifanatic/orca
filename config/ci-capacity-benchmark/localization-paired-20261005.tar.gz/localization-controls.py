import os,json,hashlib,subprocess,shutil,time
from pathlib import Path
root=Path.cwd();out=Path(os.environ.get('CI_LOCALIZATION_CONTROL_OUT','/tmp/orca-ci-localization-controls-20261005'));out.mkdir(exist_ok=True)
node=shutil.which('node');env=dict(os.environ,ORCA_BACKGROUND_LAUNCH='1',NODE_DISABLE_COMPILE_CACHE='1');env.pop('NODE_COMPILE_CACHE',None)
def sha(data):return hashlib.sha256(data).hexdigest()
paths=['config/scripts/audit-localization-coverage.mjs','config/scripts/audit-localization-coverage.test.mjs','config/scripts/localization-extraction-change-scope.mjs','config/scripts/localization-extraction-change-scope.test.mjs'];frozen={p:sha((root/p).read_bytes()) for p in paths}
audit=(root/paths[0]).read_text();tests=(root/paths[1]).read_text();module=root/'config/scripts/ci-localization-fault-audit.mjs';test=root/'config/scripts/ci-localization-fault-control.test.mjs';testtext=tests.replace("'./audit-localization-coverage.mjs'","'./ci-localization-fault-audit.mjs'");assert testtext!=tests
fixture=root/'src/renderer/src/ci-localization-extraction-control.test.tsx';promoted=root/'src/renderer/src/ci-localization-extraction-control.tsx';payload=b'declare const t: (key: string, options: { defaultValue: string }) => string;\nexport const control = t("ci.extraction.must_remain_checked", { defaultValue: "Localization gate control" });\n'
assert all(not p.exists() for p in [module,test,fixture,promoted])
ledger=[]
def run(name,args,expected):
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  start=time.perf_counter();r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se);elapsed=time.perf_counter()-start
 record={'name':name,'argv':args,'exitCode':r.returncode,'expectedExitCode':expected,'seconds':elapsed,'stdoutSha256':sha((out/(name+'.stdout')).read_bytes()),'stderrSha256':sha((out/(name+'.stderr')).read_bytes())};ledger.append(record);(out/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n');assert r.returncode==expected,(name,r.returncode)
 return record
try:
 test.write_text(testtext)
 mutants=[
 ('missing-template', '      ts.isTemplateExpression(node)\n','      false\n','sees static templates and every dynamic template part in visible calls'),
 ('missing-call-traversal','    ts.forEachChild(node, visit)','    if (!ts.isCallExpression(node)) ts.forEachChild(node, visit)','keeps traversing calls and callbacks to find nested JSX attributes and text'),
 ('missing-class-exclusion','if (hasAncestorObjectPropertyName(node, CLASS_PROPERTY_NAMES)) {','if (false) {','ignores nested class properties and translations while seeing sibling copy'),
 ('missing-translation-exclusion','if (!hasHumanLanguageText(value) || isInsideLocalizationCall(node)) {','if (!hasHumanLanguageText(value)) {','ignores nested class properties and translations while seeing sibling copy')]
 for name,before,after,target in mutants:
  assert audit.count(before)==1,(name,audit.count(before));mutant=audit.replace(before,after,1);module.write_text(mutant);(out/(name+'.source')).write_text(mutant);report=out/(name+'.json')
  record=run(name,[node,'node_modules/vitest/vitest.mjs','run','--config','config/vitest.config.ts','--no-cache','--no-file-parallelism','--maxWorkers','1','--reporter','json','--outputFile',str(report),str(test.relative_to(root))],1)
  raw=json.loads(report.read_text());cases=[case for suite in raw['testResults'] for case in suite['assertionResults']];assert len(cases)==int(os.environ['CI_LOCALIZATION_CONTROL_CASES']);assert any(case['title']==target and case['status']=='failed' for case in cases),(name,cases)
  record.update(mutantSourceSha256=sha(mutant.encode()),testSourceSha256=sha(testtext.encode()),intendedFailedTitle=target,cases=[{'title':c['title'],'status':c['status']} for c in cases])
 module.unlink();test.unlink()
 fixture.write_bytes(payload);changes=out/'ignored-changes.bin';changes.write_bytes((str(fixture.relative_to(root))+'\0').encode());run('ignored-selection',[node,paths[2],str(changes)],0);assert (out/'ignored-selection.stdout').read_text().strip()=='false'
 run('ignored-real-gate',[node,'config/scripts/verify-localization-extraction.mjs'],0)
 fixture.rename(promoted);changes=out/'promoted-changes.bin';changes.write_bytes((str(fixture.relative_to(root))+'\0'+str(promoted.relative_to(root))+'\0').encode());run('promoted-selection',[node,paths[2],str(changes)],0);assert (out/'promoted-selection.stdout').read_text().strip()=='true'
 run('promoted-real-gate',[node,'config/scripts/verify-localization-extraction.mjs'],1);assert 'ci.extraction.must_remain_checked' in (out/'promoted-real-gate.stderr').read_text()
 receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'candidateHashes':frozen,'faultsDetected':len(mutants),'actualIgnoredInputPassesRealGate':True,'promotedInputSelectedAndFailsRealGate':True,'allRawCasesRetained':True,'commands':ledger,'fixtureSha256':sha(payload)}
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'faultsDetected':len(mutants),'ignoredGateExit':0,'promotedGateExit':1}))
finally:
 for p in [module,test]:
  if p.exists():p.unlink()
 for p in [fixture,promoted]:
  if p.exists():assert p.read_bytes()==payload;p.unlink()
 for p,h in frozen.items():assert sha((root/p).read_bytes())==h,p
