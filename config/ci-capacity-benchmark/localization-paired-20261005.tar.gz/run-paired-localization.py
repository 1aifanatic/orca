import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--execute', action='store_true')
args = parser.parse_args()
assert args.execute, 'Explicit --execute is required'
root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
out = args.out.resolve()
assert root != out and root not in out.parents and root != bundle and root not in bundle.parents
out.mkdir(parents=True, exist_ok=True)
manifest_bytes = (bundle / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
write_json(out / 'driver-start.json', {
    'runId': os.environ['GITHUB_RUN_ID'], 'runAttempt': os.environ['GITHUB_RUN_ATTEMPT'],
    'manifestSha256': sha(manifest_bytes), 'driverSha256': sha(Path(__file__).read_bytes()),
    'bundle': str(bundle), 'root': str(root), 'startedUnixSeconds': time.time()
})
records = []
originals = {}
owned_temporary = {}
failure = None
restoration = {'attempted': False, 'success': False}
node = shutil.which('node')
assert node
env = dict(os.environ, ORCA_BACKGROUND_LAUNCH='1', NODE_DISABLE_COMPILE_CACHE='1')
env.pop('NODE_COMPILE_CACHE', None)
orders = [['original', 'candidate'], ['candidate', 'original'], ['original', 'candidate']]
paths = [
    'config/scripts/audit-localization-coverage.mjs',
    'config/scripts/audit-localization-coverage.test.mjs',
    'config/scripts/localization-extraction-change-scope.mjs',
    'config/scripts/localization-extraction-change-scope.test.mjs'
]


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, timeout=60)


def source_state():
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'status': git('status', '--porcelain', '--untracked-files=all').decode(),
        'changedPaths': sorted(git('diff', 'HEAD', '--name-only').decode().splitlines()),
        'stagedPaths': git('diff', '--cached', '--name-only').decode().splitlines()
    }


def terminate_owned(process):
    if os.name == 'nt':
        process.kill()
        process.wait(timeout=10)
        return
    for sig in [signal.SIGTERM, signal.SIGKILL]:
        try:
            os.killpg(process.pid, sig)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
    process.wait(timeout=10)


class Interrupted(Exception):
    pass


def on_signal(number, frame):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    raise Interrupted('Signal ' + str(number))


signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT, on_signal)


def run(name, command, expected=0, timeout=1200, extra_env=None):
    stdout = out / (name + '.stdout')
    stderr = out / (name + '.stderr')
    started = time.perf_counter()
    process = None
    interrupted = None
    timed_out = False
    with stdout.open('xb') as so, stderr.open('xb') as se:
        try:
            process = subprocess.Popen(command, cwd=root, env={**env, **(extra_env or {})},
                                       stdout=so, stderr=se, start_new_session=os.name != 'nt')
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                terminate_owned(process)
        except BaseException as error:
            interrupted = error
            if process is not None:
                terminate_owned(process)
    elapsed = time.perf_counter() - started
    record = {
        'name': name, 'argv': command, 'exitCode': process.returncode if process else None,
        'expectedExitCode': expected, 'seconds': elapsed, 'timedOut': timed_out,
        'interruption': repr(interrupted) if interrupted else None,
        'stdoutSha256': sha(stdout.read_bytes()), 'stderrSha256': sha(stderr.read_bytes()),
        'stdout': stdout.name, 'stderr': stderr.name
    }
    records.append(record)
    write_json(out / 'commands.json', records)
    if interrupted:
        raise interrupted
    assert not timed_out and record['exitCode'] == expected, (name, record)
    return record


def guard(arm):
    state = source_state()
    assert state['head'] == manifest['sourceSha']
    assert state['tree'] == manifest['sourceTreeGitOid']
    assert not state['stagedPaths']
    wanted = [] if arm == 'original' else sorted(
        row['file'] for row in manifest['subjects'] if row['originalSha256'] != row['candidateSha256']
    )
    assert state['changedPaths'] == wanted, state
    subject_rows = {row['file']: row for row in manifest['subjects']}
    for row in manifest['sourceGuards']:
        target = root / row['file']
        assert target.is_file() and not target.is_symlink(), row['file']
        expected = subject_rows[row['file']][arm + 'Sha256'] if row['file'] in subject_rows else row['sha256']
        assert sha(target.read_bytes()) == expected, row['file']
        assert bool(target.stat().st_mode & 0o111) == (row['gitMode'] == '100755'), row['file']
    for path, content in owned_temporary.items():
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == content, str(path)
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    expected_untracked = {str(path.relative_to(root)) for path in owned_temporary}
    assert {path for path in untracked if path} == expected_untracked, untracked
    return state


def install_temporary(name, content):
    target = root / 'config' / 'scripts' / name
    assert not target.exists()
    target.write_bytes(content)
    owned_temporary[target] = content
    return target


def case_report(report, expected_count, failed_title=None):
    raw = json.loads(report.read_text())
    cases = [{'suite': suite['name'], **case} for suite in raw['testResults']
             for case in suite['assertionResults']]
    assert len(cases) == expected_count, (report.name, len(cases), expected_count)
    assert all(case['status'] in ['passed', 'failed', 'pending', 'todo', 'skipped'] for case in cases)
    if failed_title is None:
        assert raw['success'] is True and all(case['status'] == 'passed' for case in cases), report.name
    else:
        assert raw['success'] is False
        assert any(case['title'] == failed_title and case['status'] == 'failed' for case in cases)
    return {'file': report.name, 'sha256': sha(report.read_bytes()), 'cases': cases}


try:
    assert manifest['schemaVersion'] == 1
    assert manifest['sourceSha'] == '761d63a4e52ff7915d4432c004df13182db63010'
    assert manifest['orders'] == orders
    assert manifest['expectedCases'] == 53 and manifest['expectedControlCases'] == 8
    assert manifest['criteria'] == {
        'allPairsPositive': True, 'medianPercentAtLeast': 5, 'medianSavingAboveOriginalRange': True
    }
    assert sorted(row['file'] for row in manifest['subjects']) == sorted(paths)
    assert len({row['file'] for row in manifest['sourceGuards']}) == len(manifest['sourceGuards'])
    assert set(paths) <= {row['file'] for row in manifest['sourceGuards']}
    assert set(manifest['bundleFiles']) == {path.name for path in bundle.iterdir()} - {'manifest.json'}
    for name, expected in manifest['bundleFiles'].items():
        assert Path(name).name == name and (bundle / name).is_file()
        assert sha((bundle / name).read_bytes()) == expected, name
    assert subprocess.check_output([node, '--version'], text=True).strip() == manifest['nodeVersion'] == 'v24.21.0'
    assert subprocess.check_output(['pnpm', '--version'], text=True).strip() == manifest['pnpmVersion'] == '12.8.1'
    assert manifest['sourceGuardCount'] == len(manifest['sourceGuards'])
    assert source_state()['status'] == '', 'Bootstrap source must be clean'
    guard('original')
    for row in manifest['subjects']:
        original = (root / row['file']).read_bytes()
        assert sha(original) == row['originalSha256']
        assert original == (bundle / row['originalName']).read_bytes()
        candidate = (bundle / row['candidateName']).read_bytes()
        assert sha(candidate) == row['candidateSha256']
        originals[row['file']] = original
    for row in manifest['subjects']:
        (root / row['file']).write_bytes((bundle / row['candidateName']).read_bytes())
    guard('candidate')
    original_audit = install_temporary('ci-localization-original-audit-20261005.mjs', originals[paths[0]])
    original_scope = install_temporary('ci-localization-original-scope-20261005.mjs', originals[paths[2]])
    guard('candidate')
    inventory_runs = {}
    for arm, script in [('original', original_audit), ('candidate', root / paths[0])]:
        inventory_runs[arm] = run('inventory-' + arm, [node, str(script), '--json', '--output', str(out / (arm + '-inventory.json'))])
    original_inventory = (out / 'original-inventory.json').read_bytes()
    candidate_inventory = (out / 'candidate-inventory.json').read_bytes()
    assert original_inventory == candidate_inventory
    write_json(out / 'inventory-comparison.json', {
        'byteEqual': True, 'originalSha256': sha(original_inventory), 'candidateSha256': sha(candidate_inventory),
        'inventoryCandidates': len(json.loads(candidate_inventory)), 'commands': inventory_runs
    })
    pairs = []
    for number, order in enumerate(orders, 1):
        pair = {'pair': number, 'order': order}
        for arm in order:
            guard('candidate')
            script = original_audit if arm == 'original' else root / paths[0]
            pair[arm] = run('audit-' + str(number) + '-' + arm, [node, str(script), '--check'])
        assert pair['original']['stdoutSha256'] == pair['candidate']['stdoutSha256']
        assert pair['original']['stderrSha256'] == pair['candidate']['stderrSha256']
        pair['savedSeconds'] = pair['original']['seconds'] - pair['candidate']['seconds']
        pair['savedPercent'] = 100 * pair['savedSeconds'] / pair['original']['seconds']
        pairs.append(pair)
        write_json(out / 'audit-pairs-progress.json', pairs)
    original_times = [pair['original']['seconds'] for pair in pairs]
    median_saving = statistics.median(pair['savedSeconds'] for pair in pairs)
    median_percent = statistics.median(pair['savedPercent'] for pair in pairs)
    original_range = max(original_times) - min(original_times)
    audit_result = {
        'pairs': pairs, 'medianPairedSavingSeconds': median_saving, 'medianPairedPercent': median_percent,
        'originalRangeSeconds': original_range,
        'performanceQualified': all(pair['savedSeconds'] > 0 for pair in pairs) and median_percent >= 5 and median_saving > original_range,
        'inventoryByteEqual': True, 'wholePrGainEstablished': False
    }
    write_json(out / 'audit-comparison.json', audit_result)
    changes = out / 'ignored-changes.bin'
    changes.write_bytes((manifest['ignoredChangePath'] + '\0').encode())
    scope_pairs = []
    for number, order in enumerate(orders, 1):
        pair = {'pair': number, 'order': order}
        for arm in order:
            guard('candidate')
            script = original_scope if arm == 'original' else root / paths[2]
            started = time.perf_counter()
            decision = run('scope-' + str(number) + '-' + arm, [node, str(script), str(changes)])
            selected = (out / decision['stdout']).read_text().strip()
            assert selected == ('true' if arm == 'original' else 'false')
            gate = run('extraction-' + str(number) + '-' + arm, [node, 'config/scripts/verify-localization-extraction.mjs']) if selected == 'true' else None
            pair[arm] = {
                'seconds': time.perf_counter() - started, 'selection': selected,
                'classification': decision, 'extraction': gate,
                'extractionStatus': 'success' if gate else 'not_selected'
            }
        pair['savedSeconds'] = pair['original']['seconds'] - pair['candidate']['seconds']
        scope_pairs.append(pair)
        write_json(out / 'scope-pairs-progress.json', scope_pairs)
    write_json(out / 'scope-comparison.json', {
        'pairs': scope_pairs,
        'medianPairedConditionalSavingSeconds': statistics.median(pair['savedSeconds'] for pair in scope_pairs),
        'allPairsPositive': all(pair['savedSeconds'] > 0 for pair in scope_pairs),
        'wholePrGainEstablished': False, 'candidateExclusionsAreNotTestPasses': True
    })
    guard('candidate')
    report = out / 'candidate-cases.json'
    run('candidate-cases', [node, 'node_modules/vitest/vitest.mjs', 'run', '--config', 'config/vitest.config.ts',
                            '--no-cache', '--pool=forks', '--maxWorkers=4', '--reporter=json',
                            '--outputFile=' + str(report), paths[1], paths[3]])
    write_json(out / 'candidate-case-inventory.json', case_report(report, manifest['expectedCases']))
    guard('candidate')
    controls_out = out / 'controls'
    run('real-controls', ['python3', str(bundle / 'localization-controls.py')], extra_env={
        'CI_LOCALIZATION_CONTROL_OUT': str(controls_out),
        'CI_LOCALIZATION_CONTROL_CASES': str(manifest['expectedControlCases'])
    })
    controls = json.loads((controls_out / 'receipt.json').read_text())
    assert controls['faultsDetected'] == 4 and controls['promotedInputSelectedAndFailsRealGate'] is True
    for command in controls['commands']:
        assert command['exitCode'] == command['expectedExitCode']
    guard('candidate')
    write_json(out / 'qualification.json', {
        'runId': os.environ['GITHUB_RUN_ID'], 'runAttempt': os.environ['GITHUB_RUN_ATTEMPT'],
        'sourceSha': manifest['sourceSha'], 'sourceTreeGitOid': manifest['sourceTreeGitOid'],
        'manifestSha256': sha(manifest_bytes), 'candidateCases': manifest['expectedCases'],
        'allCandidateCasesPassed': True, 'inventoryByteEqual': True, 'realMutantFaultsDetected': 4,
        'ignoredTestPromotionFaultDetected': True, 'auditPerformanceQualified': audit_result['performanceQualified'],
        'wholePrGainEstablished': False, 'performanceFailureDoesNotFalsifyCorrectness': True
    })
except BaseException as error:
    failure = repr(error)
    write_json(out / 'failure.json', {'error': failure, 'sourceState': source_state()})
finally:
    restoration['attempted'] = True
    try:
        cleanup_errors = []
        for target, content in owned_temporary.items():
            if target.exists():
                if target.is_symlink() or target.read_bytes() != content:
                    cleanup_errors.append('Unexpected temporary bytes: ' + str(target))
                else:
                    target.unlink()
        owned_temporary.clear()
        for path, content in originals.items():
            (root / path).write_bytes(content)
        assert not cleanup_errors, cleanup_errors
        if len(originals) == len(paths):
            guard('original')
            assert source_state()['status'] == ''
            restoration['success'] = True
        else:
            restoration['note'] = 'Pre-overlay failure; checkout source was not changed'
            restoration['success'] = source_state()['status'] == ''
        restoration['sourceState'] = source_state()
    except BaseException as error:
        restoration['error'] = repr(error)
        failure = failure or repr(error)
    write_json(out / 'source-restoration.json', restoration)
    write_json(out / 'driver-terminal.json', {
        'runId': os.environ['GITHUB_RUN_ID'], 'runAttempt': os.environ['GITHUB_RUN_ATTEMPT'],
        'failure': failure, 'sourceRestoration': restoration, 'commandCount': len(records)
    })
if failure or not restoration['success']:
    raise SystemExit(1)
