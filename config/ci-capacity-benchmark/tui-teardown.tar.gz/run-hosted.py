import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from teardown_runtime import run_process, write_config, resolved_source

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--local-validation', action='store_true')
parser.add_argument('--validate-only', action='store_true')
args = parser.parse_args()
root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
manifest = json.loads((bundle / 'manifest.json').read_text())
for name, expected in manifest['inputHashes'].items():
    assert hashlib.sha256((bundle / name).read_bytes()).hexdigest() == expected, name
source_sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
assert source_sha == manifest['sourceSha'] and tree == manifest['sourceTree']
assert subprocess.run(['git', 'diff', '--quiet', 'HEAD'], cwd=root).returncode == 0
production = json.loads((bundle / 'production-source-hashes.json').read_text())
for path, expected in production.items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
primary = root / manifest['tuiFile']
primary_bytes = primary.read_bytes()
assert hashlib.sha256(primary_bytes).hexdigest() == manifest['baselineSha256']
node = json.loads(subprocess.check_output(['node', '-p', 'JSON.stringify({version:process.version,platform:process.platform,arch:process.arch})'], cwd=root, text=True))
pnpm = subprocess.check_output(['pnpm', '--version'], cwd=root, text=True).strip()
assert pnpm == manifest['pnpmVersion']
if not args.local_validation:
    assert node == {'version': 'v24.21.0', 'platform': 'linux', 'arch': 'arm64'}, node
provenance = {'sourceSha': source_sha, 'sourceTree': tree, 'node': node, 'pnpmVersion': pnpm,
              'runId': os.environ.get('GITHUB_RUN_ID'), 'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
              'oneWorker': True, 'backgroundLaunch': '1',
              'manifestSha256': hashlib.sha256((bundle / 'manifest.json').read_bytes()).hexdigest(),
              'localValidation': args.local_validation}
if not args.local_validation:
    assert provenance['runId'] and provenance['runAttempt']
(out / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
if args.validate_only:
    print(json.dumps({'validated': True, **provenance}))
    sys.exit(0)

def environment(cache):
    assert not cache.exists(), cache
    cache.mkdir()
    env = os.environ.copy()
    env['ORCA_BACKGROUND_LAUNCH'] = '1'
    env['NODE_DISABLE_COMPILE_CACHE'] = '1'
    env['ORCA_TEARDOWN_CACHE_DIR'] = str(cache)
    env.pop('ORCA_BALANCE_UNIT_SHARDS', None)
    return env


def cases(report):
    return sorted([{'fullName': case['fullName'], 'status': case['status']}
                   for item in report['testResults'] for case in item['assertionResults']],
                  key=lambda case: (case['fullName'], case['status']))


def require_success(result, raw, ledger, count):
    assert result.returncode == 0, result.stdout
    report = json.loads(raw.read_text())
    assert report['success'] and report['numTotalTests'] == count and report['numPassedTests'] == count
    assert report['numFailedTests'] == 0 and report['numPendingTests'] == 0 and report['numTodoTests'] == 0
    assert len(report['testResults']) == 1 and report['testResults'][0]['status'] == 'passed'
    assert not any(marker in result.stdout for marker in ['Unhandled Errors', 'Unhandled Rejection', 'Uncaught Exception'])
    actual = cases(report)
    assert actual == ledger, (actual, ledger)
    return report, actual


def healthy_pair():
    write_config(root, bundle)
    ledger = json.loads((bundle / 'tui-case-ledger.json').read_text())
    records = []
    for arm in ['baseline', 'candidate']:
        healthy = bundle / 'healthy.test.ts'
        healthy.write_text(resolved_source(root, (bundle / (arm + '.source')).read_text()))
        raw = out / (arm + '-healthy.json')
        env = environment(out / (arm + '-empty-cache'))
        started = time.perf_counter()
        result = run_process(['pnpm', 'exec', 'vitest', 'run', '--config', str(bundle / 'vitest.config.ts'),
                              healthy.name, '--outputFile=' + str(raw)], cwd=root, env=env, timeout=60)
        wall = time.perf_counter() - started
        (out / (arm + '-healthy.log')).write_text(result.stdout)
        report, actual = require_success(result, raw, ledger, 41)
        case_path = out / (arm + '-healthy-case-ledger.json')
        case_path.write_text(json.dumps(actual, indent=2) + '\n')
        records.append({'arm': arm, 'wallSeconds': wall, 'exitCode': result.returncode,
                        'moduleElapsedMs': report['testResults'][0]['endTime'] - report['testResults'][0]['startTime'],
                        'passedCases': 41, 'sourceSha256': manifest[arm + 'Sha256'],
                        'caseLedgerSha256': hashlib.sha256(case_path.read_bytes()).hexdigest(),
                        'rawReportSha256': hashlib.sha256(raw.read_bytes()).hexdigest()})
    (out / 'healthy-pair.json').write_text(json.dumps({'purpose': 'Ordinary-path regression check; one pair is not a speed claim',
                                                     'provenance': provenance, 'records': records}, indent=2) + '\n')
    return records


def controls():
    env = os.environ.copy()
    env['ORCA_BACKGROUND_LAUNCH'] = '1'
    result = run_process([sys.executable, str(bundle / 'run-controls.py'), '--source-sha', source_sha],
                         cwd=root, env=env, timeout=120)
    (out / 'controls-driver.log').write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    rows = json.loads((bundle / 'controls-summary.json').read_text())
    assert len(rows) == 12
    expected = manifest['controls']
    assert [[row['control'], row['arm'], row['status']] for row in rows] == expected
    assert all(all(row['restoration'].values()) for row in rows)
    return {'invocations': len(rows), 'restoredEveryPath': True}


def parity_qualification():
    for path, expected in manifest['paritySources'].items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
    cache = out / 'parity-empty-cache'
    env = environment(cache)
    config = bundle / 'parity.config.ts'
    config.write_text('import { defineConfig } from ' + json.dumps(str(root / 'node_modules/vitest/dist/config.js')) + '\n'
                      + 'import original from ' + json.dumps(str(root / 'config/vitest.config.ts')) + '\n'
                      + 'export default defineConfig({ ...original, root: ' + json.dumps(str(root))
                      + ', cacheDir: process.env.ORCA_TEARDOWN_CACHE_DIR, test: { ...original.test, maxWorkers: 1, '
                      + 'experimental: { ...original.test?.experimental, fsModuleCache: false }, reporters: ["default", "json"] } })\n')
    raw = out / 'parity-qualification.json'
    result = run_process(['pnpm', 'exec', 'vitest', 'run', '--config', str(config),
                          manifest['parityFile'], '--outputFile=' + str(raw)], cwd=root, env=env, timeout=60)
    (out / 'parity-qualification.log').write_text(result.stdout)
    ledger = json.loads((bundle / 'parity-case-ledger.json').read_text())
    _, actual = require_success(result, raw, ledger, 8)
    receipt_ledger = out / 'parity-qualification-case-ledger.json'
    receipt_ledger.write_text(json.dumps(actual, indent=2) + '\n')
    receipt = {'purpose': 'Separate untimed final-source parity qualification; no modification of source-pair artifacts',
               'provenance': provenance, 'file': manifest['parityFile'], 'exitCode': result.returncode,
               'passedCases': 8, 'sourceHashes': manifest['paritySources'],
               'rawReportSha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
               'defaultLogSha256': hashlib.sha256((out / 'parity-qualification.log').read_bytes()).hexdigest(),
               'caseLedgerSha256': hashlib.sha256(receipt_ledger.read_bytes()).hexdigest()}
    (out / 'parity-qualification-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return {'passedCases': 8, 'receipt': 'parity-qualification-receipt.json'}

results = {}
errors = {}
try:
    # The independent parity qualification still runs if a TUI phase fails.
    for name, phase in [('healthyPair', healthy_pair), ('cleanupControls', controls), ('parityQualification', parity_qualification)]:
        try:
            results[name] = phase()
        except Exception as error:
            errors[name] = str(error)
finally:
    assert primary.read_bytes() == primary_bytes, 'Primary TUI test was modified'
    for path, expected in production.items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
    assert subprocess.run(['git', 'diff', '--quiet', 'HEAD'], cwd=root).returncode == 0
    for path in bundle.iterdir():
        if path.is_file() and (path.name in ['manifest.json', 'source-hashes.json', 'baseline.source', 'candidate.source', 'teardown.patch',
                                           'production-source-hashes.json', 'tui-case-ledger.json', 'parity-case-ledger.json']
                              or path.name == 'controls-summary.json'
                              or path.name.startswith(('baseline-', 'candidate-')) and path.suffix in ['.json', '.log']):
            shutil.copyfile(path, out / path.name)
    summary = {'qualified': not errors, 'provenance': provenance, 'results': results, 'errors': errors}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
assert not errors, errors
