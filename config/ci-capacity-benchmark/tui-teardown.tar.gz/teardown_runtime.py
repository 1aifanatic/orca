import json
import os
from pathlib import Path
import signal
from types import SimpleNamespace
import subprocess


def run_process(command, *, cwd, env, timeout):
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True,
                               start_new_session=os.name == 'posix')
    try:
        output, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == 'posix':
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        else:
            process.terminate()
        try:
            process.wait(timeout=0.3)
        except subprocess.TimeoutExpired:
            pass
        finally:
            if os.name == 'posix':
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
        output, _ = process.communicate(timeout=5)
        raise RuntimeError('Bounded test process timed out: ' + output)
    return SimpleNamespace(returncode=process.returncode, stdout=output)


def write_config(root, bundle):
    config = '''import { defineConfig } from %s
import original from %s
export default defineConfig({
  ...original,
  root: %s,
  cacheDir: process.env.ORCA_TEARDOWN_CACHE_DIR,
  resolve: {
    ...original.resolve,
    alias: {
      ...original.resolve?.alias,
      vitest: %s,
      electron: %s
    }
  },
  test: {
    ...original.test,
    include: ['*.test.ts'], exclude: [], maxWorkers: 1, sequence: {},
    experimental: { ...original.test?.experimental, fsModuleCache: false },
    reporters: ['default', 'json']
  }
})
''' % (json.dumps(str(root / 'node_modules/vitest/dist/config.js')),
       json.dumps(str(root / 'config/vitest.config.ts')), json.dumps(str(bundle)),
       json.dumps(str(root / 'node_modules/vitest/dist/index.js')),
       json.dumps(str(root / 'node_modules/electron/index.js')))
    (bundle / 'vitest.config.ts').write_text(config)


def resolved_source(root, source):
    for relative, target in [
        ('./hook-service', 'src/main/opencode/hook-service.ts'),
        ('./opencode-tui-session-fixture', 'src/main/opencode/opencode-tui-session-fixture.ts'),
        ('../../shared/promise-timeout-fallback', 'src/shared/promise-timeout-fallback.ts')
    ]:
        source = source.replace('from ' + repr(relative), 'from ' + repr(str(root / target)))
    return source
