import argparse
import hashlib
import json
import os
import re
import shutil
from pathlib import Path
import subprocess
import time
from teardown_runtime import run_process, write_config, resolved_source

root = Path.cwd().resolve()
bundle = Path(__file__).resolve().parent
source_path = root / 'src/main/opencode/hook-plugin-opencode2-tui-ownership.test.ts'
source_bytes = source_path.read_bytes()
parser = argparse.ArgumentParser()
parser.add_argument('--source-sha', default='5cce5f56775d3d66eb3abe2fbc80900c4eff5c05')
args = parser.parse_args()
source_sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert source_sha == args.source_sha
hashes = json.loads((bundle / 'source-hashes.json').read_text())
assert hashlib.sha256(source_bytes).hexdigest() in hashes.values()
for arm, expected in hashes.items():
    assert hashlib.sha256((bundle / (arm + '.source')).read_bytes()).hexdigest() == expected
production_hashes = json.loads((bundle / 'production-source-hashes.json').read_text())
for path, expected in production_hashes.items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
write_config(root, bundle)

restoration = '''
const controlFetch = globalThis.fetch
const controlArgv = process.argv
const controlEnv = Object.fromEntries(ENV_KEYS.map((key) => [key, process.env[key]]))
afterAll(() => {
  const restored = {
    realTimers: !vi.isFakeTimers(),
    fetch: globalThis.fetch === controlFetch,
    argv: process.argv === controlArgv,
    environment: ENV_KEYS.every((key) => process.env[key] === controlEnv[key])
  }
  console.log('TUI_FAILURE_RESTORATION=' + JSON.stringify(restored))
  expect(Object.values(restored).every(Boolean)).toBe(true)
})
'''
normal_body = '''
    process.env.ORCA_PANE_KEY = PANE_A
    const tui = fakeTui()
    await (await loadPlugin()).default?.setup?.(tui.ctx)
    tui.navigate(SES_A)
    await pump(tui, turn(SES_A, 'A').start)
    expect(summary(posts)).toContain(`SessionBusy:${SES_A}`)
'''
retry_body = '''
    process.env.ORCA_PANE_KEY = PANE_A
    failPosts = true
    const tui = fakeTui()
    await (await loadPlugin()).default?.setup?.(tui.ctx)
    tui.navigate(SES_A)
    await pump(tui, turn(SES_A, 'A').start)
    expect(vi.getTimerCount()).toBeGreaterThan(1)
'''
delay_body = '''
    process.env.ORCA_PANE_KEY = PANE_A
    postDelayMs = 10000
    const tui = fakeTui()
    await (await loadPlugin()).default?.setup?.(tui.ctx)
    await tick(0)
    expect(delayedPosts.size).toBe(1)
    expect(vi.getTimerCount()).toBeGreaterThan(1)
'''
cleanup_start = 'return async () => {\n      try {\n        disposed = true;'
release = 'await releaseTuiStatusDelivery(factoryID, () => setMemory((draft) => { draft.last = ""; }));'
rows = []

def run(label, arm, body, before=None, after=None, expected_pass=False, expected_timers=None, minimum_wall=None):
    source = (bundle / (arm + '.source')).read_text().replace('import { afterEach,', 'import { afterAll, afterEach,')
    source = resolved_source(root, source)
    # Instrument only the afterEach assertion; explicit close wrappers are untouched.
    if arm == 'candidate':
        before_check = '\n          expect(vi.getTimerCount()).toBe(0)'
        assert source.count(before_check) == 1
        source = source.replace(before_check, "\n          console.log('TUI_TEARDOWN_TIMER_CHECK=' + vi.getTimerCount())" + before_check)
        source = source.replace('const { setTimeout: realSetTimeout, clearTimeout: realClearTimeout } = globalThis', 'const { setTimeout: realSetTimeout, clearTimeout: realClearTimeout } = globalThis\nconst controlRealNow = Date.now')
        source = source.replace('    let deadline: ReturnType<typeof setTimeout> | undefined', '    const controlCleanupStarted = controlRealNow()\n    let deadline: ReturnType<typeof setTimeout> | undefined')
        source = source.replace('deadline = realSetTimeout(() => resolve(false), 2000)', '''deadline = realSetTimeout(() => {
              console.log('TUI_NATIVE_DEADLINE=' + JSON.stringify({ elapsedMs: controlRealNow() - controlCleanupStarted, fakeTimers: vi.isFakeTimers() }))
              resolve(false)
            }, 2000)''')
    needle = 'writeFileSync(pluginPath, _internals.getOpenCodePluginSource())'
    assert source.count(needle) == 1
    if before is not None:
        replacement = 'writeFileSync(pluginPath, (() => { const source = _internals.getOpenCodePluginSource(); const before = ' + json.dumps(before) + '; if (source.split(before).length !== 2) throw new Error("Mutation must match one generated-source location"); return source.replace(before, ' + json.dumps(after) + '); })())'
        source = source.replace(needle, replacement)
    elif after is not None:
        source = source.replace(needle, 'writeFileSync(pluginPath, ' + json.dumps(after) + ' + _internals.getOpenCodePluginSource())')
    selected = 'TUI teardown control ' + label
    index = source.rfind('\n})')
    assert index > 0
    source = source[:index] + '\n  it(' + json.dumps(selected) + ', async () => {\n' + body + '  })\n' + source[index:] + restoration
    test_path = bundle / 'control.test.ts'
    test_path.write_text(source)
    output_path = bundle / (arm + '-' + label + '.json')
    env = os.environ.copy()
    env['ORCA_BACKGROUND_LAUNCH'] = '1'
    env.pop('ORCA_BALANCE_UNIT_SHARDS', None)
    env['NODE_DISABLE_COMPILE_CACHE'] = '1'
    cache = bundle / ('control-cache-' + arm + '-' + label)
    shutil.rmtree(cache, ignore_errors=True)
    cache.mkdir()
    env['ORCA_TEARDOWN_CACHE_DIR'] = str(cache)
    started = time.perf_counter()
    result = run_process(['pnpm', 'exec', 'vitest', 'run', '--config', str(bundle / 'vitest.config.ts'),
                             test_path.name, '--outputFile=' + str(output_path), '-t', selected],
                            cwd=root, env=env, timeout=15)
    elapsed = time.perf_counter() - started
    (bundle / (arm + '-' + label + '.log')).write_text(result.stdout)
    assert output_path.exists(), result.stdout
    report = json.loads(output_path.read_text())
    assertions = [case for module in report['testResults'] for case in module['assertionResults']]
    selected_results = [case for case in assertions if selected in case['fullName']]
    assert len(selected_results) == 1, result.stdout
    actual = selected_results[0]
    assert (result.returncode == 0) == expected_pass and actual['status'] == ('passed' if expected_pass else 'failed'), result.stdout
    marker = 'TUI_FAILURE_RESTORATION='
    assert marker in result.stdout, result.stdout
    restored = json.loads(result.stdout.split(marker)[1].splitlines()[0])
    assert all(restored.values()), result.stdout
    timer_checks = [int(value) for value in re.findall(r'TUI_TEARDOWN_TIMER_CHECK=(\d+)\b', result.stdout)]
    if expected_timers is not None:
        assert timer_checks == (expected_timers if isinstance(expected_timers, list) else [expected_timers]), result.stdout
    assert elapsed < 7, (label, elapsed)
    native_deadlines = [json.loads(value) for value in re.findall(r'TUI_NATIVE_DEADLINE=(\{[^\n]+\})', result.stdout)]
    if minimum_wall is not None:
        assert elapsed > minimum_wall, (label, elapsed)
        assert len(native_deadlines) == 1 and 1900 <= native_deadlines[0]['elapsedMs'] < 5000 and native_deadlines[0]['fakeTimers'], result.stdout
    else:
        assert not native_deadlines, result.stdout
    row = {'control': label, 'arm': arm, 'status': actual['status'], 'exitCode': result.returncode,
           'wallSeconds': elapsed, 'afterEachTimerChecks': timer_checks, 'nativeDeadlines': native_deadlines, 'restoration': restored,
           'failureMessages': actual.get('failureMessages', [])}
    rows.append(row)
    (bundle / 'controls-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps({key: value for key, value in row.items() if key != 'failureMessages'}), flush=True)

try:
    run('import-refusal', 'candidate', normal_body, after='throw new Error("TUI_IMPORT_REFUSAL");\n', expected_timers=[])
    run('setup-refusal', 'candidate', normal_body, 'async function setupOpenCode2Tui(ctx) {', 'async function setupOpenCode2Tui(ctx) { throw new Error("TUI_SETUP_REFUSAL");', expected_timers=0)
    run('valid-afterEach-close', 'candidate', normal_body, expected_pass=True, expected_timers=0)
    run('valid-post-delay-release', 'candidate', delay_body, expected_pass=True, expected_timers=0)
    for label, body, before, after in [
        ('interval-leak', normal_body, 'clearInterval(tick);', 'void tick;'),
        ('retry-leak', retry_body, 'if (statusRetryTimer) clearTimeout(statusRetryTimer);', 'void statusRetryTimer;')
    ]:
        run(label, 'baseline', body, before, after, expected_pass=True)
        run(label, 'candidate', body, before, after, expected_timers=1)
    run('body-refusal-interval-leak', 'candidate', normal_body + '    throw new Error("TUI_BODY_REFUSAL")\n',
        'clearInterval(tick);', 'void tick;', expected_timers=1)
    run('cleanup-rejection-leak', 'candidate', normal_body, cleanup_start,
        'return async () => { throw new Error("TUI_CLEANUP_REJECTION");\n      try {\n        disposed = true;', expected_timers=1)
    run('cleanup-timeout-leak', 'candidate', normal_body, cleanup_start,
        'return async () => { await new Promise(() => {});\n      try {\n        disposed = true;', expected_timers=1, minimum_wall=2)
    run('cleanup-timeout-no-leak', 'candidate', normal_body, release,
        'await new Promise(() => {});', expected_timers=0, minimum_wall=2)
finally:
    assert source_path.read_bytes() == source_bytes, 'Primary test was modified'
    for path, expected in production_hashes.items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
