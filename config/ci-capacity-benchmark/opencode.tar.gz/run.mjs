import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { cpus, platform, release } from 'node:os'
import { join, resolve } from 'node:path'
import { performance } from 'node:perf_hooks'
import { pathToFileURL } from 'node:url'

const root = resolve(process.cwd())
const bundle = import.meta.dirname
const output = resolve(process.argv[2] || join(root, 'artifacts/opencode-subscribe-benchmark'))
const controlsOnly = process.argv.includes('--controls-only')
const captureOnly = process.argv.includes('--capture-only')
const timingOnly = process.argv.includes('--timing-only')
const file = 'src/main/native-chat/transcript-opencode-subscribe.test.ts'
const sourcePath = join(root, file)
const candidate = readFileSync(sourcePath, 'utf8')
const baseline = readFileSync(join(bundle, 'baseline.test.fixture.ts'), 'utf8')
const { resolvePnpmCliInvocation } = await import(pathToFileURL(join(root, 'config/scripts/pnpm-cli-invocation.mjs')).href)
const { runProcessSync, describeProcessFailure } = await import(pathToFileURL(join(root, 'config/scripts/script-child-process.mjs')).href)
const { summarizeBenchmarkSamples } = await import(pathToFileURL(join(root, 'config/scripts/benchmark-sample-summary.mjs')).href)
const pnpm = resolvePnpmCliInvocation()
const digest = (data) => createHash('sha256').update(data).digest('hex')
mkdirSync(output, { recursive: true })
function replaceRequired(source, marker, replacement) {
  assert(source.includes(marker), `missing source marker: ${marker}`)
  return source.replace(marker, replacement)
}
function execute(label, extraArgs = [], allowFailure = false) {
  const reportPath = join(output, `${label}.json`)
  const started = performance.now()
  const result = runProcessSync({ program: pnpm.command, args: [...pnpm.prefixArgs, 'test', file, '--maxWorkers=1', '--reporter=json', '--outputFile', reportPath, ...extraArgs], cwd: root, env: { ...process.env, ORCA_BACKGROUND_LAUNCH: '1' }, timeoutMs: 1_200_000, maxOutputBytes: 4_000_000 })
  const wallMs = performance.now() - started
  writeFileSync(join(output, `${label}.log`), result.stdout + result.stderr)
  if (!allowFailure) assert.equal(result.code, 0, describeProcessFailure(result))
  const report = JSON.parse(readFileSync(reportPath, 'utf8'))
  const tests = report.testResults.flatMap((suite) => suite.assertionResults)
  return { label, wallMs, bodyMs: tests.reduce((sum, test) => sum + (test.duration || 0), 0), passes: report.numPassedTests, skips: report.numPendingTests, failures: report.numFailedTests, cases: tests.map((test) => ({ name: test.fullName, status: test.status })).sort((a, b) => a.name.localeCompare(b.name)), witnesses: tests.filter((test) => test.status === 'failed').map((test) => test.fullName) }
}
function instrument(source, label) {
  let result = replaceRequired(source, '  let displayed: NativeChatMessage[] = []', `
  const captureStartedAt = Date.now()
  function captureOpenCode(kind: string, payload: unknown): void {
    const tables = version === 'v1' ? ['session', 'message', 'part'] : ['session_v2', 'session_message']
    recordOpenCodeObservation(kind, {
      version,
      elapsedMs: Date.now() - captureStartedAt,
      isTransaction: db.isTransaction,
      pragmas: { journalMode: db.pragma('journal_mode'), synchronous: db.pragma('synchronous') },
      schema: db.prepare("SELECT type, name, tbl_name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name").all(),
      rows: tables.map((table) => ({ table, rows: db.prepare('SELECT rowid, * FROM ' + table + ' ORDER BY rowid').all() })),
      payload
    })
  }
  captureOpenCode('seed', null)
  let displayed: NativeChatMessage[] = []`)
  result = replaceRequired(result, '  const onReplace = vi.fn((messages: NativeChatMessage[]) => {', '  const onReplace = vi.fn((messages: NativeChatMessage[], ...rest: unknown[]) => {')
  result = replaceRequired(result, '    displayed = messages\n  })', "    captureOpenCode('replace', [messages, ...rest])\n    displayed = messages\n  })")
  result = replaceRequired(result, '  const onAppend = vi.fn((messages: NativeChatMessage[]) => {', '  const onAppend = vi.fn((messages: NativeChatMessage[], ...rest: unknown[]) => {')
  result = replaceRequired(result, '    displayed.push(...messages)', "    captureOpenCode('append', [messages, ...rest])\n    displayed.push(...messages)")
  result = replaceRequired(result, `  const readPage = vi.fn(async (args: Parameters<typeof readOpenCodeTranscriptPage>[0]) =>
    readOpenCodeTranscriptPage(args)
  )`, `  const readPage = vi.fn(async (args: Parameters<typeof readOpenCodeTranscriptPage>[0]) => {
    const page = readOpenCodeTranscriptPage(args)
    captureOpenCode('page', { args: { ...args, dbPath: '<fixture-db>' }, page })
    return page
  })`)
  result = replaceRequired(result, `      onInitialSnapshot: (messages) => {
        displayed = messages
      },`, `      onInitialSnapshot: (...values) => {
        captureOpenCode('snapshot', values)
        displayed = values[0]
      },`)
  result = replaceRequired(result, '      readSignal: async (dbPath, sessionId) => readOpenCodeTranscriptSignal(dbPath, sessionId),', `      readSignal: async (dbPath, sessionId) => {
        const signal = readOpenCodeTranscriptSignal(dbPath, sessionId)
        captureOpenCode('signal', { sessionId, signal })
        return signal
      },`)
  result = replaceRequired(result, '  fixtures.push({ db, root, stop: subscription.unsubscribe })', `  fixtures.push({ db, root, stop: () => {
    subscription.unsubscribe()
    captureOpenCode('closed', null)
  } })`)
  return result + `
import { afterAll } from 'vitest'
import { createHash } from 'node:crypto'
import { appendFileSync } from 'node:fs'
const observations = new Map<string, { count: number; bytes: number; kinds: Record<string, number>; hash: ReturnType<typeof createHash> }>()
function recordOpenCodeObservation(kind: string, payload: unknown): void {
  const name = expect.getState().currentTestName ?? '<no-test>'
  let record = observations.get(name)
  if (!record) {
    record = { count: 0, bytes: 0, kinds: {}, hash: createHash('sha256') }
    observations.set(name, record)
  }
  const bytes = Buffer.from(JSON.stringify({ kind, payload }))
  const prefix = Buffer.alloc(4)
  prefix.writeUInt32LE(bytes.length)
  record.hash.update(prefix).update(bytes)
  record.count++
  record.bytes += prefix.length + bytes.length
  record.kinds[kind] = (record.kinds[kind] ?? 0) + 1
}
afterAll(() => {
  const rows = [...observations].map(([name, record]) => ({ name, count: record.count, bytes: record.bytes, kinds: record.kinds, sha256: record.hash.digest('hex') }))
  appendFileSync(${JSON.stringify(join(output, label + '-capture-'))} + process.pid + '.jsonl', JSON.stringify(rows) + '\\n')
})
`
}
function readCapture(label) {
  const rows = readdirSync(output).filter((name) => name.startsWith(label + '-capture-') && name.endsWith('.jsonl')).flatMap((name) => readFileSync(join(output, name), 'utf8').trim().split('\n').flatMap((line) => JSON.parse(line))).sort((a, b) => a.name.localeCompare(b.name))
  assert.equal(rows.length, 28)
  assert.equal(new Set(rows.map((row) => row.name)).size, 28)
  const kinds = {}
  for (const row of rows) {
    assert.equal(row.kinds.seed, 1)
    assert.equal(row.kinds.closed, 1)
    assert.equal(row.kinds.snapshot, 1)
    assert(row.kinds.page > 0 && row.kinds.signal > 0)
    for (const [kind, count] of Object.entries(row.kinds)) kinds[kind] = (kinds[kind] || 0) + count
  }
  return { rows, kinds, bytes: rows.reduce((sum, row) => sum + row.bytes, 0), canonicalSha256: digest(JSON.stringify(rows)) }
}
const marker = `  const readPage = vi.fn(async (args: Parameters<typeof readOpenCodeTranscriptPage>[0]) =>
    readOpenCodeTranscriptPage(args)
  )`
const rollbackMarker = `    const f = watchFixture(version)
    await vi.advanceTimersByTimeAsync(0)
    expect(f.displayed()).toHaveLength(300)
    f.update(1, 'edited oldest')`
const rollbackSource = replaceRequired(candidate, rollbackMarker, `    const f = watchFixture(version)
    await vi.advanceTimersByTimeAsync(0)
    expect(f.displayed()).toHaveLength(300)
    const table = version === 'v1' ? 'message' : 'session_message'
    const query = 'SELECT rowid, * FROM ' + table + ' ORDER BY rowid'
    const rows = f.db.prepare(query).all()
    expect(() => f.batch(() => {
      f.insert(3001, 'rolled back')
      throw new Error('rollback probe')
    })).toThrow('rollback probe')
    expect(f.db.isTransaction).toBe(false)
    expect(f.db.prepare(query).all()).toEqual(rows)
    f.update(1, 'edited oldest')`)
try {
  const samples = []
  const summary = { environment: { node: process.version, platform: platform(), release: release(), cpu: cpus()[0]?.model, imageOS: process.env.ImageOS, imageVersion: process.env.ImageVersion }, hashes: { baseline: digest(baseline), candidate: digest(candidate) } }
  let expectedCases
  for (let pair = 1; !controlsOnly && !captureOnly && pair <= 3; pair++) {
    for (const arm of pair % 2 ? ['baseline', 'candidate'] : ['candidate', 'baseline']) {
      writeFileSync(sourcePath, arm === 'baseline' ? baseline : candidate)
      const run = execute(`${arm}-${pair}`)
      assert.equal(run.passes, 28)
      assert.equal(run.skips, 0)
      assert.equal(run.failures, 0)
      if (!expectedCases) expectedCases = run.cases
      assert.deepEqual(run.cases, expectedCases)
      samples.push({ pair, arm, ...run })
      console.log(JSON.stringify({ pair, arm, wallMs: run.wallMs, bodyMs: run.bodyMs, passes: run.passes }))
    }
  }
  if (samples.length) {
    summary.samples = samples
    summary.baseline = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'baseline').map((sample) => sample.wallMs))
    summary.candidate = summarizeBenchmarkSamples(samples.filter((sample) => sample.arm === 'candidate').map((sample) => sample.wallMs))
    summary.changePercent = 100 * (summary.candidate.medianMs - summary.baseline.medianMs) / summary.baseline.medianMs
  }
  if (!controlsOnly && !timingOnly) {
    const captures = {}
    for (const arm of ['baseline', 'candidate']) {
      writeFileSync(sourcePath, instrument(arm === 'baseline' ? baseline : candidate, arm))
      const run = execute(`${arm}-full-capture`)
      assert.equal(run.passes, 28)
      assert.equal(run.skips, 0)
      if (!expectedCases) expectedCases = run.cases
      assert.deepEqual(run.cases, expectedCases)
      captures[arm] = readCapture(arm)
      writeFileSync(join(output, `${arm}-canonical-capture.json`), JSON.stringify(captures[arm], null, 2) + '\n')
      console.log(JSON.stringify({ arm, fullCapturePasses: run.passes, kinds: captures[arm].kinds, bytes: captures[arm].bytes, canonicalSha256: captures[arm].canonicalSha256 }))
    }
    assert.deepEqual(captures.candidate, captures.baseline)
    summary.capture = captures.candidate
  }
  if (!timingOnly && !captureOnly) {
    writeFileSync(sourcePath, rollbackSource)
    const rollback = execute('positive-rollback', ['--testNamePattern', 'replaces an edit older'])
    assert.equal(rollback.passes, 2)
    assert.equal(rollback.skips, 26)
    summary.rollback = rollback
    const faults = [
      { name: 'missing-row', pattern: 'replaces an edit older', source: replaceRequired(candidate, '  const insert = (index: number, text = `message ${index}`) => {', '  const insert = (index: number, text = `message ${index}`) => {\n    if (index === 1) return') },
      { name: 'frontier-rowid', pattern: 'keeps appending after the remembered window', source: replaceRequired(candidate, marker, `  const readPage = vi.fn(async (args: Parameters<typeof readOpenCodeTranscriptPage>[0]) => {
    const page = readOpenCodeTranscriptPage(args)
    return page && { ...page, items: page.items.map((item) => item.rowid > 2400 ? { ...item, rowid: 1 } : item) }
  })`) },
      { name: 'read-cap', pattern: 'holds the frontier and retries', source: replaceRequired(candidate, marker, `  const readPage = vi.fn(async (args: Parameters<typeof readOpenCodeTranscriptPage>[0]) => {
    args.limit = 2401
    return readOpenCodeTranscriptPage(args)
  })`) },
      { name: 'missing-commit', pattern: 'replaces an edit older', source: replaceRequired(candidate, "      db.exec('COMMIT')", '') },
      { name: 'missing-rollback', pattern: 'replaces an edit older', source: replaceRequired(rollbackSource, "      db.exec('ROLLBACK')", '') }
    ]
    summary.negativeControls = []
    for (const fault of faults) {
      writeFileSync(sourcePath, fault.source)
      const run = execute(`negative-${fault.name}`, ['--testNamePattern', fault.pattern], true)
      assert.equal(run.failures, 2, `fault survived: ${fault.name}`)
      assert.equal(run.skips, 26)
      summary.negativeControls.push({ name: fault.name, failures: run.failures, witnesses: run.witnesses })
      console.log(JSON.stringify({ fault: fault.name, failures: run.failures, witnesses: run.witnesses }))
    }
  }
  writeFileSync(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + '\n')
  console.log(JSON.stringify({ baseline: summary.baseline, candidate: summary.candidate, changePercent: summary.changePercent, capture: summary.capture && { kinds: summary.capture.kinds, bytes: summary.capture.bytes, canonicalSha256: summary.capture.canonicalSha256 }, negativeControls: summary.negativeControls }))
} finally { writeFileSync(sourcePath, candidate) }

