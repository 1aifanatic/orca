from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle, root, out = Path(__file__).resolve().parent, Path.cwd(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/main/ssh/ssh-remote-commands.test.ts')
fixture = Path('src/main/ssh/ssh-relay-gc-listing.test-fixture.ts')
manifest = json.loads((bundle / 'manifest.json').read_text())
for filename, expected in manifest.items():
    if hashlib.sha256((bundle / filename).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Frozen input changed: {filename}')
candidate = (bundle / 'candidate.source').read_text()
names = json.loads((bundle / 'case-names.json').read_text())
fixture_source = (bundle / 'fixture-candidate.source').read_text()
if (root / fixture).read_text() != fixture_source:
    raise RuntimeError('GC fixture differs from frozen candidate')
restore = (root / test).read_bytes()
production = {
    'commands': (Path('src/main/ssh/ssh-remote-commands.ts'), 'remote-commands-original.source'),
    'exec': (Path('src/main/ssh/ssh-relay-exec-command.ts'), 'exec-command-original.source')
}
original = {family: (bundle / frozen).read_text() for family, (_, frozen) in production.items()}
scale = 'bounds real POSIX GC output with more than the exec-cap stage population'
failure = 'fails closed when real POSIX GC enumeration fails'
mutants = [
    ('uncapped-transport', 'exec', 'combined.slice(-MAX_EXEC_OUTPUT_CHARS)', 'combined', scale, 'expected'),
    ('head-only-transport', 'exec', 'combined.slice(-MAX_EXEC_OUTPUT_CHARS)',
     'combined.slice(0, MAX_EXEC_OUTPUT_CHARS)', scale, 'not to contain'),
    ('disabled-name-filter', 'commands', 'name ~ /${namePattern}/ && count <', 'count <', scale, 'to deeply equal'),
    ('sixty-five-valid-results', 'commands', 'MAX_RELAY_GC_LISTING_ENTRIES = 64',
     'MAX_RELAY_GC_LISTING_ENTRIES = 65', scale, 'to deeply equal'),
    ('reversed-listing-order', 'commands', 'for (i=0; i<count; i++) print entries[i]',
     'for (i=count-1; i>=0; i--) print entries[i]', scale, 'to deeply equal'),
    ('files-and-symlinks-admitted', 'commands', '-maxdepth 1 -type d -name', '-maxdepth 1 -name', scale, 'to deeply equal'),
    ('nested-installs-admitted', 'commands', '-mindepth 1 -maxdepth 1 -type d', '-mindepth 1 -type d', scale, 'to deeply equal'),
    ('enumeration-failure-ignored', 'commands', 'if (status != 0) exit 1;', '', failure, 'promise resolved')
]
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_SSH_GC_MUTANT_IMPORTED': '0'}
rows = []
try:
    for label, family, pattern, replacement, selected, expected in mutants:
        relative, frozen = production[family]
        if (root / relative).read_text() != original[family] or original[family].count(pattern) != 1:
            raise RuntimeError(f'Changed production source/mutation site: {relative}: {pattern}')
        mutated = original[family].replace(pattern, replacement)
        mutated = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                         lambda match: 'from ' + json.dumps((root / relative.parent / match.group(2)).resolve().as_posix()),
                         mutated)
        mutated += "\nprocess.env.ORCA_SSH_GC_MUTANT_IMPORTED = '1'\n"
        module_file = out / f'{label}.ts'
        module_file.write_text(mutated)
        config = out / f'{label}.config.ts'
        module_name = relative.stem
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*' + module_name +
                          '$/, replacement: ' + json.dumps(module_file.as_posix()) +
                          ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        source = candidate.replace('import { describe, expect, it }', 'import { afterAll, describe, expect, it }')
        source += "\nafterAll(() => expect(process.env.ORCA_SSH_GC_MUTANT_IMPORTED).toBe('1'))\n"
        (root / test).write_text(source)
        target = out / f'{label}.json'
        started = time.perf_counter()
        with (out / f'{label}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(test),
                                   '--maxWorkers=1', '--experimental.fsModuleCache=false',
                                   '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        report = json.loads(target.read_text())
        cases = [case for suite in report['testResults'] for case in suite['assertionResults']]
        failed = [case for case in cases if case['status'] == 'failed']
        if sorted(case['fullName'] for case in cases) != names or proc.returncode != 1 or \
                report['numPassedTests'] != 0 or report['numFailedTests'] != 1 or \
                report['numPendingTests'] != 26 or len(failed) != 1 or failed[0]['title'] != selected or \
                expected not in failed[0]['failureMessages'][0]:
            raise RuntimeError(f'{label} failed at an unexpected oracle; inspect {target}')
        row = {'mutation': label, 'productionSha256': hashlib.sha256(mutated.encode()).hexdigest(),
               'testSha256': hashlib.sha256(source.encode()).hexdigest(),
               'fixtureSha256': manifest['fixture-candidate.source'],
               'processWallSeconds': time.perf_counter() - started, 'bodyMs': failed[0].get('duration', 0),
               'failed': 1, 'pending': 26, 'failure': failed[0]['failureMessages'][0].split('\n')[0]}
        rows.append(row)
        print(json.dumps(row), flush=True)
        (root / test).write_bytes(restore)
finally:
    (root / test).write_bytes(restore)
    if (root / test).read_bytes() != restore or (root / fixture).read_text() != fixture_source:
        raise RuntimeError('Test/fixture restoration failed')
    for family, (relative, _) in production.items():
        if (root / relative).read_text() != original[family]:
            raise RuntimeError(f'Production changed during controls: {relative}')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
