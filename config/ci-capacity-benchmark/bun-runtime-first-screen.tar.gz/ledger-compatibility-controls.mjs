import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import { captureRawCaseLedger } from './headless-raw-case-ledger.mjs'

assert.equal(process.env.ORCA_BACKGROUND_LAUNCH, '1')
const bundle = import.meta.dirname
const output = resolve(process.argv[2])
mkdirSync(output)
const hash = (path) => createHash('sha256').update(readFileSync(path)).digest('hex')
const read = (name) => JSON.parse(readFileSync(join(bundle, name), 'utf8'))
const save = (name, value) => writeFileSync(join(output, name), JSON.stringify(value, null, 2) + '\n')
const manifest = read('manifest.json')
for (const [name, expected] of Object.entries(manifest.inputHashes)) {
  assert.equal(hash(join(bundle, name)), expected, name)
}
const metadata = read('ledger-compatibility-inputs/baseline-metadata.json')
const baselinePath = join(bundle, 'ledger-compatibility-inputs/baseline-vitest.json')
assert.equal(hash(baselinePath), metadata.actualRawReportSha256)
const report = read('ledger-compatibility-inputs/baseline-vitest.json')
const baseline = captureRawCaseLedger(baselinePath, metadata.sourceRoot)
assert.equal(baseline.cases.length, 973)
assert.equal(baseline.files.length, 93)
assert.equal(baseline.cases.filter((row) => row.status === 'passed').length, 942)
assert.equal(baseline.cases.filter((row) => row.status === 'skipped').length, 31)
const expectedCases = report.testResults.flatMap((module) => module.assertionResults.map((row) => ({
  file: relative(metadata.sourceRoot, module.name), ancestorTitles: row.ancestorTitles,
  fullName: row.fullName, title: row.title, status: row.status
})))
assert.deepEqual(baseline.cases.map((row) => JSON.stringify(row)).sort(),
  expectedCases.map((row) => JSON.stringify(row)).sort())
save('actual-baseline-ledger.json', baseline)
const driver = readFileSync(join(bundle, 'run-first-screen.mjs'), 'utf8')
const statement = "assert.deepEqual(receipts[1].rawCases, receipts[0].rawCases, 'Full raw case ledgers changed')"
assert.equal(driver.split(statement).length - 1, 1)
const compare = new Function('assert', 'receipts', statement)
compare(assert, [{ rawCases: baseline }, { rawCases: baseline }])
const controls = [{ name: 'actual-942-passed-31-literal-skipped', outcome: 'captured-exact-973-identities' }]

function variant(name, mutate, comparison = false) {
  const changed = structuredClone(report)
  const rows = changed.testResults.flatMap((module) => module.assertionResults)
  mutate(changed, rows)
  save(name + '.json', changed)
  const path = join(output, name + '.json')
  if (!comparison) {
    assert.throws(() => captureRawCaseLedger(path, metadata.sourceRoot), (error) =>
      error.code === 'ERR_ASSERTION' && error.message.includes('includes(item.status)'))
    controls.push({ name, outcome: 'rejected-at-status-guard', rawSha256: hash(path) })
    return
  }
  const captured = captureRawCaseLedger(path, metadata.sourceRoot)
  assert.deepEqual(captured.files, baseline.files)
  if (name === 'count-preserving-status-swap') assert.deepEqual(captured.totals, baseline.totals)
  save(name + '-ledger.json', captured)
  assert.throws(() => compare(assert, [{ rawCases: baseline }, { rawCases: captured }]), (error) =>
    error.code === 'ERR_ASSERTION' && error.message.includes('Full raw case ledgers changed'))
  controls.push({ name, outcome: 'captured-but-exact-ledger-comparison-rejected', rawSha256: hash(path) })
}

variant('unknown-status', (_report, rows) => { rows.find((row) => row.status === 'passed').status = 'unknown' })
variant('failed-status-with-healthy-root-counts', (_report, rows) => { rows.find((row) => row.status === 'passed').status = 'failed' })
variant('passed-to-skipped', (report, rows) => {
  rows.find((row) => row.status === 'passed').status = 'skipped'
  report.numPassedTests--; report.numPendingTests++
}, true)
variant('skipped-to-passed', (report, rows) => {
  rows.find((row) => row.status === 'skipped').status = 'passed'
  report.numPassedTests++; report.numPendingTests--
}, true)
variant('count-preserving-status-swap', (_report, rows) => {
  const passed = rows.find((row) => row.status === 'passed')
  const skipped = rows.find((row) => row.status === 'skipped')
  passed.status = 'skipped'; skipped.status = 'passed'
}, true)
for (const [name, expected] of Object.entries(manifest.inputHashes)) {
  assert.equal(hash(join(bundle, name)), expected, name)
}
save('control-receipt.json', { status: 'PASS', bundle, manifestSha256: hash(join(bundle, 'manifest.json')),
  captureModuleSha256: hash(join(bundle, 'headless-raw-case-ledger.mjs')),
  unchangedDriverSha256: hash(join(bundle, 'run-first-screen.mjs')),
  controlSourceSha256: hash(join(bundle, 'ledger-compatibility-controls.mjs')),
  actualRawReportSha256: hash(baselinePath), exactComparisonStatement: statement,
  controls, statusesPreservedLiterally: true, duplicateIdentityMultiplicityPreserved: true,
  localNode: process.version, localPlatform: process.platform,
  productionBuildOrTestRerunOrTimingOrAPIOrDownload: false, candidatePerformanceQualified: false })
