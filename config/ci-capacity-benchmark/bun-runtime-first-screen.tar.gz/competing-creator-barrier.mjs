import fs from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { join } from 'node:path'

const exists = fs.existsSync
const ready = process.env.SCREEN_CREATOR_BARRIER
fs.existsSync = (path) => {
  const result = exists(path)
  if (path === process.env.SCREEN_CREATOR_CACHE && !result) {
    fs.writeFileSync(join(ready, process.env.SCREEN_CREATOR_ID), '')
    const end = Date.now() + 5000
    while (!(exists(join(ready, 'one')) && exists(join(ready, 'two')))) {
      if (Date.now() > end) throw new Error('Competing creator barrier timed out')
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 10)
    }
  }
  return result
}
syncBuiltinESMExports()
