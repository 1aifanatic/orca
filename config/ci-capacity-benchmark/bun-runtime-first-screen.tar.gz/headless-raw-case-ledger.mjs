import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { relative } from 'node:path'

export function captureRawCaseLedger(path, root) {
  const report = JSON.parse(readFileSync(path, 'utf8'))
  assert.equal(report.success, true)
  for (const name of ['numFailedTests', 'numFailedTestSuites', 'numRuntimeErrorTestSuites', 'numUnhandledErrors']) {
    assert.equal(report[name] ?? 0, 0, name)
  }
  assert.deepEqual(report.unhandledErrors ?? [], [])
  assert.equal(report.snapshot.didUpdate, false)
  assert.equal(report.snapshot.failure, false)
  for (const key of ['added', 'updated', 'unmatched']) assert.equal(report.snapshot[key], 0)
  const files = []
  const cases = []
  for (const module of report.testResults) {
    const file = relative(root, module.name)
    assert(file && !file.startsWith('..'))
    assert(!files.includes(file), 'Duplicate module')
    files.push(file)
    assert(['passed', 'pending'].includes(module.status))
    assert.equal(module.message ?? '', '')
    for (const item of module.assertionResults) {
      assert(['passed', 'pending', 'todo', 'skipped'].includes(item.status))
      assert.deepEqual(item.failureMessages ?? [], [])
      cases.push({ file, ancestorTitles: item.ancestorTitles, fullName: item.fullName,
        title: item.title, status: item.status })
    }
  }
  assert(cases.length > 0 && files.length > 0)
  assert.equal(cases.length, report.numTotalTests)
  assert.equal(cases.filter((item) => item.status === 'passed').length, report.numPassedTests)
  cases.sort((left, right) => JSON.stringify(left).localeCompare(JSON.stringify(right)))
  return { files: files.sort(), cases, totals: {
    total: report.numTotalTests, passed: report.numPassedTests,
    pending: report.numPendingTests, todo: report.numTodoTests ?? 0
  } }
}
