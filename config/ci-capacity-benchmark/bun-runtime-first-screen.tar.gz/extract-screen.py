import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile

root = Path(os.environ['GITHUB_WORKSPACE'])
temporary = Path(os.environ['RUNNER_TEMP'])
bundle = temporary / 'bun-runtime-first-screen-bundle'
output = temporary / 'bun-runtime-first-screen-results'
bundle.mkdir(exist_ok=False)
output.mkdir(exist_ok=False)
archive = root / 'config/ci-capacity-benchmark/bun-runtime-first-screen.tar.gz'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
bootstrap = {'runId': os.environ['GITHUB_RUN_ID'], 'runAttempt': os.environ['GITHUB_RUN_ATTEMPT'],
             'bootstrapSha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             'bootstrapTree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
             'eventSha': os.environ['GITHUB_SHA'], 'workflowRef': os.environ['GITHUB_WORKFLOW_REF'],
             'archiveSha256': sha(archive)}
assert bootstrap['bootstrapSha'] == bootstrap['eventSha']
(output / 'bootstrap.json').write_text(json.dumps(bootstrap, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as stream:
    members = stream.getmembers()
    assert len(members) <= 128 and len({member.name for member in members}) == len(members)
    assert sum(member.size for member in members) <= 16 * 1024 * 1024
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        target = bundle / member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(stream.extractfile(member).read())
manifest = json.loads((bundle / 'manifest.json').read_text())
actual = {str(path.relative_to(bundle)) for path in bundle.rglob('*') if path.is_file()}
assert actual == set(manifest['inputHashes']) | {'manifest.json'}
for name, expected in manifest['inputHashes'].items():
    assert sha(bundle / name) == expected, name
assert sha(bundle / 'prototype/manifest.json') == 'abe95ebe178523a651b588aba6e90bb8330e673970872571fba1a38806cc8797'
shutil.copytree(bundle, output / 'portable-inputs')
(output / 'manifest.json').write_bytes((bundle / 'manifest.json').read_bytes())
environment = {'SCREEN_BUNDLE': str(bundle), 'SCREEN_RESULTS': str(output),
               'SCREEN_DRIVER': str(bundle / 'run-first-screen.mjs'),
               'SCREEN_NARROW_OUTPUT': str(output / 'narrow-workflow-checks'),
               'SCREEN_CONTROL_LEGACY': str(temporary / 'bun-runtime-control-source'),
               'SCREEN_CONTROL_OUTPUT': str(output / 'runtime-controls')}
with open(os.environ['GITHUB_ENV'], 'a') as stream:
    for name, value in environment.items():
        stream.write(name + '=' + value + '\n')
