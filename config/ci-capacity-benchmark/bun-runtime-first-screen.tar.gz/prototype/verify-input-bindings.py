import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args]).decode().strip()


def digest(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f'Regular file required: {path}')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_checkout(root, expected, candidate_files=None):
    if git(root, 'rev-parse', 'HEAD') != expected['commit']:
        raise ValueError(f'Unexpected HEAD: {root}')
    if git(root, 'rev-parse', 'HEAD^{tree}') != expected['tree']:
        raise ValueError(f'Unexpected source tree: {root}')
    if git(root, 'diff', '--cached', '--name-only'):
        raise ValueError(f'Staged source changes: {root}')
    changes = set(git(root, 'diff', '--name-only', 'HEAD').splitlines())
    untracked = set(git(root, 'ls-files', '--others', '--exclude-standard').splitlines())
    allowed = candidate_files or {}
    if changes != (set(allowed) & set(expected['files'])):
        raise ValueError(f'Unexpected tracked changes: {root}: {changes}')
    if untracked != (set(allowed) - set(expected['files'])):
        raise ValueError(f'Unexpected untracked source: {root}: {untracked}')
    for name, metadata in expected['files'].items():
        wanted = allowed.get(name, metadata['sha256'])
        if digest(root / name) != wanted:
            raise ValueError(f'Changed input: {root / name}')
    for name, wanted in allowed.items():
        if digest(root / name) != wanted:
            raise ValueError(f'Changed candidate: {root / name}')
    for name in expected['absent']:
        if name not in allowed and ((root / name).exists() or (root / name).is_symlink()):
            raise ValueError(f'Unexpected previously absent input: {root / name}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--current-root', type=Path, required=True)
    parser.add_argument('--legacy-root', type=Path, required=True)
    parser.add_argument('--candidate', action='store_true')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    manifest_path = bundle / 'manifest.json'
    if digest(manifest_path) != args.manifest_sha256:
        raise ValueError('Manifest differs from externally approved SHA-256')
    manifest = json.loads(manifest_path.read_text())
    if any(path.is_symlink() for path in bundle.rglob('*')):
        raise ValueError('Symlink in frozen bundle')
    actual_paths = {
        str(path.relative_to(bundle)) for path in bundle.rglob('*') if path.is_file()
    }
    if actual_paths != set(manifest['files']) | {'manifest.json'}:
        raise ValueError('Bundle file inventory changed')
    for name, metadata in manifest['files'].items():
        if digest(bundle / name) != metadata['sha256']:
            raise ValueError(f'Changed frozen bundle asset: {name}')
    inputs = json.loads((bundle / 'input-bindings.json').read_text())
    candidates = manifest['production_candidate_files'] if args.candidate else None
    verify_checkout(args.current_root.resolve(), inputs['current'], candidates)
    verify_checkout(args.legacy_root.resolve(), inputs['legacy'])
    print(json.dumps({'verified': True, 'candidate': args.candidate,
                      'manifest_sha256': args.manifest_sha256}))


if __name__ == '__main__':
    main()
