import { createHash } from 'node:crypto'
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { currentTarget } from './server-build-target.mjs'

export async function reuseInstalledLegacyBun({ sourceDir, installedExecutable }) {
  if (process.platform !== 'linux' || !installedExecutable) {
    return { reused: false, reason: 'No installed Linux Bun to reuse' }
  }
  try {
    const legacy = resolve(sourceDir)
    const { ORCAD_BUN_VERSION, ORCAD_BUN_RELEASE_ASSETS } = await import(
      pathToFileURL(join(legacy, 'src/shared/orcad-bun-runtime.ts')).href
    )
    const { orcadBunRuntimeFilename } = await import(
      pathToFileURL(join(legacy, 'src/shared/orcad-artifacts.ts')).href
    )
    const target = currentTarget()
    const asset = ORCAD_BUN_RELEASE_ASSETS[target]
    if (!asset) {
      return { reused: false, reason: 'The legacy builder does not support this target' }
    }
    const cached = join(
      legacy, 'out', '.orcad-bun-runtime', `v${ORCAD_BUN_VERSION}`, target,
      orcadBunRuntimeFilename(target)
    )
    if (existsSync(cached)) {
      return { reused: false, reason: 'The legacy builder will check its existing runtime cache' }
    }
    const bytes = readFileSync(installedExecutable)
    if (createHash('sha256').update(bytes).digest('hex') !== asset.executableSha256) {
      return { reused: false, reason: 'Installed Bun differs from the pinned legacy executable' }
    }
    mkdirSync(dirname(cached), { recursive: true })
    writeFileSync(cached, bytes, { flag: 'wx', mode: 0o755 })
    chmodSync(cached, 0o755)
    // The unchanged builder still checks the cache hash and executes its version probe.
    return { reused: true, target, cached }
  } catch (error) {
    return { reused: false, reason: String(error) }
  }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const result = await reuseInstalledLegacyBun({
    sourceDir: process.argv[2],
    installedExecutable: process.argv[3]
  })
  console.log(JSON.stringify(result))
}
