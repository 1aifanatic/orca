# Legacy Bun runtime reuse: prepared candidate

This is a TEMP-only source design. The helper, builder, controls, tests and timing screen have not run. No API, download, dispatch or primary-source edits were performed by this author. Root supplied the existing job metadata and exact upstream action source.

The candidate avoids a duplicate Bun download only when the binary installed by the existing pinned `setup-bun` action exactly matches the frozen legacy builder's executable SHA-256. It copies those bytes into that builder's existing runtime cache and then runs the unchanged historical build. It introduces no artifact cache, cache marker, cached test verdict or new cache client.

The three production paths are the workflow, its existing change classifier, and the new `reuse-legacy-orcad-bun-runtime.mjs`. `candidate.patch` contains precisely those changes. The unchanged pure `server-build-target.mjs` is included beside the TEMP helper solely for isolated qualification; it is already present in the production checkout and is not a production change.

## Source and integrity authority

- Current source: `1bec53ceb23b5f296a38ffa0e085778d32fc7849`, tree `8dda0783bd3355b2ae8068b9ca4e3e21f65240e8`.
- Legacy source: `f4092c06d639ee13ad446261dcabc78b27a21fbc`, tree `e11c31b0bce8ae903fc8e46ea2efdb5d6038350d`.
- Upstream action: `oven-sh/setup-bun@0c5077e51419868618aeaa5fe8019c62421857d6`. Supplied TS files match the upstream Git blob IDs. The actual bundled `dist/setup/index.js` was not inspected; the real screen must observe its installed bytes.
- `input-bindings.json` binds 32 selected build/test/toolchain files and each entire named Git tree. This selected inventory is not claimed to enumerate every transitive build input.

The helper reads version, asset and runtime filename from the legacy checkout's exact `src/shared/orcad-bun-runtime.ts` and `src/shared/orcad-artifacts.ts`. It uses the existing current pure target classifier. Static extraction confirmed the historical and current classifier bodies are identical except the unsupported-platform error label. Importing the old builder to call its target helper would execute top-level esbuild setup through `script-child-process.mjs`; the candidate avoids that duplicate work.

The existing builder's `materializeRuntime()` is authoritative. It removes a cache file with the wrong executable SHA, downloads and checks the pinned ZIP if absent, always checks the executable SHA again, and actually executes `--version` for the current host before building. Required version is `1.4.2`. Canonical Linux glibc executable hashes are:

| Target | Executable SHA-256 |
| --- | --- |
| linux-x64-glibc | a83d263767d839e4d2649ca8e35d07159c7afc99afdc96d731ced29e056dda0c |
| linux-arm64-glibc | 616f267a34278ff5ac282df37ffdfba1d7141f4f6926bca99af2cd6ef3ad32b1 |

The cache location is `<legacy>/out/.orcad-bun-runtime/v1.4.2/<target>/bun-runtime`. No new metadata is written. Missing/unreadable installed binary, checksum mismatch, absent target metadata or non-Linux execution declines the preseed. An existing cache is left to the canonical builder to check. Unsupported canonical build targets retain the builder's original failure; the helper does not pretend they are supported.

## Installed binary and rejected override

The action's existing default URL selects `bun-linux-x64.zip` when `/proc/cpuinfo` contains AVX2, otherwise `bun-linux-x64-baseline.zip`; unreadable CPU information also selects baseline. ARM64 maps to `bun-linux-aarch64.zip`. The legacy pin always names the modern x64 archive. A default baseline x64 binary therefore fails the helper's exact checksum gate and follows the unchanged old download path. No version-string equivalence is accepted as binary identity.

`bun-download-url` is a supported action option, but the supplied pinned `src/action.ts` proves any custom URL disables both its existing-install shortcut and its cache. A forced canonical URL would move the download into the foreground and could erase the observed join frontier. That provisional design was never run and is preserved under `rejected-forced-url/`; it is excluded from the production patch. The candidate retains the existing action version, version input, default variant and caching behavior.

The workflow consumes the pinned action's `bun-path` output for both preseed and cross-runtime test executable, replacing PATH lookup. Actual canonical installed x64 SHA is mandatory in the real screen before considering performance adoption. An ARM-only result does not establish this candidate's material x64 opportunity.

## Existing timing evidence

Root supplied successful attempt 1 metadata for run `37252271146`, reported head `9c7b036da57b5c74905d37730870767e5204ab40`. The actual tested checkout SHA was not independently captured here, and this observation is not a timing result for the frozen candidate source.

| Persistence lane | Job elapsed | Background Bun producer | Foreground prebuild + Node build | Bun join |
| --- | ---: | ---: | ---: | ---: |
| ubuntu-22.04 / x64, job 111582231827 | 80 s | 17 s | 10 s | 7 s |
| ubuntu-24.04-arm, job 111582231937 | 89 s | 16 s | 14 s | 2 s |

These second-resolution observations establish a small join frontier. They do not show how much time downloads consumed, a candidate gain, p50/p95 improvement, or avoidable workflow runner-hours. Hashing and copying the installed executable also cost time. Setup, producer, preparation-to-tests boundary and occupied job elapsed must all be measured.

## Coverage and workflow behavior

The legacy independent `pnpm install`, fixed source, full build, native watcher smoke, actual Bun profile-state preflight, Node worker/load checks, artifact content hash, background execution and mandatory failure-propagating join remain. Current Node build, all unchanged Node-server test selectors and both cross-runtime integration modules remain. Existing protocol mismatch skips remain explicit; they cannot be converted into missing-input skips.

Main, release, scheduled and manual qualification retain their existing matrix, source selection, Node18 checks and template paths. Only the existing Linux Bun runtime materialization can reuse exact bytes; its JavaScript/native artifacts and smoke checks are rebuilt. The new helper path is added to the classifier's existing `ALWAYS_FILES`, so a future helper-only change cannot skip CI. Existing qualification policy already treats a `bun` path as full qualification.

## Input guard and qualification plan

The frozen `verify-input-bindings.py` is read-only and has not run. Root can execute it against isolated current and legacy checkouts, supplying the externally reviewed manifest SHA. Baseline requires both named HEADs/trees, no tracked or untracked changes and exact selected file bytes/absences. `--candidate` permits precisely the three production paths from the manifest and requires their exact candidate bytes. Write all results outside this bundle. Dependency installs and output caches are ignored Git outputs, not permitted source edits.

`CONTROLS.md` specifies the smallest real runtime proof, failure controls and initial paired screen. No control result or speed result is claimed by this preparation receipt. The unchanged background/failure barrier evidence in `docs/reference/ci-runner-efficiency.md` may be cited for identical workflow guards; it does not qualify this new helper's actual copying or fallback behavior.
