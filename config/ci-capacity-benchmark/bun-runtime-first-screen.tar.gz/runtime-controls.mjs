import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { reuseInstalledLegacyBun } from './prototype/candidate/config/scripts/reuse-legacy-orcad-bun-runtime.mjs'

const source = resolve(process.env.SCREEN_SOURCE_ROOT)
const legacy = resolve(process.env.SCREEN_CONTROL_LEGACY)
const output = resolve(process.env.SCREEN_CONTROL_OUTPUT)
const installed = process.env.SCREEN_INSTALLED_BUN
const { runProcessSync, spawnProcess } = await import(
  pathToFileURL(join(source, 'config/scripts/script-child-process.mjs')).href
)
const sha = (path) => createHash('sha256').update(readFileSync(path)).digest('hex')
const expected = 'a83d263767d839e4d2649ca8e35d07159c7afc99afdc96d731ced29e056dda0c'
assert.equal(process.platform, 'linux')
assert.equal(process.arch, 'x64')
assert.equal(sha(installed), expected, 'Visible stop: installed x64 variant differs from canonical legacy Bun')
mkdirSync(output, { recursive: false })
const record = (name, value) => writeFileSync(join(output, name + '.json'), JSON.stringify(value, null, 2) + '\n')
const installedVersion = runProcessSync({ program: installed, args: ['--version'] })
assert.equal(installedVersion.code, 0)
assert.equal(installedVersion.stdout.trim(), '1.4.2')
record('installed-binary', { path: installed, sha256: sha(installed), bytes: statSync(installed).size, actualVersion: installedVersion })
const cached = join(legacy, 'out/.orcad-bun-runtime/v1.4.2/linux-x64-glibc/bun-runtime')
assert(!existsSync(cached))
const healthy = await reuseInstalledLegacyBun({ sourceDir: legacy, installedExecutable: installed })
assert.equal(healthy.reused, true)
assert.equal(healthy.cached, cached)
assert.equal(sha(cached), expected)
assert.equal(statSync(cached).mode & 0o777, 0o755)
record('healthy-preseed', healthy)
const downloadLog = join(output, 'bun-download.log')
writeFileSync(downloadLog, '')
const canonicalUrl = 'https://github.com/oven-sh/bun/releases/download/bun-v1.4.2/bun-linux-x64.zip'
function builder(name, forbid) {
  const result = runProcessSync({ program: process.execPath,
    args: ['--import', join(import.meta.dirname, 'observe-runtime-download.mjs'),
      join(legacy, 'config/scripts/build-orcad-bun.mjs'), '--runtime-only', '--out-dir', join(output, name)],
    cwd: legacy, timeoutMs: 180000, env: { ...process.env,
      SCREEN_CANONICAL_BUN_URL: canonicalUrl, SCREEN_BUN_DOWNLOAD_LOG: downloadLog,
      SCREEN_FORBID_BUN_DOWNLOAD: forbid ? '1' : '0' } })
  record(name, result)
  assert.equal(result.code, 0)
  assert.equal(sha(join(output, name, 'bun-runtime')), expected)
}
builder('healthy-runtime-only', true)
assert.equal(readFileSync(downloadLog, 'utf8'), '')
writeFileSync(cached, 'Owned deliberately corrupted cache\n')
const badHash = sha(cached)
const declined = await reuseInstalledLegacyBun({ sourceDir: legacy, installedExecutable: installed })
assert.equal(declined.reused, false)
assert.equal(sha(cached), badHash)
record('corrupted-cache-declined', { declined, preservedSha256: badHash })
builder('corrupted-cache-fallback', false)
assert.equal(readFileSync(downloadLog, 'utf8'), canonicalUrl + '\n')
assert.equal(sha(cached), expected)
rmSync(cached)
const invalid = join(output, 'different-installed-binary')
writeFileSync(invalid, 'Tiny deliberately mismatched installed binary\n')
const negatives = []
for (const executable of [undefined, join(output, 'missing-installed-binary'), invalid]) {
  const result = await reuseInstalledLegacyBun({ sourceDir: legacy, installedExecutable: executable })
  assert.equal(result.reused, false)
  assert(!existsSync(cached))
  negatives.push(result)
}
for (const [key, value] of [['platform', 'win32'], ['arch', 's390x']]) {
  const descriptor = Object.getOwnPropertyDescriptor(process, key)
  try {
    Object.defineProperty(process, key, { ...descriptor, value })
    const result = await reuseInstalledLegacyBun({ sourceDir: legacy, installedExecutable: installed })
    assert.equal(result.reused, false)
    assert(!existsSync(cached))
    negatives.push({ processFixture: { [key]: value }, result })
  } finally {
    Object.defineProperty(process, key, descriptor)
  }
}
record('tiny-negative-inputs', negatives)
const barrier = join(output, 'competing-creators')
mkdirSync(barrier)
function creator(id) {
  const child = spawnProcess({ program: process.execPath,
    args: ['--import', join(import.meta.dirname, 'competing-creator-barrier.mjs'),
      join(import.meta.dirname, 'prototype/candidate/config/scripts/reuse-legacy-orcad-bun-runtime.mjs'), legacy, installed],
    env: { ...process.env, SCREEN_CREATOR_CACHE: cached, SCREEN_CREATOR_BARRIER: barrier,
      SCREEN_CREATOR_ID: id }, stdio: ['ignore', 'pipe', 'pipe'] })
  return new Promise((done, reject) => {
    let stdout = '', stderr = ''
    child.stdout.on('data', (chunk) => { stdout += chunk })
    child.stderr.on('data', (chunk) => { stderr += chunk })
    child.on('error', reject)
    const timer = setTimeout(() => child.kill('SIGKILL'), 30000)
    child.on('close', (code) => { clearTimeout(timer); done({ id, code, stdout, stderr }) })
  })
}
const racers = await Promise.all([creator('one'), creator('two')])
const parsed = racers.map((item) => ({ ...item, result: JSON.parse(item.stdout) }))
record('competing-creator-results', parsed)
assert(parsed.every((item) => item.code === 0))
assert.equal(parsed.filter((item) => item.result.reused).length, 1)
assert.match(parsed.find((item) => !item.result.reused).result.reason, /EEXIST/)
assert.equal(sha(cached), expected)
assert.equal(statSync(cached).mode & 0o777, 0o755)
record('control-receipt', { passed: true, healthySha256: expected, healthyNoRedownload: true,
  realCorruptCacheDownloads: 1, negativeInputs: negatives.length, exclusiveCreation: true,
  fixtureOnlyProcessOverrides: true, sourceHelperUnchanged: true })
