import { appendFileSync } from 'node:fs'

const originalFetch = globalThis.fetch
globalThis.fetch = async (...args) => {
  const url = String(args[0]?.url ?? args[0])
  if (url === process.env.SCREEN_CANONICAL_BUN_URL) {
    appendFileSync(process.env.SCREEN_BUN_DOWNLOAD_LOG, `${url}\n`)
    if (process.env.SCREEN_FORBID_BUN_DOWNLOAD === '1') {
      throw new Error('Healthy canonical cache unexpectedly redownloaded Bun')
    }
  }
  return originalFetch(...args)
}
