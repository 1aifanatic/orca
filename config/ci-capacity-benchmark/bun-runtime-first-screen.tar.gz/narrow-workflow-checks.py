import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path(os.environ["SCREEN_SOURCE_ROOT"]).resolve()
bundle = Path(__file__).resolve().parent / "prototype"
out = Path(os.environ["SCREEN_NARROW_OUTPUT"]).resolve()
out.mkdir(exist_ok=False)

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=root, timeout=30).decode().strip()

def source_snapshot():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=root, timeout=30).decode().rstrip('\n'),
            'changedPaths': git('diff', 'HEAD', '--name-only').splitlines(),
            'stagedPaths': git('diff', '--cached', '--name-only').splitlines()}

def require_owned_source_paths():
    assert git('rev-parse', 'HEAD') == manifest['sourceSha']
    assert git('rev-parse', 'HEAD^{tree}') == manifest['sourceTreeGitOid']
    # Preflight both subjects before writing either, preserving concurrent edits.
    for row in manifest['subjects']:
        path = row['file']
        source = root / path
        assert source.is_file() and not source.is_symlink(), 'Missing or unexpected owned path: ' + path
        assert source.read_bytes() in sources[path].values(), 'Unknown concurrent owned bytes: ' + path

def restore_owned_sources():
    refused = {}
    checkout_changed = git('rev-parse', 'HEAD') != manifest['sourceSha'] or git('rev-parse', 'HEAD^{tree}') != manifest['sourceTreeGitOid']
    for row in manifest['subjects']:
        path = row['file']
        source = root / path
        reason = None
        if checkout_changed:
            reason = 'Checkout changed; preserving the new checkout'
        elif not source.is_file() or source.is_symlink():
            reason = 'Missing or unexpected subject path; preserving it'
        elif source.read_bytes() not in sources[path].values():
            reason = 'Unknown concurrent subject bytes; preserving them'
        if reason is not None:
            refused[path] = {'reason': reason, 'savedOriginalPath': str(bundle / row['originalAsset'])}
        else:
            source.write_bytes(sources[path]['original'])
    if refused:
        write_json(out / 'restore-refused.json', {'refused': refused, 'runId': os.environ.get('GITHUB_RUN_ID'),
                                                'runAttempt': os.environ.get('GITHUB_RUN_ATTEMPT')})
        raise RuntimeError('Subject restoration refused; unknown contents preserved and known subjects restored')

def terminate_owned_group(process):
    # Kill the original group even when its leader exits after TERM.
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait(timeout=5)

def invoke(command, env, log, timeout):
    started = time.perf_counter()
    timed_out = False
    with log.open('x') as stream:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            status = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            terminate_owned_group(process)
            status = process.returncode
        except BaseException:
            terminate_owned_group(process)
            raise
    return status, time.perf_counter() - started, timed_out

class Interrupted(Exception):
    pass

def on_signal(number, frame):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    raise Interrupted('Signal ' + str(number))

signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT, on_signal)

inputs = json.loads((bundle / 'input-bindings.json').read_text())
paths = ['.github/workflows/node-server-tests.yml', 'config/scripts/node-server-change-scope.mjs']
manifest = {'sourceSha': inputs['current']['commit'], 'sourceTreeGitOid': inputs['current']['tree'],
            'subjects': [{'file': path, 'originalAsset': 'original/' + path} for path in paths]}
sources = {path: {arm: (bundle / arm / path).read_bytes() for arm in ['original', 'candidate']} for path in paths}
require_owned_source_paths()
assert source_snapshot()['status'] == ''
assert all((root / path).read_bytes() == arms['original'] for path, arms in sources.items())
try:
    require_owned_source_paths()
    for path, arms in sources.items():
        (root / path).write_bytes(arms['candidate'])
    command = ['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts', 'config/scripts/node-server-change-scope.test.mjs',
               'config/scripts/ci-background-step-barriers.test.mjs', '--reporter=json', '--outputFile=' + str(out / 'vitest.json')]
    status, wall, timeout = invoke(command, {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1'}, out / 'vitest.log', 180)
    write_json(out / 'invocation.json', {'command': command, 'status': status, 'wallSeconds': wall, 'timedOut': timeout})
    assert status == 0 and not timeout
    report = json.loads((out / 'vitest.json').read_text())
    assert report['success'] and report['numFailedTests'] == 0
finally:
    restore_owned_sources()
final = source_snapshot()
assert final['head'] == manifest['sourceSha'] and final['tree'] == manifest['sourceTreeGitOid'] and final['status'] == ''
write_json(out / 'final-source.json', final)
