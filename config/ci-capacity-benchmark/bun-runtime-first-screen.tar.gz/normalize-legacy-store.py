import json
import os
from pathlib import Path
import subprocess
import time

source = Path(os.environ['SCREEN_SOURCE_ROOT'])
temporary = Path(os.environ['RUNNER_TEMP'])
worktree = temporary / 'bun-runtime-store-normalization'
output = Path(os.environ['SCREEN_RESULTS']) / 'legacy-store-normalization'
output.mkdir(exist_ok=False)
legacy_sha = 'f4092c06d639ee13ad446261dcabc78b27a21fbc'
legacy_tree = 'e11c31b0bce8ae903fc8e46ea2efdb5d6038350d'
record = {'runId': os.environ['GITHUB_RUN_ID'], 'runAttempt': os.environ['GITHUB_RUN_ATTEMPT'],
          'sourceSha': legacy_sha, 'sourceTree': legacy_tree,
          'policy': 'warm default-store complete-producer screen; not cold-install CI proof',
          'worktree': str(worktree), 'startedUnixMs': int(time.time() * 1000),
          'startedMonotonicNs': time.monotonic_ns(), 'commands': []}
created = False


def command(arguments, name, capture=False):
    record['commands'].append(arguments)
    with (output / name).open('w') as stream:
        completed = subprocess.run(arguments, cwd=source, stdout=stream, stderr=subprocess.STDOUT)
    if completed.returncode:
        raise RuntimeError(f'{name}: exit {completed.returncode}; see preserved raw log')
    return (output / name).read_text().strip() if capture else None


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=worktree, text=True).strip()


def require_owned_source():
    assert worktree.is_dir() and not worktree.is_symlink(), 'Unknown normalization path retained'
    assert git('rev-parse', 'HEAD') == legacy_sha, 'Changed normalization HEAD retained'
    assert git('rev-parse', 'HEAD^{tree}') == legacy_tree, 'Changed normalization tree retained'
    assert git('status', '--porcelain', '--untracked-files=all') == '', 'Changed normalization inputs retained'


try:
    assert not worktree.exists() and not worktree.is_symlink()
    record['invokingPnpmVersion'] = command(['pnpm', '--version'], 'invoking-pnpm-version.txt', True)
    command(['git', 'worktree', 'add', '--detach', str(worktree), legacy_sha], 'worktree-add.log')
    created = True
    require_owned_source()
    assert not (worktree / 'out').exists() and not (worktree / 'out').is_symlink()
    record['packageManager'] = json.loads((worktree / 'package.json').read_text())['packageManager']
    record['installStartedUnixMs'] = int(time.time() * 1000)
    record['installStartedMonotonicNs'] = time.monotonic_ns()
    command(['pnpm', '--dir', str(worktree), 'install', '--frozen-lockfile', '--ignore-scripts'], 'install.log')
    record['installEndedUnixMs'] = int(time.time() * 1000)
    record['installEndedMonotonicNs'] = time.monotonic_ns()
    record['delegatedPnpmVersion'] = command(['pnpm', '--dir', str(worktree), '--version'], 'delegated-pnpm-version.txt', True)
    record['storePath'] = command(['pnpm', '--dir', str(worktree), 'store', 'path', '--silent'], 'legacy-store-path.txt', True)
    record['storeDirConfiguration'] = command(['pnpm', '--dir', str(worktree), 'config', 'get', 'store-dir'], 'legacy-store-config.txt', True)
    assert record['delegatedPnpmVersion'] == record['packageManager'].split('@')[1].split('+')[0]
    assert record['storePath'], 'No delegated store path recorded'
    require_owned_source()
    assert not (worktree / 'out').exists() and not (worktree / 'out').is_symlink(), 'Unexpected build/runtime output retained'
    record['qualified'] = True
except BaseException as error:
    record['qualified'] = False
    record['error'] = repr(error)
    raise
finally:
    try:
        if created:
            require_owned_source()
            command(['git', 'worktree', 'remove', '--force', str(worktree)], 'worktree-remove.log')
        assert not worktree.exists() and not worktree.is_symlink()
        record['worktreeAndOwnedOutputsRemoved'] = True
    except BaseException as error:
        record['qualified'] = False
        record['cleanupError'] = repr(error)
        raise
    finally:
        record['endedUnixMs'] = int(time.time() * 1000)
        record['endedMonotonicNs'] = time.monotonic_ns()
        record['setupMilliseconds'] = (record['endedMonotonicNs'] - record['startedMonotonicNs']) / 1e6
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
