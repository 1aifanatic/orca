from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
bundle, root, out = Path(__file__).resolve().parent, Path.cwd(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
test = Path('src/main/window/attach-main-window-services.test.ts')
fixture = Path('src/main/window/main-window-service-stubs.test-fixture.ts')
production = Path('src/main/window/attach-main-window-services.ts')
manifest = json.loads((bundle / 'manifest.json').read_text())
for filename, expected in manifest.items():
    if hashlib.sha256((bundle / filename).read_bytes()).hexdigest() != expected:
        raise RuntimeError(f'Frozen input changed: {filename}')
candidate = (bundle / 'candidate.source').read_text()
names = json.loads((bundle / 'case-names.json').read_text())
fixture_source = (bundle / 'fixture-candidate.source').read_text()
original = (bundle / 'production-original.source').read_text()
if (root / fixture).read_text() != fixture_source or (root / test).read_text() != candidate:
    raise RuntimeError('Candidate test/stubs differ from frozen source')
if (root / production).read_text() != original:
    raise RuntimeError('Production differs from frozen source')
restore = (root / test).read_bytes()
selected = 'gives host-local catalog notifiers the runtime'
mutants = [
    ('ssh-registration-omitted', [('  registerSshHandlers(store, () => mainWindow, runtime)', '')], 'to be called once'),
    ('ssh-wrong-store', [('registerSshHandlers(store, () => mainWindow, runtime)', 'registerSshHandlers(null, () => mainWindow, runtime)')], 'to be called once'),
    ('ssh-wrong-window', [('registerSshHandlers(store, () => mainWindow, runtime)', 'registerSshHandlers(store, () => null, runtime)')], 'to be'),
    ('ssh-wrong-runtime', [('registerSshHandlers(store, () => mainWindow, runtime)', 'registerSshHandlers(store, () => mainWindow, undefined)')], 'to be called once'),
    ('remote-registration-omitted', [('  registerRemoteWorkspaceHandlers(store, () => mainWindow, runtime)', '')], 'to be called once'),
    ('remote-wrong-window', [('registerRemoteWorkspaceHandlers(store, () => mainWindow, runtime)', 'registerRemoteWorkspaceHandlers(store, () => null, runtime)')], 'to be'),
    ('daemon-registration-before-pty', [('  registerDaemonManagementHandlers()', ''), ('  registerPtyHandlers(\n', '  registerDaemonManagementHandlers()\n  registerPtyHandlers(\n')], 'to have been called after'),
    ('cleanup-wrong-store', [('registerWorkspaceCleanupHandlers(store)', 'registerWorkspaceCleanupHandlers(null)')], 'to be called once'),
    ('folder-watch-wrong-window', [('startFolderRepoGitUpgradeWatch(store, mainWindow)', 'startFolderRepoGitUpgradeWatch(store, null)')], 'to be called once')
]
env = {**os.environ, 'ORCA_BACKGROUND_LAUNCH': '1', 'NODE_DISABLE_COMPILE_CACHE': '1',
       'ORCA_ATTACH_MUTANT_IMPORTED': '0'}
rows = []
try:
    for label, replacements, expected in mutants:
        mutated = original
        for pattern, replacement in replacements:
            if mutated.count(pattern) != 1:
                raise RuntimeError(f'Changed mutation site: {pattern}')
            mutated = mutated.replace(pattern, replacement)
        mutated = re.sub(r"from (['\"])(\.[^'\"]+)\1",
                         lambda match: 'from ' + json.dumps((root / production.parent / match.group(2)).resolve().as_posix()),
                         mutated)
        mutated += "\nprocess.env.ORCA_ATTACH_MUTANT_IMPORTED = '1'\n"
        module_file = out / f'{label}.ts'
        module_file.write_text(mutated)
        config = out / f'{label}.config.ts'
        config.write_text('import base from ' + json.dumps((root / 'config/vitest.config.ts').as_posix()) +
                          '\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*attach-main-window-services$/, replacement: ' +
                          json.dumps(module_file.as_posix()) +
                          ' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
        source = candidate.replace('import { beforeEach,', 'import { afterAll, beforeEach,')
        source += "\nafterAll(() => expect(process.env.ORCA_ATTACH_MUTANT_IMPORTED).toBe('1'))\n"
        (root / test).write_text(source)
        target = out / f'{label}.json'
        started = time.perf_counter()
        with (out / f'{label}.log').open('w') as log:
            proc = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(test),
                                   '--maxWorkers=1', '--experimental.fsModuleCache=false',
                                   '--testNamePattern', selected, '--reporter=json', f'--outputFile={target}'],
                                  cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
        report = json.loads(target.read_text())
        cases = [case for suite in report['testResults'] for case in suite['assertionResults']]
        failed = [case for case in cases if case['status'] == 'failed']
        if sorted(case['fullName'] for case in cases) != names or proc.returncode != 1 or \
                report['numPassedTests'] != 0 or report['numFailedTests'] != 1 or \
                report['numPendingTests'] != 30 or len(failed) != 1 or failed[0]['title'] != selected or \
                expected not in failed[0]['failureMessages'][0]:
            raise RuntimeError(f'{label} failed at an unexpected oracle; inspect {target}')
        row = {'mutation': label, 'productionSha256': hashlib.sha256(mutated.encode()).hexdigest(),
               'testSha256': hashlib.sha256(source.encode()).hexdigest(),
               'fixtureSha256': manifest['fixture-candidate.source'],
               'processWallSeconds': time.perf_counter() - started, 'bodyMs': failed[0].get('duration', 0),
               'failed': 1, 'pending': 30, 'failure': failed[0]['failureMessages'][0].split('\n')[0]}
        rows.append(row)
        print(json.dumps(row), flush=True)
        (root / test).write_bytes(restore)
finally:
    (root / test).write_bytes(restore)
    if (root / test).read_bytes() != restore or (root / fixture).read_text() != fixture_source:
        raise RuntimeError('Test/fixture restoration failed')
    if (root / production).read_text() != original:
        raise RuntimeError('Production changed during controls')
(out / 'summary.json').write_text(json.dumps(rows, indent=2))
