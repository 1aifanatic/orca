from pathlib import Path
import json
import os
import re
import subprocess
import tempfile

root = Path.cwd()
scratch = Path(tempfile.mkdtemp(prefix='orca-status-store-controls-'))
results = []


def standalone(source):
    return re.sub(r"from '(\./[^']+)'", lambda match: f"from '{root / 'src/shared' / match[1][2:]}'", source)


mutation = standalone((root / 'src/shared/agent-status-store-mutation.ts').read_text())
state = standalone((root / 'src/shared/agent-status-store-state.ts').read_text())
age = 'state.revision - tombstone.revision < AGENT_STATUS_STORE_TOMBSTONE_RETENTION_REVISIONS'
count = 'state.tombstones.size <= AGENT_STATUS_STORE_LIMITS.tombstones'
children = 'children: [...state.children.values()],'
controls = [
    ('age-early', 'agent-status-store-mutation', mutation.replace(age, age + ' - 1'), 'retention revision boundary'),
    ('age-late', 'agent-status-store-mutation', mutation.replace(age, age.replace(' < ', ' <= ')), 'retention revision boundary'),
    ('age-disabled', 'agent-status-store-mutation', mutation.replace(age, 'true'), 'retention revision boundary'),
    ('overflow-disabled', 'agent-status-store-mutation', mutation.replace(count, 'true'), 'count overflows'),
    ('snapshot-description', 'agent-status-store-state', state.replace(children, '''children: [...state.children.values()].map((record) => {
      const corrupted = { ...record }
      delete corrupted.description
      return corrupted
    }),'''), r'decision for decision \(seed 1\)'),
]
for name, module, source, pattern in controls:
    original = mutation if module == 'agent-status-store-mutation' else state
    assert source != original, f'{name} replacement did not apply'
    mutant = scratch / f'{name}.ts'
    mutant.write_text(source)
    config = scratch / f'vitest-{name}.config.ts'
    config.write_text(f"import {{ mergeConfig }} from '{root}/node_modules/vitest/dist/config.js'\nimport base from '{root}/config/vitest.config.ts'\nexport default mergeConfig(base, {{resolve: {{alias: [{{find: './{module}', replacement: '{mutant}'}}]}}}})\n")
    report = scratch / f'{name}.json'
    with (scratch / f'{name}.log').open('w') as log:
        completed = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', str(config), 'src/shared/agent-status-store-in-place.test.ts', '--maxWorkers=1', f'--testNamePattern={pattern}', '--reporter=json', f'--outputFile={report}'], cwd=root, env=dict(os.environ, ORCA_BACKGROUND_LAUNCH='1'), stdout=log, stderr=subprocess.STDOUT)
    parsed = json.loads(report.read_text())
    failures = [test for module in parsed['testResults'] for test in module['assertionResults'] if test['status'] == 'failed']
    assert completed.returncode == 1 and len(failures) == 1 and failures[0]['failureMessages'][0].startswith('AssertionError:'), f'{name} did not fail at its expected assertion; see {log.name}'
    results.append({'control': name, 'failedTest': failures[0]['title'], 'failure': failures[0]['failureMessages'][0].split('\n')[0]})
    print(json.dumps(results[-1]), flush=True)
(scratch / 'summary.json').write_text(json.dumps(results, indent=2) + '\n')
print(f'Control reports: {scratch}', flush=True)
