from pathlib import Path
import json
import os
import re
import subprocess

root = Path.cwd()
support = Path(__file__).resolve().parent
target = root / 'src/main/runtime/rpc/terminal-output-frame-chunks-equivalence.test.ts'
production = target.with_name('terminal-output-frame-chunks.ts')
original = (support / target.name).read_text()
candidate = target.read_bytes()


def standalone(source):
    return re.sub(r"from '(\.[^']+)'", lambda match: f"from '{(production.parent / match[1]).resolve().as_posix()}'", source)


prefix = original[:original.index('type FrameSummary')].replace("import { describe, expect, it } from 'vitest'\n", '')
reference = standalone(prefix) + "\nexport { legacyIterateTerminalOutputFrameChunks as iterateTerminalOutputFrameChunks, exceedsTerminalStreamChunkBytes, TERMINAL_STREAM_BYTE_PROBE_CODE_UNITS }\n"
body = standalone(production.read_text())
controls = [
    ('original-oracle', reference, '', True, False),
    ('seq-offset', body.replace('startSeq! + chunkStart + text.length', 'startSeq! + chunkStart + text.length + 1'), 'matches across 1B', False, False),
    ('surrogate-width', body.replace('width = 2', 'width = 1'), 'sweeps a chunk boundary across a surrogate pair', False, False),
    ('byte-width', body.replace('let partBytes = 3', 'let partBytes = 1'), 'matches on multi-byte-only', False, False),
    ('span-transform', body.replace('transformed: true', 'transformed: false'), 'matches on the small/no-chunking sizes', False, False),
    ('removed-algebra', f"export {{ exceedsTerminalStreamChunkBytes, TERMINAL_STREAM_BYTE_PROBE_CODE_UNITS }} from '{production.as_posix()}'\nexport function* iterateTerminalOutputFrameChunks() {{ throw new Error('Production generator cannot be used') }}\n", 'never reaches the delayed-final-seq', True, True),
    ('real-production-unusable', f"export {{ exceedsTerminalStreamChunkBytes, TERMINAL_STREAM_BYTE_PROBE_CODE_UNITS }} from '{production.as_posix()}'\nexport function* iterateTerminalOutputFrameChunks() {{ throw new Error('Production generator cannot be used') }}\n", 'matches on the small/no-chunking sizes', False, False),
]
results = []
try:
    for name, content, pattern, passes, use_original in controls:
        target.write_bytes(original.encode() if use_original else candidate)
        mutant = support / f'control-{name}.ts'
        mutant.write_text(content)
        config = support / f'control-{name}.config.ts'
        config.write_text(f"import {{ mergeConfig }} from '{root.as_posix()}/node_modules/vitest/dist/config.js'\nimport base from '{root.as_posix()}/config/vitest.config.ts'\nexport default mergeConfig(base, {{resolve: {{alias: [{{find: './terminal-output-frame-chunks', replacement: '{mutant.as_posix()}'}}]}}}})\n")
        report = support / f'control-{name}.json'
        args = ['pnpm', 'exec', 'vitest', 'run', '--config', str(config), str(target.relative_to(root)), '--maxWorkers=1', '--reporter=json', f'--outputFile={report}']
        if pattern:
            args.append(f'--testNamePattern={pattern}')
        with (support / f'control-{name}.log').open('w') as log:
            completed = subprocess.run(args, cwd=root, env=dict(os.environ, ORCA_BACKGROUND_LAUNCH='1'), stdout=log, stderr=subprocess.STDOUT)
        parsed = json.loads(report.read_text())
        failures = [test for module in parsed['testResults'] for test in module['assertionResults'] if test['status'] == 'failed']
        expected = completed.returncode == 0 and parsed['success'] if passes else completed.returncode == 1 and len(failures) == 1
        assert expected, f'{name} returned an unexpected result; see {log.name}'
        results.append({'control': name, 'success': parsed['success'], 'passedTests': parsed['numPassedTests'], 'failures': [test['title'] for test in failures]})
        print(json.dumps(results[-1]), flush=True)
finally:
    target.write_bytes(candidate)
(support / 'controls-summary.json').write_text(json.dumps(results, indent=2) + '\n')
