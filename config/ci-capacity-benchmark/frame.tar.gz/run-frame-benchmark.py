from pathlib import Path
import json
import os
import subprocess
import time

root = Path.cwd()
support = Path(__file__).resolve().parent
target = root / 'src/main/runtime/rpc/terminal-output-frame-chunks-equivalence.test.ts'
variants = {variant: {name: (support / (('candidate-' if variant == 'candidate' else '') + name)).read_bytes() for name in ['terminal-output-frame-chunks-equivalence.test.ts']} for variant in ['baseline', 'candidate']}
env = dict(os.environ, ORCA_BACKGROUND_LAUNCH='1')
records = []
try:
    for index, variant in enumerate(['baseline', 'candidate', 'candidate', 'baseline', 'baseline', 'candidate'], 2):
        for name, content in variants[variant].items():
            (target.parent / name).write_bytes(content)
        report = support / f'{variant}-{index}.json'
        with (support / f'{variant}-{index}.log').open('w') as log:
            start = time.monotonic()
            result = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts', str(target.relative_to(root)), '--maxWorkers=1', '--reporter=json', f'--outputFile={report}'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'{variant} {index} failed; see {log.name}')
        parsed = json.loads(report.read_text())
        records.append({'variant': variant, 'index': index, 'wallSeconds': time.monotonic() - start, 'moduleMs': sum(test['endTime'] - test['startTime'] for test in parsed['testResults']), 'assertions': parsed['numPassedTests']})
        (support / 'alternating-summary.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps(records[-1]), flush=True)
finally:
    for name, content in variants['candidate'].items():
        (target.parent / name).write_bytes(content)
