from pathlib import Path
import argparse, hashlib, json, os, statistics, subprocess, time
parser=argparse.ArgumentParser()
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
bundle=Path(__file__).resolve().parent; root=Path.cwd(); out=args.out.resolve(); out.mkdir(parents=True,exist_ok=True)
test=Path('src/main/ssh/ssh-relay-native-deps-install.test.ts'); production=Path('src/main/ssh/ssh-relay-deploy.ts')
manifest=json.loads((bundle/'manifest.json').read_text())
for name,digest in manifest.items():
 if hashlib.sha256((bundle/name).read_bytes()).hexdigest()!=digest: raise RuntimeError(f'Frozen source changed: {name}')
sources={mode:(bundle/f'{mode}.source').read_bytes() for mode in ['original','candidate']}
if (root/test).read_bytes()!=sources['candidate']:raise RuntimeError('Worktree differs from candidate')
original_production=(bundle/'production-original.source').read_bytes()
if (root/production).read_bytes()!=original_production:raise RuntimeError('Production differs from frozen source')
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1'}
rows=[]; expected=None
try:
 for index,mode in enumerate(['original','candidate','candidate','original','original','candidate']):
  (root/test).write_bytes(sources[mode]); report_path=out/f'{index}-{mode}.json'
  started=time.perf_counter()
  with (out/f'{index}-{mode}.log').open('w') as log:
   proc=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.config.ts',str(test),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json',f'--outputFile={report_path}'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  elapsed=time.perf_counter()-started; report=json.loads(report_path.read_text())
  cases=[case for suite in report['testResults'] for case in suite['assertionResults']]
  statuses={case['fullName']:case['status'] for case in cases}
  if proc.returncode or not report['success'] or report['numPassedTests']!=31 or report['numFailedTests'] or report['numPendingTests'] or len(cases)!=31 or len(statuses)!=31:raise RuntimeError(f'Changed verdict/census: {report_path}')
  if expected is None:expected=statuses
  if statuses!=expected:raise RuntimeError(f'Changed case identities/outcomes: {report_path}')
  row={'index':index,'mode':mode,'processWallSeconds':elapsed,'bodyMs':sum(case.get('duration',0) for case in cases),'passed':31,'sourceSha256':manifest[f'{mode}.source'],'caseStatuses':statuses}
  rows.append(row);print(json.dumps({key:value for key,value in row.items() if key!='caseStatuses'}),flush=True)
finally:
 (root/test).write_bytes(sources['candidate'])
 if (root/test).read_bytes()!=sources['candidate'] or (root/production).read_bytes()!=original_production:raise RuntimeError('Source restoration failed')
medians={mode:statistics.median(row['processWallSeconds'] for row in rows if row['mode']==mode) for mode in sources}
summary={'rows':rows,'medianSeconds':medians,'medianReductionPercent':100*(1-medians['candidate']/medians['original']),'caseStatuses':expected,'productionSha256':manifest['production-original.source']}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({'medianSeconds':medians,'medianReductionPercent':summary['medianReductionPercent']}),flush=True)
