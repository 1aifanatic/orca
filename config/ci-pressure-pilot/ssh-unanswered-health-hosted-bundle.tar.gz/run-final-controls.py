from pathlib import Path
import hashlib,json,os,re,subprocess,time
bundle=Path(__file__).resolve().parent;root=Path.cwd();out=bundle/'final-controls';out.mkdir(exist_ok=True)
test=Path('src/main/ssh/ssh-relay-native-deps-install.test.ts');production=Path('src/main/ssh/ssh-relay-deploy.ts')
candidate=(bundle/'final.source').read_text();original=(bundle/'original.source').read_text();source=(bundle/'production-original.source').read_text()
if (root/test).read_text()!=candidate or (root/production).read_text()!=source:raise RuntimeError('Frozen inputs differ')
selected='does not rewrite node_modules when the health probe never answered'
site="    return { status: 'unverifiable', missing: [] }\n  }\n}\n\nasync function repairInstalledNativeDeps"
assert source.count(site)==1
mutant=source.replace(site,"    return { status: 'blocked', missing: ['node-pty', '@parcel/watcher'] }\n  }\n}\n\nasync function repairInstalledNativeDeps")
mutant=re.sub(r"from (['\"])(\.[^'\"]+)\1",lambda match:'from '+json.dumps((root/production.parent/match.group(2)).resolve().as_posix()),mutant)
mutant += "\nprocess.env.ORCA_UNANSWERED_HEALTH_MUTANT_IMPORTED = '1'\n"
(out/'wrong-repair.ts').write_text(mutant)
(out/'wrong-repair.config.ts').write_text('import base from '+json.dumps((root/'config/vitest.config.ts').as_posix())+'\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*\\/ssh-relay-deploy$/, replacement: '+json.dumps((out/'wrong-repair.ts').as_posix())+' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
probe_start=source.index('async function probeRequiredNativeDeps(')
probe_body=source.index('  const escapedNode = shellEscape(nodePath)',probe_start)
skipped=source[:probe_body]+"  return { status: 'ok', missing: [] }\n"+source[probe_body:]
skipped=re.sub(r"from (['\"])(\.[^'\"]+)\1",lambda match:'from '+json.dumps((root/production.parent/match.group(2)).resolve().as_posix()),skipped)
skipped+="\nprocess.env.ORCA_UNANSWERED_HEALTH_MUTANT_IMPORTED = '1'\n"
(out/'skipped-probe.ts').write_text(skipped)
(out/'skipped-probe.config.ts').write_text('import base from '+json.dumps((root/'config/vitest.config.ts').as_posix())+'\nexport default { ...base, resolve: { ...base.resolve, alias: [{ find: /^.*\\/ssh-relay-deploy$/, replacement: '+json.dumps((out/'skipped-probe.ts').as_posix())+' }, ...Object.entries(base.resolve.alias).map(([find, replacement]) => ({ find, replacement }))] } }\n')
start=candidate.index("  it('"+selected);end=candidate.index("  it('lets a probe SSH-channel failure",start)
body=candidate[start:end];assert body.count("      'READY'")==1
no_ready=candidate[:start]+body.replace("      'READY'","      'WAITING'")+candidate[end:]
plans=[('healthy-final',candidate,'config/vitest.config.ts',True,None),('absent-ready-candidate',no_ready,'config/vitest.config.ts',False,'an unanswered health probe must still allow an intact relay to launch'),('wrong-repair-candidate',candidate,str(out/'wrong-repair.config.ts'),False,'expected true to be false'),('skipped-probe-original',original,str(out/'skipped-probe.config.ts'),True,None),('skipped-probe-candidate',candidate,str(out/'skipped-probe.config.ts'),False,'to have a length of 1')]
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_UNANSWERED_HEALTH_MUTANT_IMPORTED':'0'};rows=[]
try:
 for label,test_source,config,should_pass,expected_failure in plans:
  is_mutant=label.startswith(('wrong-repair','skipped-probe'))
  if is_mutant:
   test_source=test_source.replace('import { afterEach, beforeEach,','import { afterAll, afterEach, beforeEach,')
   test_source+="\nafterAll(() => expect(process.env.ORCA_UNANSWERED_HEALTH_MUTANT_IMPORTED).toBe('1'))\n"
  (root/test).write_text(test_source);report_path=out/f'{label}.json';started=time.perf_counter()
  with (out/f'{label}.log').open('w') as log:
   proc=subprocess.run(['pnpm','exec','vitest','run','--config',config,str(test),'--maxWorkers=1','--experimental.fsModuleCache=false','--testNamePattern',selected,'--reporter=json',f'--outputFile={report_path}'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  report=json.loads(report_path.read_text());cases=[case for suite in report['testResults'] for case in suite['assertionResults']];selected_case=[case for case in cases if case['title']==selected]
  if len(cases)!=31 or len(selected_case)!=1 or report['numPendingTests']!=30:raise RuntimeError(f'Unexpected census: {label}')
  observed=selected_case[0]
  if should_pass:
   if proc.returncode or not report['success'] or observed['status']!='passed' or report['numPassedTests']!=1 or report['numFailedTests']:raise RuntimeError(f'Positive control failed: {label}')
  else:
   if proc.returncode!=1 or report['success'] or observed['status']!='failed' or report['numFailedTests']!=1 or report['numPassedTests'] or expected_failure not in observed['failureMessages'][0]:raise RuntimeError(f'Unexpected failure oracle: {label}')
  row={'label':label,'passed':report['numPassedTests'],'failed':report['numFailedTests'],'pending':report['numPendingTests'],'processWallSeconds':time.perf_counter()-started,'testSha256':hashlib.sha256(test_source.encode()).hexdigest(),'productionSha256':hashlib.sha256((skipped if label.startswith('skipped-probe') else mutant if is_mutant else source).encode()).hexdigest(),'failure':observed.get('failureMessages',[])};rows.append(row);print(json.dumps({key:value for key,value in row.items() if key!='failure'}),flush=True)
  (root/test).write_text(candidate)
finally:
 (root/test).write_text(candidate)
 if (root/test).read_text()!=candidate or (root/production).read_text()!=source:raise RuntimeError('Source restoration failed')
(out/'summary.json').write_text(json.dumps(rows,indent=2))
