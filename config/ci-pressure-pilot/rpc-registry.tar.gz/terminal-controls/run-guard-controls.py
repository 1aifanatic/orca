from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);test=root/'src/main/runtime/rpc/terminal-subscribe-buffer.test.ts';fixture=root/'src/main/runtime/rpc/unused-default-rpc-methods.test-fixture.ts';restore=test.read_bytes();assert restore==(bundle/'candidate.source').read_bytes()
guards=json.loads((bundle/'source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
rows=[];env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_FIXTURE_IMPORTED':'0'}
try:
 for operation in ['clearAllMocks','resetAllMocks','unrelated-history']:
  for kind in (['spy-history-control','candidate-counter'] if operation!='unrelated-history' else ['candidate-counter']):
   source=(bundle/('fixture-spy-history-control.source' if kind=='spy-history-control' else 'fixture.source')).read_text()
   observer=("expect(unusedDefaultRpcMethods.iterate).not.toHaveBeenCalled()" if kind=='spy-history-control' else 'expect(unusedDefaultRpcMethods.consumption.count).toBe(0)')
   transformed=source+"\nimport {afterAll} from 'vitest'\nprocess.env.ORCA_FIXTURE_IMPORTED='1'\nafterAll(()=>{ "+observer+"; expect(vi.isFakeTimers()).toBe(false) })\n"
   module=out/f'{operation}-{kind}.source';module.write_text(transformed);config=out/f'{operation}-{kind}.config.ts';config.write_text('import base from '+json.dumps(str(root/'config/vitest.config.ts'))+'\nimport {readFileSync} from \'node:fs\'\nexport default {...base,plugins:[{name:\'guard-control\',enforce:\'pre\',transform(code,id){if(id.split(\'?\')[0]==='+json.dumps(str(fixture))+')return readFileSync('+json.dumps(str(module))+',\'utf8\')}}]}\n')
   footer="\nimport {afterEach,afterAll} from 'vitest'\nimport {ALL_RPC_METHODS} from './methods'\n"
   if operation=='unrelated-history':footer+="const unrelatedHistory=vi.fn()\nunrelatedHistory('kept')\nafterAll(()=>expect(unrelatedHistory).toHaveBeenCalledExactlyOnceWith('kept'))\n"
   else:footer+="afterEach(()=>{expect(()=>[...ALL_RPC_METHODS]).toThrow('Explicit-registry tests must not consume the default RPC manifest');vi."+operation+"()})\n"
   footer+="afterAll(()=>expect(process.env.ORCA_FIXTURE_IMPORTED).toBe('1'))\n";test.write_bytes(restore+footer.encode());report=out/f'{operation}-{kind}.json';started=time.perf_counter()
   with (out/f'{operation}-{kind}.log').open('x') as h:p=subprocess.run(['pnpm','exec','vitest','run','--config',str(config),str(test),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report),'--testNamePattern','marks scrollback-only subscribed previews truncated when the uncursored read is limited'],cwd=root,env=env,stdout=h,stderr=subprocess.STDOUT,timeout=90)
   d=json.loads(report.read_text());failed=[c for s in d['testResults'] for c in s['assertionResults'] if c['status']=='failed'];assert d['numTotalTests']==10 and d['numPendingTests']==9 and not any(s.get('message') for s in d['testResults']),report
   if operation=='unrelated-history' or kind=='spy-history-control':assert p.returncode==0 and d['success'] and d['numPassedTests']==1,report
   else:assert p.returncode==1 and len(failed)==1 and 'expected 1 to be +0' in '\n'.join(failed[0]['failureMessages']),report
   row={'operation':operation,'kind':kind,'fixtureSha256':hashlib.sha256(source.encode()).hexdigest(),'exitCode':p.returncode,'wallSeconds':time.perf_counter()-started,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests'],'failureMessages':failed[0]['failureMessages'] if failed else []};rows.append(row);print(json.dumps(row),flush=True)
finally:
 test.write_bytes(restore)
 for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
 assert test.read_bytes()==restore
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
