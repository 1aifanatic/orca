from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);test=root/'src/main/runtime/rpc/terminal-subscribe-buffer.test.ts';restore=test.read_bytes()
sources={kind:(bundle/f'{kind}.source').read_text() for kind in ['original','candidate']};assert restore.decode() in sources.values()
guards=json.loads((bundle/'source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
faults=[
 ('scrollback-incompleteness-lost','src/main/runtime/rpc/methods/terminal/terminal-subscribe-method.ts','truncated: isTerminalReadPayloadIncomplete(read)','truncated: false','marks scrollback-only subscribed previews truncated when the uncursored read is limited','to deeply equal'),
 ('binary-snapshot-false-truncation','src/main/runtime/rpc/methods/terminal/terminal-legacy-subscribe-snapshot.ts','truncated: initialOutputOverflowed,','truncated: isTerminalReadPayloadIncomplete(read),','does not mark binary snapshot frames truncated from an overflowed read when serialized data is available','to match object'),
 ('abort-listener-guard-lost','src/main/runtime/rpc/methods/terminal/terminal-legacy-simple-subscriptions.ts','  const serialized = await serializeBudgetedMobileSnapshot(runtime, ptyId, false)\n  if (registration.released) {\n    return\n  }','  const serialized = await serializeBudgetedMobileSnapshot(runtime, ptyId, false)','does not register legacy JSON listeners after the stream signal aborts during snapshot','to not be called at all'),
 ('default-registry-consumed','src/main/runtime/rpc/dispatcher.ts','this.registry = buildRegistry(methods)','this.registry = buildRegistry(ALL_RPC_METHODS)','marks scrollback-only subscribed previews truncated when the uncursored read is limited','Explicit-registry tests must not consume the default RPC manifest')
]
names=sorted('terminal subscribe buffering '+s for s in re.findall(r"^  it\('([^']+)'",sources['original'],re.M));assert len(names)==10
rows=[];env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_RPC_FAULT_IMPORTED':'0'}
try:
 for name,subject,pattern,replacement,title,diagnostic in faults:
  source=(root/subject).read_text();assert source.count(pattern)==1,(name,source.count(pattern));mutant=source.replace(pattern,replacement)+"\nprocess.env.ORCA_RPC_FAULT_IMPORTED = '1'\n";module=out/(name+'.source');module.write_text(mutant)
  fixture=root/'src/main/runtime/rpc/unused-default-rpc-methods.test-fixture.ts'
  observedFixture=out/(name+'.fixture.source');observedFixture.write_text((bundle/'fixture.source').read_text()+"\nimport { afterAll } from 'vitest'\nafterAll(() => expect(unusedDefaultRpcMethods.consumption.count).toBe(0))\n")
  config=out/(name+'.config.ts')
  config.write_text('import base from '+json.dumps(str(root/'config/vitest.config.ts'))+'\nimport {readFileSync} from \'node:fs\'\nexport default {...base,plugins:[{name:\'rpc-fault\',enforce:\'pre\',transform(code,id){const path=id.split(\'?\')[0];if(path==='+json.dumps(str(root/subject))+')return readFileSync('+json.dumps(str(module))+',\'utf8\');if(path==='+json.dumps(str(fixture))+')return readFileSync('+json.dumps(str(observedFixture))+',\'utf8\')}}]}\n')
  arms=[]
  for kind in ['original','candidate']:
   cleanup="\nimport { afterAll } from 'vitest'\nafterAll(() => {\n  expect(process.env.ORCA_RPC_FAULT_IMPORTED).toBe('1')\n  expect(vi.isFakeTimers()).toBe(false)\n"+"})\n"
   test.write_text(sources[kind]+cleanup);report=out/f'{name}-{kind}.json';start=time.perf_counter()
   with (out/f'{name}-{kind}.log').open('x') as h:p=subprocess.run(['pnpm','exec','vitest','run','--config',str(config),str(test),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report),'--testNamePattern',title],cwd=root,env=env,stdout=h,stderr=subprocess.STDOUT,timeout=90)
   d=json.loads(report.read_text());cases=[c for s in d['testResults'] for c in s['assertionResults']];failed=[c for c in cases if c['status']=='failed'];assert sorted(c['fullName'] for c in cases)==names and len(cases)==10,report
   if name=='default-registry-consumed' and kind=='original':assert p.returncode==0 and d['success'] and d['numPassedTests']==1 and d['numPendingTests']==9,report
   else:
    assert p.returncode==1 and len(failed)==1 and failed[0]['title']==title and diagnostic in '\n'.join(failed[0]['failureMessages']),report
    assert d['numPassedTests']==0 and d['numPendingTests']==9 and not any(s.get('message') for s in d['testResults']),report
   arms.append({'kind':kind,'exitCode':p.returncode,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests'],'wallSeconds':time.perf_counter()-start,'failureMessages':failed[0]['failureMessages'] if failed else []})
  row={'fault':name,'subject':subject,'productionSha256':hashlib.sha256(source.encode()).hexdigest(),'mutantSha256':hashlib.sha256(mutant.encode()).hexdigest(),'arms':arms};rows.append(row);print(json.dumps(row),flush=True)
finally:
 test.write_bytes(restore)
 for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
 assert test.read_bytes()==restore
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
