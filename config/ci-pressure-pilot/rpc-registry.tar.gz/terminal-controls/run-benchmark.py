from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);parser.add_argument('--screen',action='store_true');args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True);test=root/'src/main/runtime/rpc/terminal-subscribe-buffer.test.ts'
sources={mode:(bundle/f'{mode}.source').read_bytes() for mode in ['original','candidate']};restore=test.read_bytes();assert restore in sources.values()
guards=json.loads((bundle/'source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
names=sorted('terminal subscribe buffering '+s for s in re.findall(r"^  it\('([^']+)'",sources['original'].decode(),re.M));assert len(names)==10
rows=[];env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1'}
try:
 for index,mode in enumerate(['original','candidate'] if args.screen else ['original','candidate','candidate','original','original','candidate']):
  test.write_bytes(sources[mode]);report=out/f'{index}-{mode}.json';started=time.perf_counter()
  with (out/f'{index}-{mode}.log').open('x') as h:p=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.config.ts',str(test),'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report)],cwd=root,env=env,stdout=h,stderr=subprocess.STDOUT,timeout=180)
  wall=time.perf_counter()-started;d=json.loads(report.read_text());cases=[c for s in d['testResults'] for c in s['assertionResults']]
  assert p.returncode==0 and d['success'] and d['numTotalTests']==10 and d['numPassedTests']==10 and d['numPendingTests']==0 and d['numFailedTests']==0,report
  assert sorted(c['fullName'] for c in cases)==names and all(c['status']=='passed' for c in cases),report
  row={'mode':mode,'wallSeconds':wall,'testSha256':hashlib.sha256(sources[mode]).hexdigest(),'cases':sorted([c['fullName'],c['status']] for c in cases),'bodyMs':sum(c.get('duration',0) for c in cases)};rows.append(row);print(json.dumps(row),flush=True)
finally:
 test.write_bytes(restore)
 for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
 assert test.read_bytes()==restore
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
