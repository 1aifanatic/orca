import hashlib,json,os,shutil,signal,subprocess,sys,time
from pathlib import Path
b=Path(__file__).resolve().parent
out=b/'sigterm-control-final';out.mkdir(exist_ok=False)
root=out/'isolated-source';root.mkdir()
m=json.loads((b/'manifest.json').read_text());primary=Path.cwd()
for row in m['sources']:
 path=root/row['file'];path.parent.mkdir(parents=True,exist_ok=True)
 path.write_bytes((b/'candidates'/row['file']).read_bytes() if row['role']=='subject' else (primary/row['file']).read_bytes())
for file in list(m['productionSha256'])+[m['fixture']['file']]:
 path=root/file;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((primary/file).read_bytes())
starting={r['file']:(root/r['file']).read_bytes() for r in m['sources']}
shims=out/'control-bin';shims.mkdir()
pidfile=out/'owned-processes.json'
pnpm=shims/'pnpm';pnpm.write_text('#!'+sys.executable+'\nimport json,subprocess,sys,time\nfrom pathlib import Path\nif sys.argv[1:]==["--version"]:print("control-runtime");raise SystemExit(0)\nassert sys.argv[1:3]==["exec","vitest"]\nchild=subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"])\nPath('+repr(str(pidfile))+').write_text(json.dumps({"child":__import__("os").getpid(),"grandchild":child.pid}))\ntime.sleep(60)\n')
for command,value in [('git','f'*40),('node','control-runtime')]:
 path=shims/command;path.write_text('#!'+sys.executable+'\nprint('+repr(value)+')\n')
for p in shims.iterdir():p.chmod(0o755)
env=dict(os.environ,PATH=str(shims)+os.pathsep+os.environ['PATH'],ORCA_BACKGROUND_LAUNCH='1')
with (out/'driver.log').open('wb') as log:
 process=subprocess.Popen([sys.executable,str(b/'qualify.py'),'benchmark','--out',str(out/'driver-receipts')],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  deadline=time.monotonic()+5
  while not pidfile.exists() and time.monotonic()<deadline:
   assert process.poll() is None,(out/'driver.log').read_text()
   time.sleep(.01)
  assert pidfile.exists(),'Fake child did not start'
  pids=json.loads(pidfile.read_text());assert all(pid>0 for pid in pids.values())
  os.kill(process.pid,signal.SIGTERM)
  code=process.wait(timeout=10)
 finally:
  if process.poll() is None:process.kill();process.wait(timeout=5)
assert code!=0
summary=json.loads((out/'driver-receipts/summary.json').read_text())
assert not summary['qualified'] and summary['allStartingSourcesRestored'] and 'SIGTERM' in summary['error']
assert all((root/path).read_bytes()==data for path,data in starting.items())
def alive(pid):
 try:os.kill(pid,0);return True
 except ProcessLookupError:return False
wait_until=time.monotonic()+3
while any(alive(pid) for pid in pids.values()) and time.monotonic()<wait_until:time.sleep(.01)
assert not any(alive(pid) for pid in pids.values()),pids
receipt={'passed':True,'driverSha256':hashlib.sha256((b/'qualify.py').read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256((b/'manifest.json').read_bytes()).hexdigest(),'isolatedSourceFiles':len(starting),'allSourceBytesRestored':True,'actualOwnedChildAndGrandchildExited':True,'exitCode':code,'summarySha256':hashlib.sha256((out/'driver-receipts/summary.json').read_bytes()).hexdigest(),'scope':'Actual final driver SIGTERM handling with isolated source copies and deliberately held control command; no Vitest timing or production correctness claim','noPrimaryWrites':True,'backgroundLaunch':True}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
