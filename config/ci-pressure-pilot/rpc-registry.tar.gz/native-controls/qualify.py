import argparse
import hashlib
import json
import os
import platform
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path.cwd()
BUNDLE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['smoke', 'benchmark', 'controls'])
parser.add_argument('--out', type=Path)
args = parser.parse_args()
OUT = args.out.resolve() if args.out else BUNDLE / (args.mode + '-receipts')
OUT.mkdir(parents=True, exist_ok=True)
manifest = json.loads((BUNDLE / 'manifest.json').read_text())
subjects = [row for row in manifest['sources'] if row['role'] == 'subject']
catalogs = [row for row in manifest['sources'] if row['role'] == 'realCatalog']
fixture = ROOT / manifest['fixture']['file']
sources = {row['file']: {label: (BUNDLE / (label + 's') / row['file']).read_bytes()
                        for label in ['original', 'candidate']}
           for row in subjects}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    return sha(path.read_bytes())

def require_sources():
    for row in subjects:
        for label in ['original', 'candidate']:
            assert sha(sources[row['file']][label]) == row[label + 'Sha256']
        candidate_body = sources[row['file']]['candidate'].split(b'\n', 1)[1]
        adjustment = row.get('typeOnlyAdjustment')
        if adjustment:
            old_type = adjustment['originalReturnType'].encode()
            new_type = adjustment['candidateReturnType'].encode()
            anchor = adjustment['importInsertionAnchor'].encode()
            assert candidate_body.count(new_type) == candidate_body.count(anchor) == 1
            candidate_body = candidate_body.replace(new_type, old_type).replace(
                anchor, adjustment['removedTypeImport'].encode() + anchor)
        assert candidate_body == sources[row['file']]['original']
    for row in catalogs:
        assert file_sha(ROOT / row['file']) == row['sha256'], row['file']
    assert file_sha(fixture) == manifest['fixture']['sha256']
    for path, digest in manifest['productionSha256'].items():
        assert file_sha(ROOT / path) == digest, path

require_sources()
starting = {path: (ROOT / path).read_bytes() for path in sources}
assert all(data in sources[path].values() for path, data in starting.items()), 'Unexpected subject source; refusing to overwrite'
env = dict(os.environ, ORCA_BACKGROUND_LAUNCH='1', NODE_DISABLE_COMPILE_CACHE='1',
           ORCA_BALANCE_UNIT_SHARDS='0')

def stage(label):
    for path in sources:
        (ROOT / path).write_bytes(sources[path][label])

def invoke(name, files, config=None, selected=None, extra_env=None):
    require_sources()
    report_path, log_path = OUT / (name + '.json'), OUT / (name + '.log')
    command = ['pnpm', 'exec', 'vitest', 'run', '--config',
               str(config) if config else 'config/vitest.config.ts',
               '--maxWorkers=1', '--experimental.fsModuleCache=false',
               '--reporter=json', '--outputFile=' + str(report_path), *files]
    if selected:
        command.extend(['-t', selected])
    began = time.perf_counter()
    with log_path.open('wb') as log:
        process = subprocess.run(command, cwd=ROOT, env=dict(env, **(extra_env or {})),
                                 stdout=log, stderr=subprocess.STDOUT, timeout=300)
    elapsed = time.perf_counter() - began
    report = json.loads(report_path.read_text())
    suites = report['testResults']
    assert {os.path.relpath(suite['name'], ROOT) for suite in suites} == set(files)
    assert all(not suite.get('message', '') for suite in suites), suites
    ordered = {os.path.relpath(suite['name'], ROOT):
               [[case['fullName'], case['status']] for case in suite['assertionResults']]
               for suite in suites}
    failures = {os.path.relpath(suite['name'], ROOT):
                {case['fullName']: case['failureMessages'] for case in suite['assertionResults']
                 if case['status'] == 'failed'} for suite in suites}
    row = {'name': name, 'command': command, 'completeProcessSeconds': elapsed,
           'exitCode': process.returncode, 'reportSha256': file_sha(report_path),
           'logSha256': file_sha(log_path), 'orderedOutcomesByFile': dict(sorted(ordered.items())),
           'failureMessagesByFile': failures,
           'sourceSha256': {path: file_sha(ROOT / path) for path in files},
           'counts': {key: report[key] for key in
                      ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests']}}
    print(json.dumps({key: row[key] for key in
                     ['name', 'completeProcessSeconds', 'exitCode', 'counts']}), flush=True)
    require_sources()
    return row

def require_pass(row):
    assert row['exitCode'] == 0 and row['counts']['numFailedTests'] == 0
    assert row['counts']['numPendingTests'] == 0
    assert row['counts']['numTotalTests'] == row['counts']['numPassedTests'] > 0
    assert all(status == 'passed' for cases in row['orderedOutcomesByFile'].values()
               for _, status in cases)

rows = []
try:
    if args.mode in ['smoke', 'benchmark']:
        order = ['candidate'] if args.mode == 'smoke' else [
            'original', 'candidate', 'candidate', 'original', 'original', 'candidate']
        expected = None
        files = [row['file'] for row in subjects + catalogs]
        for index, label in enumerate(order):
            stage(label)
            row = invoke('pair-' + str(index) + '-' + label, files)
            require_pass(row)
            if expected is None:
                expected = row['orderedOutcomesByFile']
            assert row['orderedOutcomesByFile'] == expected
            rows.append(row)
        pairs = []
        if args.mode == 'benchmark':
            for offset in range(0, 6, 2):
                pair = rows[offset:offset + 2]
                old = next(r['completeProcessSeconds'] for r in pair if r['name'].endswith('original'))
                new = next(r['completeProcessSeconds'] for r in pair if r['name'].endswith('candidate'))
                pairs.append({'originalSeconds': old, 'candidateSeconds': new,
                              'savedSeconds': old - new, 'savedFraction': 1 - new / old})
        summary = {'order': order, 'rows': rows, 'pairs': pairs,
                   'allCompleteNamedOutcomesEqual': True,
                   'unchangedRealCatalogSubjectsInBothArms': [r['file'] for r in catalogs]}
        if pairs:
            old_median = statistics.median(p['originalSeconds'] for p in pairs)
            new_median = statistics.median(p['candidateSeconds'] for p in pairs)
            summary.update(originalMedianSeconds=old_median, candidateMedianSeconds=new_median,
                           differenceOfMediansSeconds=old_median - new_median,
                           pairedMedianSavedSeconds=statistics.median(p['savedSeconds'] for p in pairs),
                           pairedMedianSavedFraction=statistics.median(p['savedFraction'] for p in pairs))
    else:
        selected_file = 'src/main/runtime/runtime-file-path-existence.test.ts'
        selected_case = 'actual RPC dispatch resolves one folder owner and sends one provider batch for eight real files'
        token = 'methods: FILE_METHODS'
        for label in ['original', 'candidate']:
            stage(label)
            source = sources[selected_file][label].decode()
            assert source.count(token) == 1
            (ROOT / selected_file).write_text(source.replace(token, 'methods: undefined'))
            row = invoke('forced-default-consumption-' + label, [selected_file], selected=selected_case)
            failed = [(case, messages) for failures in row['failureMessagesByFile'].values()
                      for case, messages in failures.items()]
            if label == 'original':
                assert row['exitCode'] == 0 and not failed and row['counts']['numPassedTests'] == 1
            else:
                assert row['exitCode'] != 0 and row['counts']['numFailedTests'] == 1 and len(failed) == 1
                assert failed[0][0] == selected_case
                assert any('Explicit-registry tests must not consume the default RPC manifest' in m
                           for m in failed[0][1]), failed
            rows.append(row)
        catalog_file = 'src/main/runtime/rpc/methods/structured-agent-session.test.ts'
        catalog_case = 'registers every structured method on the runtime manifest'
        catalog_source = ROOT / 'src/main/runtime/rpc/methods/index.ts'
        token = '  ...STRUCTURED_AGENT_SESSION_METHODS,'
        assert catalog_source.read_text().count(token) == 1
        setup = OUT / 'catalog-import-control.setup.ts'
        setup.write_text("import { afterAll, expect } from 'vitest'\n"
                         "afterAll(() => { expect(process.env.ORCA_REAL_CATALOG_FAULT).toBe('loaded') })\n")
        config = OUT / 'catalog-missing-registration.config.ts'
        config.write_text(
            'import base from ' + json.dumps(str(ROOT / 'config/vitest.config.ts')) + '\n' +
            'export default {...base, test: {...base.test, setupFiles: [...base.test.setupFiles, ' +
            json.dumps(str(setup)) + ']}, plugins: [{name: "actual-catalog-missing-registration", enforce: "pre",' +
            ' transform(source, id) { if (id.split("?")[0].replaceAll("\\\\", "/") !== ' +
            json.dumps(str(catalog_source).replace('\\', '/')) + ') return null;' +
            ' if (source.split(' + json.dumps(token) + ').length !== 2) throw new Error("Unexpected catalog source");' +
            ' return {code: source.replace(' + json.dumps(token) + ', "") +' +
            json.dumps("\nprocess.env.ORCA_REAL_CATALOG_FAULT = 'loaded'\n") + ', map: null}; } }]}\n')
        for label in ['original', 'candidate']:
            stage(label)
            row = invoke('missing-actual-catalog-registration-' + label, [catalog_file],
                         config=config, selected=catalog_case,
                         extra_env={'ORCA_REAL_CATALOG_FAULT': 'not-imported'})
            failed = [(case, messages) for failures in row['failureMessagesByFile'].values()
                      for case, messages in failures.items()]
            assert row['exitCode'] != 0 and row['counts']['numFailedTests'] == 1 and len(failed) == 1
            assert failed[0][0].endswith(catalog_case)
            assert any('agentSession.rewind' in m and 'AssertionError' in m for m in failed[0][1]), failed
            row['actualCatalogImportProvenByPassingAfterAll'] = True
            row['unchangedCatalogTestSourceSha256'] = file_sha(ROOT / catalog_file)
            row['faultConfigSha256'] = file_sha(config)
            row['faultSetupSha256'] = file_sha(setup)
            rows.append(row)
        summary = {'rows': rows, 'explicitDefaultConsumptionOldPassesCandidateFails': True,
                   'actualMissingCatalogRegistrationDetectedInBothArms': True,
                   'catalogFaultImportAssertionPassedInBothArms': True}
finally:
    for path, source in starting.items():
        (ROOT / path).write_bytes(source)
    require_sources()

summary.update(platform=platform.platform(), processorCount=os.cpu_count(),
               source=manifest, maxWorkers=1, moduleCache=False, nodeCompileCache=False,
               backgroundLaunch=True, allStartingSourcesRestored=True,
               driverSha256=file_sha(Path(__file__)))
for name, command in [('nodeVersion', ['node', '--version']), ('pnpmVersion', ['pnpm', '--version'])]:
    summary[name] = subprocess.check_output(command, cwd=ROOT, text=True, timeout=20).strip()
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items()
                  if key.endswith('Seconds') or key.endswith('Fraction')}), flush=True)
