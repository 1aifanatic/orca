import argparse
import hashlib
import json
import os
import platform
import signal
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path.cwd()
BUNDLE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['verify', 'screen', 'benchmark'])
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
OUT = args.out.resolve()
OUT.mkdir(parents=True, exist_ok=False)
manifest = json.loads((BUNDLE / 'manifest.json').read_text())
subjects = [r for r in manifest['sources'] if r['role'] == 'subject']
catalogs = [r for r in manifest['sources'] if r['role'] == 'realCatalog']
files = [r['file'] for r in subjects + catalogs]
assert len(files) == len(set(files)) == manifest['expectedModuleCount']
assert manifest['maxWorkers'] == 4
sources = {r['file']: {label: (BUNDLE / (label + 's') / r['file']).read_bytes()
                      for label in ['original', 'candidate']} for r in subjects}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_sha(path):
    return sha(path.read_bytes())

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def require_sources(label=None):
    for row in subjects:
        path = row['file']
        for variant in ['original', 'candidate']:
            assert sha(sources[path][variant]) == row[variant + 'Sha256'], path
        expected = sources[path]['original']
        if path == 'src/main/runtime/structured-chat-coordinator-mail.test.ts':
            before = b"import type { RpcRequest } from './rpc/core'\n"
            assert expected.count(before) == 1
            expected = expected.replace(before, b'')
            before = b'): RpcRequest {'
            assert expected.count(before) == 1
            expected = expected.replace(before, b"): Parameters<RpcDispatcher['dispatch']>[0] {")
            assert row['typeOnlyAdjustment']['proofSha256'] == file_sha(BUNDLE / 'coordinator-final-type-only-proof.json')
            proof = json.loads((BUNDLE / 'coordinator-final-type-only-proof.json').read_text())
            assert proof['emittedRuntimeByteIdentical'] and proof['allMeaningfulTestBodiesByteUnchanged']
            assert proof['finalCandidateSha256'] == row['candidateSha256']
            assert proof['originalSha256'] == row['originalSha256']
        assert sources[path]['candidate'].split(b'\n', 1)[1] == expected, path
        if label:
            assert (ROOT / path).read_bytes() == sources[path][label], path
    for row in catalogs:
        assert file_sha(ROOT / row['file']) == row['sha256'], row['file']
    assert file_sha(ROOT / manifest['fixture']['file']) == manifest['fixture']['sha256']
    for path, digest in manifest['qualificationInputsSha256'].items():
        assert file_sha(BUNDLE / path) == digest, path
    for path, digest in manifest['productionSha256'].items():
        assert file_sha(ROOT / path) == digest, path

require_sources()
starting = {path: (ROOT / path).read_bytes() for path in sources}
assert all(data in sources[path].values() for path, data in starting.items()), 'Unexpected subject bytes; refusing overwrite'
if args.mode == 'verify':
    receipt = {'qualifiedStaticInputs': True, 'modules': len(files), 'cases': manifest['expectedCaseCount'],
               'manifestSha256': file_sha(BUNDLE / 'manifest.json'), 'driverSha256': file_sha(Path(__file__)),
               'sourceSha256': {path: sha(data) for path, data in starting.items()}, 'noPrimaryWrites': True}
    write_json(OUT / 'verify.json', receipt)
    print(json.dumps({key: receipt[key] for key in ['qualifiedStaticInputs', 'modules', 'cases', 'noPrimaryWrites']}))
    raise SystemExit(0)
started_metadata = {name: subprocess.check_output(command, cwd=ROOT, text=True, timeout=20).strip()
                    for name, command in [('head', ['git', 'rev-parse', 'HEAD']),
                                          ('tree', ['git', 'rev-parse', 'HEAD^{tree}']),
                                          ('nodeVersion', ['node', '--version']),
                                          ('pnpmVersion', ['pnpm', '--version'])]}
write_json(OUT / 'starting-source.json', {'metadata': started_metadata,
           'sourceSha256': {path: sha(data) for path, data in starting.items()},
           'manifestSha256': file_sha(BUNDLE / 'manifest.json'),
           'driverSha256': file_sha(Path(__file__))})
env = dict(os.environ, ORCA_BACKGROUND_LAUNCH='1', NODE_DISABLE_COMPILE_CACHE='1',
           ORCA_BALANCE_UNIT_SHARDS='0')

def stage(label):
    for path in sources:
        (ROOT / path).write_bytes(sources[path][label])
    require_sources(label)

def handle_sigterm(signum, frame):
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    raise InterruptedError('SIGTERM: restoring owned sources and stopping owned process group')

signal.signal(signal.SIGTERM, handle_sigterm)

def run_process(command, log):
    creation = {'creationflags': subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == 'nt' else {'start_new_session': True}
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, **creation)
    try:
        return process.wait(timeout=1800)
    except BaseException:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], stdout=log, stderr=subprocess.STDOUT, timeout=30)
        else:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                pass
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.wait(timeout=30)
        raise

def invoke(index, label):
    require_sources(label)
    name = f'pair-{index}-{label}'
    report_path, log_path = OUT / (name + '.json'), OUT / (name + '.log')
    command = ['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
               '--maxWorkers=' + str(manifest['maxWorkers']), '--experimental.fsModuleCache=false',
               '--reporter=json', '--outputFile=' + str(report_path), *files]
    began = time.perf_counter()
    print(json.dumps({'started': name, 'files': len(files), 'maxWorkers': manifest['maxWorkers']}), flush=True)
    with log_path.open('wb') as log:
        exit_code = run_process(command, log)
    elapsed = time.perf_counter() - began
    report = json.loads(report_path.read_text())
    suites = report['testResults']
    ledger = {os.path.relpath(suite['name'], ROOT):
              [[case['fullName'], case['status']] for case in suite['assertionResults']]
              for suite in suites}
    assert len(ledger) == len(suites), 'Duplicated report modules'
    assert set(ledger) == set(files), {'missing': sorted(set(files)-set(ledger)), 'extra': sorted(set(ledger)-set(files))}
    assert sum(len(cases) for cases in ledger.values()) == manifest['expectedCaseCount']
    assert {path: sorted(name for name, _ in cases) for path, cases in ledger.items()} == manifest['expectedCaseNamesByFile'], 'Case name or multiplicity differs from frozen source-qualified census'
    qualified_outcomes = {path: [[name, status] for name, status in cases] for path, cases in ledger.items()}
    for variable in manifest['setupDependentCaseOutcomes']:
        matched = [case for case in qualified_outcomes[variable['file']] if case[0] == variable['fullName']]
        assert len(matched) == 1 and matched[0][1] in variable['allowedStatuses']
        matched[0][1] = variable['localStatus']
    assert {path: sorted(cases) for path, cases in qualified_outcomes.items()} == manifest['expectedLocalOutcomesByFile'], 'A frozen source-qualified case status changed'
    messages = {os.path.relpath(s['name'], ROOT): s.get('message', '') for s in suites if s.get('message', '')}
    failures = {os.path.relpath(suite['name'], ROOT):
                {case['fullName']: case['failureMessages'] for case in suite['assertionResults']
                 if case['status'] == 'failed'} for suite in suites}
    row = {'name': name, 'label': label, 'command': command, 'completeProcessSeconds': elapsed,
           'exitCode': exit_code, 'reportSuccess': report['success'],
           'reportSha256': file_sha(report_path), 'logSha256': file_sha(log_path),
           'orderedOutcomesByFile': dict(sorted(ledger.items())), 'suiteMessages': messages,
           'failureMessagesByFile': {path: value for path, value in failures.items() if value},
           'sourceSha256': {path: file_sha(ROOT / path) for path in files},
           'counts': {key: report[key] for key in ['numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests']}}
    write_json(OUT / (name + '-record.json'), row)
    print(json.dumps({key: row[key] for key in ['name', 'completeProcessSeconds', 'exitCode', 'counts']}), flush=True)
    require_sources(label)
    return row

def require_healthy(row):
    assert row['exitCode'] == 0 and row['reportSuccess'] and not row['suiteMessages'], row['name']
    assert row['counts']['numFailedTests'] == 0
    assert row['counts']['numTotalTests'] == row['counts']['numPassedTests'] + row['counts']['numPendingTests'] > 0
    assert all(status in ['passed', 'pending', 'skipped'] for cases in row['orderedOutcomesByFile'].values() for _, status in cases)

rows = []
summary = {'qualified': False, 'mode': args.mode, 'source': manifest, 'metadata': started_metadata,
           'maxWorkers': manifest['maxWorkers'], 'moduleCache': False, 'nodeCompileCache': False,
           'backgroundLaunch': True, 'allStartingSourcesRestored': False}
order = ['original', 'candidate'] if args.mode == 'screen' else ['original', 'candidate', 'candidate', 'original', 'original', 'candidate']
summary['order'] = order
try:
    expected = None
    for index, label in enumerate(order):
        stage(label)
        row = invoke(index, label)
        rows.append(row)
        summary['rows'] = rows
        write_json(OUT / 'summary.json', summary)
        require_healthy(row)
        if expected is None:
            expected = row['orderedOutcomesByFile']
        assert row['orderedOutcomesByFile'] == expected, 'Complete named outcomes changed'
    pairs = []
    for offset in range(0, len(rows), 2):
        pair = rows[offset:offset + 2]
        old = next(r['completeProcessSeconds'] for r in pair if r['label'] == 'original')
        new = next(r['completeProcessSeconds'] for r in pair if r['label'] == 'candidate')
        pairs.append({'originalSeconds': old, 'candidateSeconds': new, 'savedSeconds': old-new, 'savedFraction': 1-new/old})
    summary.update(qualified=True, completeNamedOutcomesEqual=True, pairs=pairs,
                   unchangedRealCatalogSubjectsInBothArms=[r['file'] for r in catalogs],
                   originalMedianSeconds=statistics.median(p['originalSeconds'] for p in pairs),
                   candidateMedianSeconds=statistics.median(p['candidateSeconds'] for p in pairs),
                   pairedMedianSavedSeconds=statistics.median(p['savedSeconds'] for p in pairs),
                   pairedMedianSavedFraction=statistics.median(p['savedFraction'] for p in pairs))
except BaseException as error:
    summary['error'] = repr(error)
    raise
finally:
    for path, data in starting.items():
        (ROOT / path).write_bytes(data)
    require_sources()
    assert all((ROOT / path).read_bytes() == data for path, data in starting.items())
    summary.update(rows=rows, allStartingSourcesRestored=True, platform=platform.platform(), processorCount=os.cpu_count(),
                   endedHead=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip())
    write_json(OUT / 'summary.json', summary)
print(json.dumps({key: summary[key] for key in ['qualified', 'originalMedianSeconds', 'candidateMedianSeconds', 'pairedMedianSavedSeconds', 'pairedMedianSavedFraction']}), flush=True)
