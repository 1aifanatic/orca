Run from the prepared Orca checkout with Node 24 and installed native Node dependencies.
The driver checks the frozen original/final test and three production hashes before running.
It accepts only an exact original or final checkout and restores that starting source in finally.
Each invocation is a fresh pnpm/Vitest process with one worker, maxConcurrency=5,
ORCA_BACKGROUND_LAUNCH=1 and both module/Node compile caches disabled.

python3 "$pilot/qualify.py" benchmark --out "$pilot/benchmark-receipts"
python3 "$pilot/qualify.py" controls --out "$pilot/controls-receipts"

Benchmark runs original/final, final/original, original/final and requires all nine ordered
outcomes to match and all three hanging native cases to retain at least five seconds.
Receipts include complete process wall, module wall and case durations.
Controls alias actual frozen generated lsof source: parent-only kill, false-clean enumeration.
Each runs against both versions and requires the intended failure, actual mutant import,
raw probe/verdict evidence, and cleanup of traced processes/groups/directories/sockets.
A forced-Windows gate proves both versions skip all nine cases without launching native work.
Upload both output directories even if a qualification step fails.
