import argparse
import hashlib
import json
import os
import platform
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path.cwd()
BUNDLE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('mode', choices=['benchmark','controls'])
parser.add_argument('--out', type=Path)
args = parser.parse_args()
DIR = args.out.resolve() if args.out else BUNDLE / f'{args.mode}-receipts'
DIR.mkdir(parents=True, exist_ok=True)
TEST = ROOT / 'src/main/ssh/ssh-relay-incumbent-process.test.ts'
PROBE = ROOT / 'src/shared/child-process/posix-lsof-probe.ts'
manifest = json.loads((BUNDLE / 'manifest.json').read_text())
original = (BUNDLE / 'original.source').read_bytes()
candidate = (BUNDLE / 'candidate.source').read_bytes()

def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()

def digest_file(path):
    return digest_bytes(path.read_bytes())

def require_sources():
    assert digest_bytes(original) == manifest['originalSha256']
    assert digest_bytes(candidate) == manifest['candidateSha256']
    for path, expected in manifest['productionSha256'].items():
        assert digest_file(ROOT / path) == expected, path

require_sources()
starting_source = TEST.read_bytes()
assert starting_source in (original,candidate), 'Unexpected checkout source; do not overwrite it'
env = dict(os.environ, ORCA_BACKGROUND_LAUNCH='1', NODE_DISABLE_COMPILE_CACHE='1')
base_cmd = ['pnpm', 'exec', 'vitest', 'run', '--config', 'config/vitest.config.ts',
            str(TEST.relative_to(ROOT)), '--maxWorkers=1', '--maxConcurrency=5',
            '--experimental.fsModuleCache=false', '--reporter=json']

def invoke(name, config=None, selected=None, extra_env=None):
    output = DIR / f'{name}.json'
    log = DIR / f'{name}.log'
    cmd = list(base_cmd)
    if config:
        cmd[cmd.index('--config') + 1] = str(config)
    if selected:
        cmd.extend(['-t', selected])
    cmd.append(f'--outputFile={output}')
    invocation_env = dict(env, **(extra_env or {}))
    started = time.perf_counter()
    with log.open('wb') as stream:
        result = subprocess.run(cmd, cwd=ROOT, env=invocation_env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=120)
    elapsed = time.perf_counter() - started
    report = json.loads(output.read_text())
    assert len(report['testResults']) == 1, report
    suite = report['testResults'][0]
    cases = suite['assertionResults']
    row = {'name': name, 'command': cmd, 'completeProcessSeconds': elapsed,
           'exitCode': result.returncode, 'reportSha256': digest_file(output),
           'logSha256': digest_file(log), 'moduleSeconds': (suite['endTime'] - suite['startTime']) / 1000,
           'testSourceSha256': digest_file(TEST),
           'orderedOutcomes': [[case['fullName'], case['status']] for case in cases],
           'caseDurationsMs': {case['fullName']: case.get('duration') for case in cases},
           'failureMessages': {case['fullName']: case['failureMessages'] for case in cases if case['status'] == 'failed'},
           'suiteMessage': suite.get('message', ''),
           'counts': {key: report[key] for key in ('numTotalTests','numPassedTests','numFailedTests','numPendingTests')}}
    print(json.dumps({key:row[key] for key in ('name','completeProcessSeconds','moduleSeconds','exitCode','counts')}), flush=True)
    return row

rows = []
try:
    if args.mode == 'benchmark':
        expected = None
        for index, label in enumerate(['original','candidate','candidate','original','original','candidate']):
            TEST.write_bytes(original if label == 'original' else candidate)
            row = invoke(f'pair-{index}-{label}')
            assert row['exitCode'] == 0
            assert row['counts'] == {'numTotalTests':9,'numPassedTests':9,'numFailedTests':0,'numPendingTests':0}
            assert all(status == 'passed' for _, status in row['orderedOutcomes'])
            waits = {name:duration for name,duration in row['caseDurationsMs'].items()
                     if 'bounds hung lsof' in name or 'stops a hung lsof helper' in name or 'exec sleep 60' in name}
            assert len(waits) == 3 and all(duration >= 5000 for duration in waits.values()), waits
            row['nativeDeadlineDurationsMs'] = waits
            if expected is None:
                expected = row['orderedOutcomes']
            assert row['orderedOutcomes'] == expected
            rows.append(row)
        old = [row['completeProcessSeconds'] for row in rows if row['name'].endswith('original')]
        new = [row['completeProcessSeconds'] for row in rows if row['name'].endswith('candidate')]
        pairs = []
        for offset in range(0,6,2):
            pair = rows[offset:offset+2]
            o = next(row for row in pair if row['name'].endswith('original'))
            n = next(row for row in pair if row['name'].endswith('candidate'))
            pairs.append({'originalSeconds':o['completeProcessSeconds'],'candidateSeconds':n['completeProcessSeconds'],
                          'savedSeconds':o['completeProcessSeconds']-n['completeProcessSeconds'],
                          'savedFraction':1-n['completeProcessSeconds']/o['completeProcessSeconds']})
        summary = {'platform':platform.platform(),'python':platform.python_version(),'source':manifest,
                   'order':['original','candidate','candidate','original','original','candidate'],
                   'maxWorkers':1,'maxConcurrency':5,'moduleCache':False,'nodeCompileCache':False,
                   'backgroundLaunch':True,'rows':rows,'pairs':pairs,'allOrderedOutcomesEqual':True,
                   'originalMedianSeconds':statistics.median(old),'candidateMedianSeconds':statistics.median(new),
                   'medianSavedSeconds':statistics.median(old)-statistics.median(new),
                   'medianSavedFraction':1-statistics.median(new)/statistics.median(old),
                   'excludedScreen':'candidate-screen.json used describe.concurrent.skipIf, which resets Vitest concurrency'}
    else:
        probe = PROBE.read_text()
        kill = "try { process.kill(-child.pid, 'SIGKILL'); }"
        marker = "var marker = unconfirmed ? 'cleanup-unconfirmed' : (unavailable || stderrSeen ? 'unavailable' : 'lsof');"
        assert probe.count(kill) == 1 and probe.count(marker) == 1
        definitions = [
            ('parent-only-kill', probe.replace(kill,"try { process.kill(child.pid, 'SIGKILL'); }"),
             'stops a hung lsof helper as well as its parent',
             'Remote relay probe cleanup is unverifiable; refusing to race a replacement launch'),
            ('false-clean-enumeration', probe.replace(marker,"var marker = unconfirmed ? 'cleanup-unconfirmed' : 'lsof';"),
             'does not mistake diagnostic enumeration failure for proven absence',
             'AssertionError: expected')
        ]
        controls = []
        for name, module, selected, message in definitions:
            module_path = DIR / f'{name}.ts'
            module_path.write_text(module + f"\nprocess.env.ORCA_INCUMBENT_FAULT_MODULE = {json.dumps(name)}\n")
            config = DIR / f'{name}.config.ts'
            config.write_text("import base from " + json.dumps(str(ROOT / 'config/vitest.config.ts')) + "\n" +
                              "export default {...base, resolve: {...base.resolve, alias: [{find: /^.*\\/posix-lsof-probe(?:\\.ts)?$/, replacement: " + json.dumps(str(module_path)) + "}, ...Object.entries(base.resolve.alias).map(([find,replacement]) => ({find,replacement}))]}}\n")
            for label, source in [('original',original),('candidate',candidate)]:
                text = source.decode().replace("import { describe, expect, it, vi } from 'vitest'", "import { afterAll, describe, expect, it, vi } from 'vitest'")
                text += f"\nafterAll(() => {{ expect(process.env.ORCA_INCUMBENT_FAULT_MODULE).toBe({json.dumps(name)}) }})\n"
                trace_name = f'control-{name}-{label}'
                pid_trace, group_trace, path_trace, raw_probe_trace, verdict_trace = [DIR / f'{trace_name}.{suffix}' for suffix in ('pids','groups','paths','raw-probe.json','verdict.json')]
                for trace in (pid_trace,group_trace,path_trace,raw_probe_trace,verdict_trace):
                    trace.unlink(missing_ok=True)
                shim = '`#!/bin/sh\\n${script}`'
                traced_shim = '`#!/bin/sh\\necho $$ >> "$ORCA_INCUMBENT_FAULT_PID_TRACE"\\necho $$ >> "$ORCA_INCUMBENT_FAULT_GROUP_TRACE"\\necho "$FIXTURE_PID" >> "$ORCA_INCUMBENT_FAULT_PATH_TRACE"\\n${script}`'
                assert text.count(shim) == 1
                text = text.replace(shim,traced_shim)
                helper_pid = 'echo $! > "$FIXTURE_PID"\\nwait'
                assert text.count(helper_pid) == 1
                text = text.replace(helper_pid,'echo $! > "$FIXTURE_PID"\\necho $! >> "$ORCA_INCUMBENT_FAULT_PID_TRACE"\\nwait')
                parse = '    const verdict = parseRelayEndpointIncumbentProbe(socket, result.stdout)'
                assert text.count(parse) == 1
                text = text.replace(parse, "    if (process.env.ORCA_INCUMBENT_FAULT_RAW_TRACE) writeFileSync(process.env.ORCA_INCUMBENT_FAULT_RAW_TRACE, JSON.stringify(result))\n" + parse + "\n    if (process.env.ORCA_INCUMBENT_FAULT_VERDICT_TRACE) writeFileSync(process.env.ORCA_INCUMBENT_FAULT_VERDICT_TRACE, JSON.stringify(verdict))")
                TEST.write_text(text)
                row = invoke(trace_name, config=config, selected=selected,
                             extra_env={'ORCA_INCUMBENT_FAULT_MODULE':'not-imported',
                                        'ORCA_INCUMBENT_FAULT_PID_TRACE':str(pid_trace),
                                        'ORCA_INCUMBENT_FAULT_GROUP_TRACE':str(group_trace),
                                        'ORCA_INCUMBENT_FAULT_PATH_TRACE':str(path_trace),
                                        'ORCA_INCUMBENT_FAULT_RAW_TRACE':str(raw_probe_trace),
                                        'ORCA_INCUMBENT_FAULT_VERDICT_TRACE':str(verdict_trace)})
                recorded_pids = sorted({int(value) for value in pid_trace.read_text().splitlines()})
                recorded_groups = sorted({int(value) for value in group_trace.read_text().splitlines()})
                recorded_dirs = sorted({str(Path(value).parent) for value in path_trace.read_text().splitlines()})
                assert len(recorded_pids) == (2 if name == 'parent-only-kill' else 1)
                assert len(recorded_groups) == 1 and len(recorded_dirs) == 1
                pid_states = {}
                for pid in recorded_pids:
                    state = subprocess.run(['ps','-o','state=','-p',str(pid)],capture_output=True,text=True,timeout=5)
                    pid_states[str(pid)] = {'exitCode':state.returncode,'stdout':state.stdout.strip()}
                    assert (state.returncode == 1 and not state.stdout.strip()) or (state.returncode == 0 and state.stdout.strip().startswith('Z')), pid_states
                census = subprocess.run(['ps','-axo','pgid=,state='],capture_output=True,text=True,timeout=5)
                assert census.returncode == 0
                group_states = {str(group):[] for group in recorded_groups}
                for line in census.stdout.splitlines():
                    fields = line.split()
                    assert len(fields) == 2
                    if fields[0] in group_states:
                        group_states[fields[0]].append(fields[1])
                assert all(state.startswith('Z') for states in group_states.values() for state in states), group_states
                assert all(not Path(directory).exists() for directory in recorded_dirs)
                row['cleanupEvidence'] = {'recordedPids':recorded_pids,'pidStatesAfterInvocation':pid_states,
                                          'recordedProcessGroups':recorded_groups,'groupStatesAfterInvocation':group_states,
                                          'recordedFixtureDirectories':recorded_dirs,'allFixtureDirectoriesAndSocketsRemoved':True,
                                          'allFixtureProcessesAndGroupsNonExecuting':True,
                                          'traceSha256':{trace.name:digest_file(trace) for trace in (pid_trace,group_trace,path_trace)}}
                assert row['exitCode'] != 0
                assert row['counts'] == {'numTotalTests':9,'numPassedTests':0,'numFailedTests':1,'numPendingTests':8}
                assert not row['suiteMessage'], row['suiteMessage']
                assert len(row['failureMessages']) == 1
                failed_name, messages = next(iter(row['failureMessages'].items()))
                assert failed_name.endswith(selected)
                assert any(message in failure for failure in messages), row
                raw_probe = json.loads(raw_probe_trace.read_text())
                row['actualRawProbe'] = raw_probe
                row['rawProbeSha256'] = digest_file(raw_probe_trace)
                if name == 'false-clean-enumeration':
                    actual = json.loads(verdict_trace.read_text())
                    assert actual['verdict'] == 'exited' and actual['holdersEnumerable'] is True and actual['holders'] == [], actual
                    assert 'HOLDERS_SOURCE=lsof' in raw_probe['stdout']
                    assert any('unverifiable' in failure for failure in messages), row
                    row['actualWrongVerdict'] = actual
                    row['actualWrongVerdictSha256'] = digest_file(verdict_trace)
                else:
                    assert 'PROBE_CLEANUP=unconfirmed' in raw_probe['stdout']
                    assert not verdict_trace.exists()
                    row['refusedToProduceVerdictAfterUnconfirmedCleanup'] = True
                row['mutantModuleSha256'] = digest_file(module_path)
                row['configSha256'] = digest_file(config)
                row['actualMutantImportProvenByPassingAfterAll'] = True
                rows.append(row)
            controls.append({'name':name,'moduleSha256':digest_file(module_path),'selectedCase':selected,'expectedFailure':message})
        windows_rows = []
        for label, source in [('original',original),('candidate',candidate)]:
            text = source.decode()
            assert text.count("process.platform === 'win32'") == 1
            TEST.write_text(text.replace("process.platform === 'win32'", 'true'))
            row = invoke(f'control-forced-windows-skip-{label}')
            assert row['exitCode'] == 0
            assert row['counts'] == {'numTotalTests':9,'numPassedTests':0,'numFailedTests':0,'numPendingTests':9}
            assert not row['failureMessages'] and not row['suiteMessage']
            windows_rows.append(row)
            rows.append(row)
        assert windows_rows[0]['orderedOutcomes'] == windows_rows[1]['orderedOutcomes']
        summary = {'platform':platform.platform(),'source':manifest,'controls':controls,'rows':rows,
                   'allOldAndNewDefensesDetectedActualFaults':True,'allActualMutantImportAssertionsPassed':True,
                   'forcedWindowsGatePreservesAllNineSkips':True}
finally:
    TEST.write_bytes(starting_source)
    require_sources()
    assert digest_file(TEST) == digest_bytes(starting_source)

summary['startingSourceRestored'] = True
summary['startingSourceSha256'] = digest_bytes(starting_source)
summary['finalSourceSha256'] = digest_file(TEST)
summary['processorCount'] = os.cpu_count()
summary['nodeVersion'] = subprocess.check_output(['node','--version'],text=True).strip()
summary['pnpmVersion'] = subprocess.check_output(['pnpm','--version'],text=True).strip()
summary['vitestVersion'] = json.loads((ROOT / 'node_modules/vitest/package.json').read_text())['version']
summary['driverSha256'] = digest_file(Path(__file__))
summary['productionHashesUnchanged'] = True
(DIR / f'{args.mode}-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key:value for key,value in summary.items() if key not in ('rows','source')}, indent=2), flush=True)
