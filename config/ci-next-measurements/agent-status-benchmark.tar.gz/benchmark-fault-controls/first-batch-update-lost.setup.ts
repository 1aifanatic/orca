import { afterAll, expect } from "/Users/nwparker/orca/workspaces/orca/CI-Concurrency-2/node_modules/vitest/dist/index.js"
afterAll(() => expect(process.env.ORCA_BENCHMARK_FAULT_IMPORTED).toBe('1'))
