from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
guards=json.loads((bundle/'measurement-source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
report=out/'vitest.json';output=out/'diagnostic.json';env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_AGENT_STATUS_BENCH_OUTPUT':str(output)};start=time.perf_counter()
with (out/'vitest.log').open('x') as h:p=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.agent-status-benchmark.config.ts','--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report)],env=env,stdout=h,stderr=subprocess.STDOUT,timeout=90)
d=json.loads(report.read_text());a=json.loads((bundle/'original-diagnostic-output.json').read_text());b=json.loads(output.read_text())
def shape(x):return {k:shape(v) for k,v in x.items()} if isinstance(x,dict) else type(x).__name__
def counts(x):return {k:counts(v) for k,v in x.items() if not k.endswith('.ms')} if isinstance(x,dict) else x
assert p.returncode==0 and d['success'] and d['numPassedTests']==1 and d['numTotalTests']==1
assert [[c['fullName'],c['status']] for s in d['testResults'] for c in s['assertionResults']]==[['agent-status hot path benchmark reports routing, resolution and commit cost at 423 worktrees','passed']]
assert shape(a)==shape(b) and counts(a)==counts(b)
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
receipt={'exitCode':p.returncode,'wallSeconds':time.perf_counter()-start,'schemaEqual':True,'nonTimingCountsEqual':True,'counts':counts(b),'passed':1,'sourceSha256':guards['config/scripts/agent-status-hot-path-benchmark.ts']};(out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
