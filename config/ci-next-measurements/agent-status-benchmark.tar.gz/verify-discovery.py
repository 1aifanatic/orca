from pathlib import Path
import argparse,hashlib,json,subprocess
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
old=root/'config/scripts/agent-status-hot-path-benchmark.test.ts';assert not old.exists()
guards=json.loads((bundle/'measurement-source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
def discover():
 p=subprocess.run(['node','--input-type=module','-e',"import { discoverUnitFiles } from './config/scripts/ci-unit-files.mjs';console.log(JSON.stringify(discoverUnitFiles()))"],cwd=root,capture_output=True,text=True,check=True,timeout=30)
 return json.loads(p.stdout)
try:
 old.write_bytes((bundle/'benchmark-original.source').read_bytes());before=discover();old.unlink();after=discover()
finally:old.unlink(missing_ok=True)
removed=sorted(set(before)-set(after));added=sorted(set(after)-set(before))
assert removed==['config/scripts/agent-status-hot-path-benchmark.test.ts'] and not added
assert not any('agent-status-hot-path-benchmark' in f for f in after)
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
(out/'summary.json').write_text(json.dumps({'beforeCount':len(before),'afterCount':len(after),'removed':removed,'added':added,'manualExcluded':True},indent=2)+'\n')
