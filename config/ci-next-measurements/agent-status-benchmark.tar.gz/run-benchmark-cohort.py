from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
benchmark=root/'config/scripts/agent-status-hot-path-benchmark.test.ts';original=(bundle/'benchmark-original.source').read_bytes()
assert not benchmark.exists(), 'Diagnostic must have left ordinary discovery before measurement'
manual=root/'config/scripts/agent-status-hot-path-benchmark.ts';manual_before=manual.read_bytes()
files=['src/renderer/src/hooks/ipc-events/agent-status-pane-routing-index.test.ts','src/renderer/src/hooks/ipc-events/agent-status-pane-routing-index-retention.test.ts','src/renderer/src/store/slices/agent-status-batch.test.ts']
guards=json.loads((bundle/'measurement-source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
expected=json.loads((bundle/'case-ledger.json').read_text());rows=[];semantic_ledger=sorted(tuple(case) for file,cases in expected.items() if not file.endswith('agent-status-hot-path-benchmark.test.ts') for case in cases)
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1'}
try:
 for i,arm in enumerate(['original','candidate','candidate','original','original','candidate']):
  if arm=='original':benchmark.write_bytes(original)
  else:benchmark.unlink(missing_ok=True)
  selected=files+(['config/scripts/agent-status-hot-path-benchmark.test.ts'] if arm=='original' else [])
  report=out/(str(i)+'-'+arm+'.json');log=out/(str(i)+'-'+arm+'.log');start=time.perf_counter()
  with log.open('x') as h:process=subprocess.run(['pnpm','exec','vitest','run','--config','config/vitest.config.ts','--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report),*selected],cwd=root,env=env,stdout=h,stderr=subprocess.STDOUT,timeout=180)
  wall=time.perf_counter()-start;d=json.loads(report.read_text());assert process.returncode==0 and d['success'] and d['numFailedTests']==0 and d['numPendingTests']==0,report
  semantic=[];diagnostic=[]
  for suite in d['testResults']:
   entries=[(case['fullName'],case['status']) for case in suite['assertionResults']]
   if suite['name'].endswith('agent-status-hot-path-benchmark.test.ts'):diagnostic.extend(entries)
   else:semantic.extend(entries)
  semantic.sort()
  if semantic_ledger is None:semantic_ledger=semantic
  assert semantic==semantic_ledger and len(semantic)==15,report
  assert diagnostic==([('agent-status hot path benchmark reports routing, resolution and commit cost at 423 worktrees','passed')] if arm=='original' else []),report
  row={'arm':arm,'wallSeconds':wall,'passed':d['numPassedTests'],'semanticLedger':semantic,'diagnosticLedger':diagnostic,'bodyMs':sum(case.get('duration',0) for suite in d['testResults'] for case in suite['assertionResults'])};rows.append(row);print(json.dumps(row),flush=True)
finally:
 benchmark.unlink(missing_ok=True)
 assert manual.read_bytes()==manual_before
 for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
