from pathlib import Path
import argparse,json,os,subprocess,time,hashlib
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
root=Path.cwd();bundle=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
benchmark=Path('config/scripts/agent-status-hot-path-benchmark.test.ts');original=(bundle/'benchmark-original.source').read_bytes()
restore=(root/benchmark).read_bytes() if (root/benchmark).exists() else None
subjects=['src/renderer/src/hooks/ipc-events/agent-status-pane-routing-index.ts','src/renderer/src/store/slices/agent-status-live-actions.ts']
sources={p:(bundle/f'benchmark-subject-{i}.source').read_text() for i,p in enumerate(subjects)}
for p,s in sources.items():assert (root/p).read_text()==s,p
mutants=[
 ('routing-result-lost',subjects[0], '    exists: true,\n    title: paneTitle ?? tab.title,', '    exists: false,\n    title: \'lost\',', 'src/renderer/src/hooks/ipc-events/agent-status-pane-routing-index.test.ts', 'builds the ownership index once while the tab map stays identity-stable', 'expected false to be true'),
 ('routing-index-cache-disabled',subjects[0], 'const cached = indexesByLayout?.get(layoutsKey)', 'const cached = undefined', 'src/renderer/src/hooks/ipc-events/agent-status-pane-routing-index.test.ts', 'builds the ownership index once while the tab map stays identity-stable', 'expected 100 to be 1'),
 ('first-batch-update-lost',subjects[1], 'updates.map(transaction.apply)', 'updates.slice(1).map(transaction.apply)', 'src/renderer/src/store/slices/agent-status-batch.test.ts', 'matches sequential updates across repeated panes and provider-session records', 'to deeply equal')
]
expected=json.loads((bundle/'case-ledger.json').read_text())
guards=json.loads((bundle/'measurement-source-guards.json').read_text())
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
rows=[]
env={**os.environ,'ORCA_BACKGROUND_LAUNCH':'1','NODE_DISABLE_COMPILE_CACHE':'1','ORCA_BENCHMARK_FAULT_IMPORTED':'0'}
try:
 (root/benchmark).write_bytes(original)
 for name,subject,pattern,replacement,retained,title,message in mutants:
  assert sources[subject].count(pattern)==1,pattern
  mutated=sources[subject].replace(pattern,replacement)+"\nprocess.env.ORCA_BENCHMARK_FAULT_IMPORTED = '1'\n"
  module=out/(name+'.source');module.write_text(mutated)
  setup=out/(name+'.setup.ts');setup.write_text('import { afterAll, expect } from '+json.dumps(str(root/'node_modules/vitest/dist/index.js'))+"\nafterAll(() => expect(process.env.ORCA_BENCHMARK_FAULT_IMPORTED).toBe('1'))\n")
  config=out/(name+'.config.ts')
  config.write_text('import base from '+json.dumps(str(root/'config/vitest.config.ts'))+'\nimport { readFileSync } from \'node:fs\'\nexport default { ...base, plugins: [{ name: \'benchmark-fault\', enforce: \'pre\', transform(code, id) { if (id.split(\'?\')[0] === '+json.dumps(str(root/subject))+') return readFileSync('+json.dumps(str(module))+', \'utf8\') } }], test: { ...base.test, setupFiles: [...base.test.setupFiles, '+json.dumps(str(setup))+'] } }\n')
  arms=[]
  for kind,file,filter_name in [('original-diagnostic',str(benchmark),None),('retained-semantic',retained,title)]:
   report=out/(name+'-'+kind+'.json');log=out/(name+'-'+kind+'.log')
   cmd=['pnpm','exec','vitest','run','--config',str(config),file,'--maxWorkers=1','--experimental.fsModuleCache=false','--reporter=json','--outputFile='+str(report)]
   if filter_name:cmd+=['--testNamePattern',filter_name]
   start=time.perf_counter()
   with log.open('x') as h:p=subprocess.run(cmd,cwd=root,env=env,stdout=h,stderr=subprocess.STDOUT,timeout=90)
   d=json.loads(report.read_text());cases=[c for t in d['testResults'] for c in t['assertionResults']];failed=[c for c in cases if c['status']=='failed'];assert sorted(c['fullName'] for c in cases)==sorted(c[0] for c in expected[file]),report
   if kind=='original-diagnostic':assert p.returncode==0 and d['success'] and d['numPassedTests']==1 and d['numTotalTests']==1,report
   else:
    assert p.returncode==1 and len(failed)==1 and failed[0]['title']==title and message in '\n'.join(failed[0]['failureMessages']),report
    assert d['numPassedTests']==0 and d['numPendingTests']==len(expected[file])-1,report
    assert not any(t.get('message') for t in d['testResults']),report
   arm={'kind':kind,'exitCode':p.returncode,'passed':d['numPassedTests'],'failed':d['numFailedTests'],'pending':d['numPendingTests'],'wallSeconds':time.perf_counter()-start,'failureMessages':failed[0]['failureMessages'] if failed else []};arms.append(arm)
  row={'fault':name,'subject':subject,'frozenProductionSha256':hashlib.sha256(sources[subject].encode()).hexdigest(),'mutantSha256':hashlib.sha256(mutated.encode()).hexdigest(),'arms':arms};rows.append(row);print(json.dumps(row),flush=True)
finally:
 if restore is None:(root/benchmark).unlink(missing_ok=True)
 else:(root/benchmark).write_bytes(restore)
 for p,s in sources.items():assert (root/p).read_text()==s,p
for file,digest in guards.items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
