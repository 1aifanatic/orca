Run from the exact candidate repository checkout, with dependencies installed. The ordinary diagnostic test must be absent. These scripts do not change production files. Cohort and discovery scripts temporarily restore its frozen original bytes and remove them in finally; controls inject production faults through a temporary Vite pre-transform and verify the actual module was imported.

Commands, with a new output directory for each invocation:

- `python3 verify-discovery.py --out /tmp/benchmark-discovery`
- `python3 run-manual.py --out /tmp/benchmark-manual`
- `python3 run-benchmark-cohort.py --out /tmp/benchmark-cohort`
- `python3 run-benchmark-controls.py --out /tmp/benchmark-controls`

The complete cohort runs original/candidate/candidate/original/original/candidate as fresh one-worker Vitest processes with background launch and filesystem module cache disabled. Original has the diagnostic plus 15 existing semantic cases; candidate has the same 15 semantic cases. Frozen source hashes and exact names/outcomes are required. The manual check requires the original JSON shape and all nine non-timing counters.

Each of three controls runs the old diagnostic, which must pass, and a retained real semantic case, which must fail its intended assertion: lost routing result, disabled ownership-index memoization, or dropped first batch update. Retained suites are agent-status-pane-routing-index.test.ts, agent-status-pane-routing-index-retention.test.ts and agent-status-batch.test.ts; none is changed.

`qualification.json` records local screening only. Whole-shard runtime and concurrency savings require a hosted integration measurement. The benchmark remains manually available through `ORCA_BACKGROUND_LAUNCH=1 pnpm exec vitest run --config config/vitest.agent-status-benchmark.config.ts`. No package manifest or ordinary CI performance contract is changed.
