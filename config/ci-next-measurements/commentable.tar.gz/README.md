Commentable-line import boundary screen

Run from the repository root with candidate source installed:
  python3 run-benchmark.py --out /tmp/commentable-pairs
  python3 run-controls.py --out /tmp/commentable-controls

Both drivers verify frozen source/production inputs, all six original full names and outcomes, and restore the test bytes in finally. All child Vitest invocations set ORCA_BACKGROUND_LAUNCH=1, disable persisted transforms and use one worker. Three alternating pairs preserve the real hook, render signatures, React root lifecycle, editor/model overlay and all original bodies. Only unused saved-note NotesSendMenu graph is replaced by its exact typed facade. Three actual hook faults fail existing assertions; the production signature boundary calling the unrelated menu triggers both facade and afterEach sentinel, and an independent afterAll proves call history cleared. Existing NotesSendMenu.test.tsx and ReviewNotesSendMenuContent.test.tsx retain menu behavior coverage. Local medians do not establish full CI gains.
